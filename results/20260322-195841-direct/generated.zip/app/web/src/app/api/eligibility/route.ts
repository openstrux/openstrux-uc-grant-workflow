
import { NextRequest, NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { requireRole, logAccessDecision } from "../../../server/auth/middleware";
import { EligibilityRequestSchema } from "../../../../../../packages/domain/src/schemas/index";
import { runEligibilityCheck } from "../../../../../../packages/policies/src/workflow/runEligibilityCheck";
import { checkAccess } from "../../../../../../packages/policies/src/access/checkAccess";

const prisma = new PrismaClient();

export async function POST(req: NextRequest): Promise<NextResponse> {
  // 1. Authenticate — only admins may trigger eligibility checks
  const authResult = requireRole(req, "admin");
  if (authResult.error) return authResult.error;
  const { principal } = authResult;

  // 2. Parse and validate request body
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const parseResult = EligibilityRequestSchema.safeParse(body);
  if (!parseResult.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parseResult.error.flatten() },
      { status: 422 }
    );
  }

  const { submission_id, inputs } = parseResult.data;

  // 3. Load submission to check ownership/state for policy
  const submission = await prisma.submission.findUnique({
    where: { id: submission_id },
  });

  if (!submission) {
    return NextResponse.json({ error: "Submission not found" }, { status: 404 });
  }

  // 4. Check access policy
  const accessCtx = {
    principal,
    resourceType: "EligibilityRecord" as const,
    operation: "write" as const,
    resourceId: submission_id,
    submissionStatus: submission.status as import("../../../../../../packages/domain/src/entities/index").ProposalStatus,
  };

  const decision = checkAccess(accessCtx);

  await logAccessDecision(prisma, principal, accessCtx, decision.allowed, decision.reason);

  if (!decision.allowed) {
    return NextResponse.json(
      { error: "Forbidden", reason: decision.reason },
      { status: 403 }
    );
  }

  // 5. Execute service
  try {
    const result = await runEligibilityCheck(
      prisma,
      principal,
      submission_id,
      inputs
    );

    return NextResponse.json(
      {
        eligibility_record_id: result.record.id,
        submission_id: result.submission.id,
        status: result.record.status,
        failure_reasons: result.record.failure_reasons,
        active_rules: result.record.active_rules,
        new_submission_status: result.submission.status,
        audit_event_id: result.auditEvent.id,
      },
      { status: 200 }
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Internal server error";

    if (message.includes("can only be run on submitted")) {
      return NextResponse.json({ error: message }, { status: 409 });
    }

    console.error("[eligibility] runEligibilityCheck error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
