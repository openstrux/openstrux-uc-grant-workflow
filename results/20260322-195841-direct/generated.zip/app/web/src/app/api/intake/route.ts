
import { NextRequest, NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { requireRole, logAccessDecision } from "../../../server/auth/middleware";
import { IntakeRequestSchema } from "../../../../../../packages/domain/src/schemas/index";
import { submitProposal } from "../../../../../../packages/policies/src/workflow/submitProposal";
import { checkAccess } from "../../../../../../packages/policies/src/access/checkAccess";

const prisma = new PrismaClient();

export async function POST(req: NextRequest): Promise<NextResponse> {
  // 1. Authenticate — only applicants may submit proposals
  const authResult = requireRole(req, "applicant", "admin");
  if (authResult.error) return authResult.error;
  const { principal } = authResult;

  // 2. Parse and validate request body
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const parseResult = IntakeRequestSchema.safeParse(body);
  if (!parseResult.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parseResult.error.flatten() },
      { status: 422 }
    );
  }

  const request = parseResult.data;

  // 3. Check access policy
  const accessCtx = {
    principal,
    resourceType: "Submission" as const,
    operation: "write" as const,
  };

  const decision = checkAccess(accessCtx);

  await logAccessDecision(prisma, principal, accessCtx, decision.allowed, decision.reason);

  if (!decision.allowed) {
    return NextResponse.json(
      { error: "Forbidden", reason: decision.reason },
      { status: 403 }
    );
  }

  // 4. Execute service
  try {
    const result = await submitProposal(prisma, principal, request);

    return NextResponse.json(
      {
        submission_id: result.submission.id,
        status: result.submission.status,
        proposal_version_id: result.proposalVersion.id,
        audit_event_id: result.auditEvent.id,
      },
      { status: 201 }
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Internal server error";

    // Distinguish domain errors (4xx) from unexpected errors (5xx)
    if (
      message.includes("not open") ||
      message.includes("outside its submission window")
    ) {
      return NextResponse.json({ error: message }, { status: 409 });
    }

    console.error("[intake] submitProposal error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
