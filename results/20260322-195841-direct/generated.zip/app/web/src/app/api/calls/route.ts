
import { NextRequest, NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { requireRole, logAccessDecision } from "../../../server/auth/middleware";
import { checkAccess } from "../../../../../../packages/policies/src/access/checkAccess";
import { z } from "zod";

const prisma = new PrismaClient();

const CreateCallBodySchema = z.object({
  title: z.string().min(1),
  description: z.string(),
  open_date: z.coerce.date(),
  close_date: z.coerce.date(),
  max_budget_k_eur: z.number().positive(),
  reviewer_policy_version: z.string().min(1),
  enabled_eligibility_checks: z.array(z.string()).min(1),
});

export async function GET(req: NextRequest): Promise<NextResponse> {
  const authResult = requireRole(req, "admin", "applicant", "reviewer");
  if (authResult.error) return authResult.error;
  const { principal } = authResult;

  const accessCtx = {
    principal,
    resourceType: "Call" as const,
    operation: "read" as const,
  };

  const decision = checkAccess(accessCtx);
  await logAccessDecision(prisma, principal, accessCtx, decision.allowed, decision.reason);

  if (!decision.allowed) {
    return NextResponse.json({ error: "Forbidden", reason: decision.reason }, { status: 403 });
  }

  const calls = await prisma.call.findMany({
    orderBy: { created_at: "desc" },
  });

  return NextResponse.json({ calls }, { status: 200 });
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  const authResult = requireRole(req, "admin");
  if (authResult.error) return authResult.error;
  const { principal } = authResult;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const parseResult = CreateCallBodySchema.safeParse(body);
  if (!parseResult.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parseResult.error.flatten() },
      { status: 422 }
    );
  }

  const accessCtx = {
    principal,
    resourceType: "Call" as const,
    operation: "write" as const,
  };

  const decision = checkAccess(accessCtx);
  await logAccessDecision(prisma, principal, accessCtx, decision.allowed, decision.reason);

  if (!decision.allowed) {
    return NextResponse.json({ error: "Forbidden", reason: decision.reason }, { status: 403 });
  }

  const data = parseResult.data;

  const call = await prisma.call.create({
    data: {
      title: data.title,
      description: data.description,
      open_date: data.open_date,
      close_date: data.close_date,
      status: "draft",
      max_budget_k_eur: data.max_budget_k_eur,
      reviewer_policy_version: data.reviewer_policy_version,
      enabled_eligibility_checks: data.enabled_eligibility_checks,
    },
  });

  await prisma.auditEvent.create({
    data: {
      event_type: "call.created",
      actor_id: principal.id,
      target_type: "Call",
      target_id: call.id,
      payload: { title: call.title, status: call.status },
      timestamp: new Date(),
    },
  });

  return NextResponse.json({ call }, { status: 201 });
}
