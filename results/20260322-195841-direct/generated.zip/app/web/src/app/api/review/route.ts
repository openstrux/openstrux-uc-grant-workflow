
import { NextRequest, NextResponse } from "next/server";

/**
 * P3 — Review
 * Not active for the v0.6.0 MVP. Returns 501 Not Implemented.
 */
export async function GET(_req: NextRequest): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", phase: "P3", message: "Review phase is not active in v0.6.0" },
    { status: 501 }
  );
}

export async function POST(_req: NextRequest): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", phase: "P3", message: "Review phase is not active in v0.6.0" },
    { status: 501 }
  );
}
