
import { NextRequest, NextResponse } from "next/server";

/**
 * P6 — Audit / Lifecycle
 * Not active for the v0.6.0 MVP. Returns 501 Not Implemented.
 */
export async function GET(_req: NextRequest): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", phase: "P6", message: "Audit export is not active in v0.6.0" },
    { status: 501 }
  );
}
