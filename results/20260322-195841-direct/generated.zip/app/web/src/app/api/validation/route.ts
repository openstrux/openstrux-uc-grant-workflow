
import { NextRequest, NextResponse } from "next/server";

/**
 * P5 — Validation
 * Not active for the v0.6.0 MVP. Returns 501 Not Implemented.
 */
export async function GET(_req: NextRequest): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", phase: "P5", message: "Validation phase is not active in v0.6.0" },
    { status: 501 }
  );
}

export async function POST(_req: NextRequest): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", phase: "P5", message: "Validation phase is not active in v0.6.0" },
    { status: 501 }
  );
}
