
import { NextRequest, NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import { requirePrincipal, logAccessDecision } from "../../../../server/auth/middleware";
import { checkAccess } from "../../../../../../../packages/policies/src/access/checkAccess";
import type { ProposalStatus } from "../../../../../../../packages/domain/src/entities/index";

const prisma = new PrismaClient();

interface RouteParams {
  params: Promise<{ id: string }>;
}

export async function GET(
  req: NextRequest,
  { params }: RouteParams
): Promise<NextResponse> {
  const authResult = requirePrincipal(req);
  if (authResult.error) return authResult.error;
  const { principal } = authResult;

  const { id: submissionId } = await params;

  // Load submission to determine ownership and state
  const submission = await prisma.submission.findUnique({
    where: { id: submissionId },
    include: {
      proposal_versions: {
        where: { is_effective: true },
        select: {
          id: true,
          version_number: true,
          title: true,
          abstract: true,
          requested_budget_k_eur: true,
          budget_usage: true,
          tasks_breakdown: true,
          attachments_meta: true,
          is_effective: true,
          submission_id: true,
          created_at: true,
          updated_at: true,
        },
      },
    },
  });

  if (!submission) {
    return NextResponse.json({ error: "Submission not found" }, { status: 404 });
  }

  const accessCtx = {
    principal,
    resourceType: "Submission" as const,
    operation: "read" as const,
    resourceId: submissionId,
    resourceOwnerId: submission.applicant_alias,
    submissionStatus: submission.status as ProposalStatus,
  };

  const decision = checkAccess(accessCtx);
  await logAccessDecision(prisma, principal, accessCtx, decision.allowed, decision.reason);

  if (!decision.allowed) {
    return NextResponse.json(
      { error: "Forbidden", reason: decision.reason },
      { status: 403 }
    );
  }

  // Never expose applicant_alias to reviewers
  const responseBody =
    principal.role === "reviewer"
      ? {
          id: submission.id,
          call_id: submission.call_id,
          status: submission.status,
          submitted_at: submission.submitted_at,
          proposal_versions: submission.proposal_versions,
        }
      : {
          id: submission.id,
          call_id: submission.call_id,
          applicant_alias: submission.applicant_alias,
          status: submission.status,
          submitted_at: submission.submitted_at,
          proposal_versions: submission.proposal_versions,
        };

  return NextResponse.json({ submission: responseBody }, { status: 200 });
}
