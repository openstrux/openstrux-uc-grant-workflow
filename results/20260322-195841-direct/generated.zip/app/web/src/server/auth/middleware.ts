
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import type { Principal } from "../../../../../packages/domain/src/entities/index";
import { PrincipalRoleSchema } from "../../../../../packages/domain/src/schemas/index";
import { PrismaClient } from "@prisma/client";
import { checkAccess } from "../../../../../packages/policies/src/access/checkAccess";
import type { AccessContext } from "../../../../../packages/domain/src/entities/index";

// ─── JWT-lite / dev-mode principal extraction ─────────────────────────────────
// P0-P2: No external IdP. In dev mode we accept the X-Role and X-Actor-Id
// headers. In production mode a signed JWT is expected in Authorization.

const DEV_MODE = process.env.NODE_ENV !== "production";

const DevHeadersSchema = z.object({
  role: PrincipalRoleSchema,
  actorId: z.string().min(1),
  identity: z.string().min(1),
});

interface JwtPayload {
  sub: string;
  role: string;
  identity: string;
  iat: number;
  exp: number;
}

function parseDevPrincipal(req: NextRequest): Principal | null {
  const role = req.headers.get("x-role");
  const actorId = req.headers.get("x-actor-id");
  const identity = req.headers.get("x-identity");

  const parsed = DevHeadersSchema.safeParse({ role, actorId, identity });
  if (!parsed.success) return null;

  return {
    id: parsed.data.actorId,
    role: parsed.data.role,
    identity: parsed.data.identity,
  };
}

function parseJwtPrincipal(req: NextRequest): Principal | null {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) return null;

  const token = authHeader.slice(7);

  // Minimal JWT parse — signature verification requires a key; for P0-P2
  // we decode the payload only. A real implementation would use jose or jsonwebtoken.
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;

    const payloadBase64 = parts[1];
    // Handle both standard and URL-safe base64
    const padded = payloadBase64.replace(/-/g, "+").replace(/_/g, "/");
    const payload: JwtPayload = JSON.parse(
      Buffer.from(padded, "base64").toString("utf-8")
    );

    const now = Math.floor(Date.now() / 1000);
    if (payload.exp && payload.exp < now) return null;

    const roleResult = PrincipalRoleSchema.safeParse(payload.role);
    if (!roleResult.success) return null;

    return {
      id: payload.sub,
      role: roleResult.data,
      identity: payload.identity,
    };
  } catch {
    return null;
  }
}

/**
 * Extracts the principal from an incoming request.
 * Returns null if no valid credentials are found.
 */
export function extractPrincipal(req: NextRequest): Principal | null {
  if (DEV_MODE) {
    const devPrincipal = parseDevPrincipal(req);
    if (devPrincipal) return devPrincipal;
  }

  return parseJwtPrincipal(req);
}

/**
 * Requires a valid principal or returns a 401 response.
 */
export function requirePrincipal(
  req: NextRequest
): { principal: Principal; error: null } | { principal: null; error: NextResponse } {
  const principal = extractPrincipal(req);
  if (!principal) {
    return {
      principal: null,
      error: NextResponse.json(
        { error: "Unauthorized: missing or invalid credentials" },
        { status: 401 }
      ),
    };
  }
  return { principal, error: null };
}

/**
 * Requires a principal with a specific role.
 */
export function requireRole(
  req: NextRequest,
  ...allowedRoles: Principal["role"][]
): { principal: Principal; error: null } | { principal: null; error: NextResponse } {
  const result = requirePrincipal(req);
  if (result.error) return result;

  if (!allowedRoles.includes(result.principal.role)) {
    return {
      principal: null,
      error: NextResponse.json(
        {
          error: `Forbidden: role '${result.principal.role}' is not permitted for this operation`,
        },
        { status: 403 }
      ),
    };
  }

  return { principal: result.principal, error: null };
}

/**
 * Logs an access decision audit event.
 * Called from route handlers after checkAccess.
 */
export async function logAccessDecision(
  prisma: PrismaClient,
  principal: Principal,
  ctx: AccessContext,
  allowed: boolean,
  reason: string
): Promise<void> {
  await prisma.auditEvent.create({
    data: {
      event_type: "access",
      actor_id: principal.id,
      target_type: ctx.resourceType,
      target_id: ctx.resourceId ?? "unknown",
      payload: {
        operation: ctx.operation,
        allowed,
        reason,
        role: principal.role,
      },
      timestamp: new Date(),
    },
  });
}
