
import { PrismaClient } from "@prisma/client";
import type {
  EligibilityInputs,
  EligibilityResult,
  Principal,
} from "../../../domain/src/entities/index";
import { evaluateEligibility } from "../eligibility/evaluateEligibility";
import { mapToBlindedPacketContent } from "../blindedPacket/mapToBlindedPacket";

/**
 * Runs eligibility evaluation for a submission.
 * - Loads the submission + its call configuration
 * - Calls the pure evaluateEligibility function
 * - Persists an EligibilityRecord with the exact inputs and active rule set
 * - Transitions the submission status
 * - If eligible, generates the BlindedPacket from the effective ProposalVersion
 * - Writes an AuditEvent
 *
 * All writes are in a Prisma transaction.
 */
export async function runEligibilityCheck(
  prisma: PrismaClient,
  actor: Principal,
  submissionId: string,
  inputs: EligibilityInputs
): Promise<EligibilityResult> {
  const now = new Date();

  return prisma.$transaction(async (tx) => {
    // 1. Load submission
    const submission = await tx.submission.findUniqueOrThrow({
      where: { id: submissionId },
      include: {
        call: true,
        proposal_versions: {
          where: { is_effective: true },
        },
      },
    });

    if (submission.status !== "submitted") {
      throw new Error(
        `Eligibility check can only be run on submitted proposals (current status: ${submission.status})`
      );
    }

    const call = submission.call;

    // 2. Evaluate eligibility (pure function — no side effects)
    const evalResult = evaluateEligibility(
      inputs,
      call.enabled_eligibility_checks,
      call.max_budget_k_eur
    );

    // 3. Persist EligibilityRecord
    const eligibilityRecord = await tx.eligibilityRecord.create({
      data: {
        submission_id: submissionId,
        status: evalResult.status,
        inputs: inputs as unknown as Parameters<typeof tx.eligibilityRecord.create>[0]["data"]["inputs"],
        active_rules: evalResult.active_rules,
        failure_reasons: evalResult.failure_reasons,
        evaluated_at: now,
      },
    });

    // 4. Determine new submission status
    const newStatus =
      evalResult.status === "eligible" ? "eligible" : "eligibility_failed";

    // 5. Update submission status
    const updatedSubmission = await tx.submission.update({
      where: { id: submissionId },
      data: { status: newStatus },
    });

    // 6. If eligible, generate BlindedPacket from effective ProposalVersion
    if (newStatus === "eligible") {
      const effectiveVersion = submission.proposal_versions[0];
      if (!effectiveVersion) {
        throw new Error(
          `No effective ProposalVersion found for submission ${submissionId}`
        );
      }

      const domainVersion = {
        id: effectiveVersion.id,
        submission_id: effectiveVersion.submission_id,
        version_number: effectiveVersion.version_number,
        is_effective: effectiveVersion.is_effective,
        title: effectiveVersion.title,
        abstract: effectiveVersion.abstract,
        requested_budget_k_eur: effectiveVersion.requested_budget_k_eur,
        budget_usage: effectiveVersion.budget_usage,
        tasks_breakdown: effectiveVersion.tasks_breakdown as Record<string, unknown>,
        attachments_meta: (
          effectiveVersion.attachments_meta as unknown[]
        ).map((a) => a as Record<string, unknown>),
        created_at: effectiveVersion.created_at,
        updated_at: effectiveVersion.updated_at,
      };

      const blindedContent = mapToBlindedPacketContent(
        domainVersion,
        submissionId
      );

      await tx.blindedPacket.create({
        data: {
          proposal_version_id: effectiveVersion.id,
          content: blindedContent as unknown as Parameters<
            typeof tx.blindedPacket.create
          >[0]["data"]["content"],
        },
      });
    }

    // 7. Emit AuditEvent
    const auditEvent = await tx.auditEvent.create({
      data: {
        event_type: "eligibility.evaluated",
        actor_id: actor.id,
        target_type: "Submission",
        target_id: submissionId,
        payload: {
          eligibility_record_id: eligibilityRecord.id,
          result: evalResult.status,
          previous_status: "submitted",
          new_status: newStatus,
          failure_reasons: evalResult.failure_reasons,
          active_rules: evalResult.active_rules,
          evaluated_at: now.toISOString(),
        },
        timestamp: now,
      },
    });

    // 8. Map to domain types for return
    const domainEligibilityRecord = {
      id: eligibilityRecord.id,
      submission_id: eligibilityRecord.submission_id,
      status: eligibilityRecord.status as EligibilityInputs extends infer T ? "eligible" | "ineligible" | "pending" : never,
      inputs: eligibilityRecord.inputs as unknown as EligibilityInputs,
      active_rules: eligibilityRecord.active_rules,
      failure_reasons: eligibilityRecord.failure_reasons,
      evaluated_at: eligibilityRecord.evaluated_at,
      created_at: eligibilityRecord.created_at,
      updated_at: eligibilityRecord.updated_at,
    };

    const domainSubmission = {
      id: updatedSubmission.id,
      call_id: updatedSubmission.call_id,
      applicant_alias: updatedSubmission.applicant_alias,
      status: updatedSubmission.status as typeof newStatus,
      submitted_at: updatedSubmission.submitted_at,
      created_at: updatedSubmission.created_at,
      updated_at: updatedSubmission.updated_at,
    };

    const domainAuditEvent = {
      id: auditEvent.id,
      event_type: auditEvent.event_type,
      actor_id: auditEvent.actor_id,
      target_type: auditEvent.target_type,
      target_id: auditEvent.target_id,
      payload: auditEvent.payload as Record<string, unknown>,
      timestamp: auditEvent.timestamp,
    };

    return {
      record: domainEligibilityRecord,
      submission: domainSubmission,
      auditEvent: domainAuditEvent,
    };
  });
}
