
import { PrismaClient } from "@prisma/client";
import type {
  IntakeRequest,
  SubmitProposalResult,
  Principal,
} from "../../../domain/src/entities/index";
import { mapToBlindedPacketContent } from "../blindedPacket/mapToBlindedPacket";

/**
 * Creates a new Submission (in draft status), its first ProposalVersion,
 * the ApplicantIdentity record, and — when the call requires a blinded
 * packet immediately — the BlindedPacket.
 *
 * All writes are wrapped in a single Prisma transaction.
 * An AuditEvent is emitted for the submission creation.
 *
 * NOTE: The submission starts in `draft` status per the domain model.
 * A subsequent explicit `submit` action transitions it to `submitted`.
 * For the P1 MVP the intake endpoint sets status to `submitted` directly
 * because there is no separate "save draft" flow in the frontend.
 */
export async function submitProposal(
  prisma: PrismaClient,
  actor: Principal,
  request: IntakeRequest
): Promise<SubmitProposalResult> {
  const now = new Date();

  return prisma.$transaction(async (tx) => {
    // 1. Verify call exists and is open
    const call = await tx.call.findUniqueOrThrow({
      where: { id: request.call_id },
    });

    if (call.status !== "open") {
      throw new Error(`Call ${call.id} is not open for submissions (status: ${call.status})`);
    }

    if (now < call.open_date || now > call.close_date) {
      throw new Error(
        `Call ${call.id} is outside its submission window`
      );
    }

    // 2. Create Submission
    const submission = await tx.submission.create({
      data: {
        call_id: request.call_id,
        applicant_alias: actor.identity,
        status: "submitted",
        submitted_at: now,
      },
    });

    // 3. Create ProposalVersion (version 1, effective)
    const proposalVersion = await tx.proposalVersion.create({
      data: {
        submission_id: submission.id,
        version_number: 1,
        is_effective: true,
        title: request.proposal.title,
        abstract: request.proposal.abstract,
        requested_budget_k_eur: request.proposal.requested_budget_k_eur,
        budget_usage: request.proposal.budget_usage,
        tasks_breakdown: request.proposal.tasks_breakdown,
        attachments_meta: request.proposal.attachments_meta,
      },
    });

    // 4. Create ApplicantIdentity — separate record, separate data path
    await tx.applicantIdentity.create({
      data: {
        submission_id: submission.id,
        legal_name: request.identity.legal_name,
        email: request.identity.email,
        country: request.identity.country,
        organisation: request.identity.organisation,
      },
    });

    // 5. Emit AuditEvent
    const auditEvent = await tx.auditEvent.create({
      data: {
        event_type: "submission.created",
        actor_id: actor.id,
        target_type: "Submission",
        target_id: submission.id,
        payload: {
          call_id: request.call_id,
          status: "submitted",
          version_number: 1,
          submitted_at: now.toISOString(),
        },
        timestamp: now,
      },
    });

    // 6. Map domain types for return value
    // The ProposalVersion from Prisma needs casting to our domain type
    const domainProposalVersion = {
      id: proposalVersion.id,
      submission_id: proposalVersion.submission_id,
      version_number: proposalVersion.version_number,
      is_effective: proposalVersion.is_effective,
      title: proposalVersion.title,
      abstract: proposalVersion.abstract,
      requested_budget_k_eur: proposalVersion.requested_budget_k_eur,
      budget_usage: proposalVersion.budget_usage,
      tasks_breakdown: proposalVersion.tasks_breakdown as Record<string, unknown>,
      attachments_meta: (proposalVersion.attachments_meta as unknown[]).map(
        (a) => a as Record<string, unknown>
      ),
      created_at: proposalVersion.created_at,
      updated_at: proposalVersion.updated_at,
    };

    const domainSubmission = {
      id: submission.id,
      call_id: submission.call_id,
      applicant_alias: submission.applicant_alias,
      status: submission.status as "submitted",
      submitted_at: submission.submitted_at,
      created_at: submission.created_at,
      updated_at: submission.updated_at,
    };

    const domainAuditEvent = {
      id: auditEvent.id,
      event_type: auditEvent.event_type,
      actor_id: auditEvent.actor_id,
      target_type: auditEvent.target_type,
      target_id: auditEvent.target_id,
      payload: auditEvent.payload as Record<string, unknown>,
      timestamp: auditEvent.timestamp,
    };

    return {
      submission: domainSubmission,
      proposalVersion: domainProposalVersion,
      blindedPacket: null, // BlindedPacket generated on transition to `eligible`
      auditEvent: domainAuditEvent,
    };
  });
}
