
import type { ProposalVersion, BlindedPacketContent } from "../../../domain/src/entities/index";

/**
 * Strips all identity-related fields from a ProposalVersion and returns
 * a BlindedPacketContent safe for reviewer access.
 *
 * Identity fields that must NEVER appear: legal_name, email, country,
 * organisation, applicant_alias — none of these are present on ProposalVersion
 * itself, but this mapper is the enforcement point to ensure no future
 * field additions leak through.
 */
export function mapToBlindedPacketContent(
  proposalVersion: ProposalVersion,
  submissionId: string
): BlindedPacketContent {
  // Explicitly pick only safe fields — do not use object spread to avoid
  // accidentally including newly added fields.
  const content: BlindedPacketContent = {
    proposal_version_id: proposalVersion.id,
    submission_id: submissionId,
    version_number: proposalVersion.version_number,
    title: proposalVersion.title,
    abstract: proposalVersion.abstract,
    requested_budget_k_eur: proposalVersion.requested_budget_k_eur,
    budget_usage: proposalVersion.budget_usage,
    tasks_breakdown: proposalVersion.tasks_breakdown,
    attachments_meta: proposalVersion.attachments_meta,
  };

  return content;
}
