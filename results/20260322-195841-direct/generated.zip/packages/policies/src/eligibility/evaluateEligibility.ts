
import type {
  EligibilityInputs,
  EligibilityEvaluationResult,
  EligibilityStatus,
} from "../../../domain/src/entities/index";

// ─── Rule definitions ─────────────────────────────────────────────────────────

type EligibilityRule = {
  key: string;
  label: string;
  evaluate: (inputs: EligibilityInputs, maxBudgetKEur: number) => boolean;
  failureMessage: string;
};

const ALL_RULES: EligibilityRule[] = [
  {
    key: "submittedInEnglish",
    label: "Submitted in English",
    evaluate: (inputs) => inputs.submitted_in_english,
    failureMessage: "Proposal was not submitted in English.",
  },
  {
    key: "alignedWithCall",
    label: "Aligned with call objectives",
    evaluate: (inputs) => inputs.aligned_with_call,
    failureMessage: "Proposal is not aligned with the call objectives.",
  },
  {
    key: "primaryObjectiveIsRd",
    label: "Primary objective is R&D",
    evaluate: (inputs) => inputs.primary_objective_is_rd,
    failureMessage: "Primary objective is not research and development.",
  },
  {
    key: "meetsEuropeanDimension",
    label: "Meets European dimension",
    evaluate: (inputs) =>
      inputs.meets_european_dimension === "true" ||
      inputs.meets_european_dimension === "not_applicable",
    failureMessage: "Proposal does not meet the European dimension requirement.",
  },
  {
    key: "requestedBudgetKEur",
    label: "Requested budget within limit",
    evaluate: (inputs, maxBudgetKEur) =>
      inputs.requested_budget_k_eur <= maxBudgetKEur,
    failureMessage: "Requested budget exceeds the maximum allowed for this call.",
  },
];

// ─── Public evaluation function ───────────────────────────────────────────────

/**
 * Pure function — no side effects, no DB access.
 * Evaluates EligibilityInputs against the specified enabled rule keys
 * and the call's max budget.
 *
 * Records exact input values and the active rule set in the result so that
 * the persisted EligibilityRecord contains a complete audit snapshot.
 */
export function evaluateEligibility(
  inputs: EligibilityInputs,
  enabledChecks: string[],
  maxBudgetKEur: number
): EligibilityEvaluationResult {
  // Resolve only the rules that are enabled for this call
  const activeRules = ALL_RULES.filter((rule) =>
    enabledChecks.includes(rule.key)
  );

  const activeRuleKeys = activeRules.map((r) => r.key);
  const failureReasons: string[] = [];

  for (const rule of activeRules) {
    const passed = rule.evaluate(inputs, maxBudgetKEur);
    if (!passed) {
      failureReasons.push(rule.failureMessage);
    }
  }

  const status: EligibilityStatus =
    failureReasons.length === 0 ? "eligible" : "ineligible";

  return {
    status,
    failure_reasons: failureReasons,
    active_rules: activeRuleKeys,
  };
}
