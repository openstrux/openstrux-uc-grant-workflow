
import type {
  AccessContext,
  AccessDecision,
  Principal,
  ResourceType,
  Operation,
  ProposalStatus,
} from "../../../domain/src/entities/index";

// ─── Hard deny rules (evaluated before any allow) ────────────────────────────

const HARD_DENY_RULES: Array<{
  role: Principal["role"];
  resourceType: ResourceType;
  reason: string;
}> = [
  {
    role: "reviewer",
    resourceType: "ApplicantIdentity",
    reason: "POLICY:deny-identity-to-reviewer — reviewers may never access ApplicantIdentity",
  },
  {
    role: "validator",
    resourceType: "ApplicantIdentity",
    reason: "POLICY:pseudonymization — validators may never access ApplicantIdentity",
  },
];

// ─── State-based access matrix ────────────────────────────────────────────────

type StateAccessEntry = {
  applicant: ("read" | "write")[];
  reviewer: ("read" | "write")[];
  admin: ("read" | "write")[];
};

const STATE_ACCESS_MATRIX: Record<ProposalStatus, StateAccessEntry> = {
  draft: {
    applicant: ["read", "write"],
    reviewer: [],
    admin: ["read"],
  },
  submitted: {
    applicant: ["read"],
    reviewer: [],
    admin: ["read", "write"],
  },
  eligibility_failed: {
    applicant: ["read"],
    reviewer: [],
    admin: ["read", "write"],
  },
  eligible: {
    applicant: ["read"],
    reviewer: [],
    admin: ["read", "write"],
  },
  under_review: {
    applicant: ["read"],
    reviewer: ["read"],
    admin: ["read", "write"],
  },
  clarification_requested: {
    applicant: ["read", "write"],
    reviewer: ["read"],
    admin: ["read", "write"],
  },
  revised: {
    applicant: ["read"],
    reviewer: ["read"],
    admin: ["read", "write"],
  },
  validation_pending: {
    applicant: ["read"],
    reviewer: ["read"],
    admin: ["read", "write"],
  },
  selected: {
    applicant: ["read"],
    reviewer: ["read"],
    admin: ["read", "write"],
  },
  rejected: {
    applicant: ["read"],
    reviewer: [],
    admin: ["read"],
  },
};

// ─── Main policy function ─────────────────────────────────────────────────────

export function checkAccess(ctx: AccessContext): AccessDecision {
  const { principal, resourceType, operation, resourceOwnerId, submissionStatus } = ctx;

  // 1. Hard deny rules — evaluated unconditionally before anything else
  for (const rule of HARD_DENY_RULES) {
    if (principal.role === rule.role && resourceType === rule.resourceType) {
      return { allowed: false, reason: rule.reason };
    }
  }

  // 2. Admin has full access to all resources
  if (principal.role === "admin") {
    return { allowed: true, reason: "POLICY:admin-all" };
  }

  // 3. Auditor has read-only access to AuditEvent
  if (principal.role === "auditor") {
    if (resourceType === "AuditEvent" && operation === "read") {
      return { allowed: true, reason: "POLICY:auditor-audit-log-read" };
    }
    return { allowed: false, reason: "POLICY:auditor-read-only-audit-events" };
  }

  // 4. Applicant access — scoped to own submissions
  if (principal.role === "applicant") {
    // Must be the owner of this resource
    if (resourceOwnerId !== undefined && resourceOwnerId !== principal.identity) {
      return {
        allowed: false,
        reason: "POLICY:applicant-own-proposals — applicant may only access own submissions",
      };
    }

    // Applicants never access BlindedPacket or EligibilityRecord failure_reasons directly
    if (resourceType === "BlindedPacket") {
      return {
        allowed: false,
        reason: "POLICY:applicant-own-proposals — applicants excluded from BlindedPacket",
      };
    }

    // Apply state-based access matrix when we have a submission status
    if (submissionStatus !== undefined) {
      const stateEntry = STATE_ACCESS_MATRIX[submissionStatus];
      const allowed = stateEntry.applicant.includes(operation as "read" | "write");
      return {
        allowed,
        reason: allowed
          ? `POLICY:applicant-own-proposals — ${operation} allowed in state ${submissionStatus}`
          : `POLICY:applicant-own-proposals — ${operation} denied in state ${submissionStatus}`,
      };
    }

    // Default allow for applicant on their own resource with no specific state
    return { allowed: true, reason: "POLICY:applicant-own-proposals" };
  }

  // 5. Reviewer access — blinded packets of assigned proposals only
  if (principal.role === "reviewer") {
    if (resourceType === "BlindedPacket" && operation === "read") {
      // Assignment check is enforced at the service layer which calls this function
      // with resourceOwnerId set to the assigned submission id
      return { allowed: true, reason: "POLICY:reviewer-blinded-assigned" };
    }

    // Reviewers can read proposal state in permitted statuses
    if (
      resourceType === "Submission" &&
      operation === "read" &&
      submissionStatus !== undefined
    ) {
      const stateEntry = STATE_ACCESS_MATRIX[submissionStatus];
      const allowed = stateEntry.reviewer.includes("read");
      return {
        allowed,
        reason: allowed
          ? `POLICY:reviewer-blinded-assigned — read allowed in state ${submissionStatus}`
          : `POLICY:reviewer-blinded-assigned — read denied in state ${submissionStatus}`,
      };
    }

    return {
      allowed: false,
      reason: "POLICY:reviewer-blinded-assigned — operation not permitted for reviewer",
    };
  }

  // 6. Validator — P5+ stub
  if (principal.role === "validator") {
    return {
      allowed: false,
      reason: "POLICY:validator — P5 feature not active",
    };
  }

  return { allowed: false, reason: "No matching policy — access denied" };
}

// ─── Convenience assertion ────────────────────────────────────────────────────

export function assertAccess(ctx: AccessContext): void {
  const decision = checkAccess(ctx);
  if (!decision.allowed) {
    throw new AccessDeniedError(decision.reason, ctx);
  }
}

export class AccessDeniedError extends Error {
  public readonly context: AccessContext;
  public readonly policyReason: string;

  constructor(reason: string, context: AccessContext) {
    super(`Access denied: ${reason}`);
    this.name = "AccessDeniedError";
    this.policyReason = reason;
    this.context = context;
  }
}
