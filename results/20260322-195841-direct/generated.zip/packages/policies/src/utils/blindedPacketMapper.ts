
import type { ProposalVersion } from "../../../domain/src/entities/index.js";
import type { BlindedContent } from "../../../domain/src/entities/index.js";

/**
 * Maps a ProposalVersion row (as returned from Prisma) into a BlindedContent
 * object that contains absolutely no identity fields.
 *
 * Fields explicitly excluded (per specs/access-policies.md pseudonymization rule):
 *   - legal_name, email, country, organisation (from ApplicantIdentity — never on ProposalVersion)
 *   - applicant_alias (from Submission — not present on ProposalVersion)
 *   - submission_id is included because it is required for reviewer workflow
 *     but it is a pseudonymous cuid, not an identity field.
 */
export function mapToBlindedContent(
  version: Pick<
    ProposalVersion,
    | "submission_id"
    | "version_number"
    | "title"
    | "abstract"
    | "requested_budget_k_eur"
    | "budget_usage"
    | "tasks_breakdown"
    | "attachments_meta"
  >
): BlindedContent {
  return {
    submission_id: version.submission_id,
    version_number: version.version_number,
    title: version.title,
    abstract: version.abstract,
    requested_budget_k_eur: version.requested_budget_k_eur,
    budget_usage: version.budget_usage,
    tasks_breakdown: version.tasks_breakdown,
    attachments_meta: version.attachments_meta,
  };
}

/**
 * Verify at runtime that a blinded content object contains no known identity fields.
 * Throws if a violation is detected. Used in tests and as a safety guard before
 * persisting a BlindedPacket.
 */
const IDENTITY_FIELDS = [
  "legal_name",
  "email",
  "country",
  "organisation",
  "applicant_alias",
] as const;

export function assertNoIdentityFields(content: Record<string, unknown>): void {
  for (const field of IDENTITY_FIELDS) {
    if (field in content) {
      throw new Error(
        `[BlindedPacketMapper] Identity field "${field}" found in blinded content. Aborting.`
      );
    }
  }
}
