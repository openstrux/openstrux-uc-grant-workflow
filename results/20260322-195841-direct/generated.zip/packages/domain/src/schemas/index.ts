
import { z } from "zod";

// ─── Enumerations ────────────────────────────────────────────────────────────

export const ProposalStatusSchema = z.enum([
  "draft",
  "submitted",
  "eligibility_failed",
  "eligible",
  "under_review",
  "clarification_requested",
  "revised",
  "validation_pending",
  "selected",
  "rejected",
]);

export const EligibilityStatusSchema = z.enum([
  "eligible",
  "ineligible",
  "pending",
]);

export const CallStatusSchema = z.enum(["draft", "open", "closed", "archived"]);

export const MeetsEuropeanDimensionSchema = z.enum([
  "true",
  "false",
  "not_applicable",
]);

export const PrincipalRoleSchema = z.enum([
  "applicant",
  "admin",
  "reviewer",
  "validator",
  "auditor",
]);

// ─── EligibilityInputs ───────────────────────────────────────────────────────

export const EligibilityInputsSchema = z.object({
  submitted_in_english: z.boolean(),
  aligned_with_call: z.boolean(),
  primary_objective_is_rd: z.boolean(),
  meets_european_dimension: MeetsEuropeanDimensionSchema,
  requested_budget_k_eur: z.number().positive(),
  first_time_applicant_in_programme: z.boolean(),
});

// ─── Call ────────────────────────────────────────────────────────────────────

export const CallSchema = z.object({
  id: z.string().cuid(),
  title: z.string().min(1),
  description: z.string(),
  open_date: z.coerce.date(),
  close_date: z.coerce.date(),
  status: CallStatusSchema,
  max_budget_k_eur: z.number().positive(),
  reviewer_policy_version: z.string(),
  enabled_eligibility_checks: z.array(z.string()),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

export const CreateCallSchema = CallSchema.omit({
  id: true,
  created_at: true,
  updated_at: true,
  status: true,
});

// ─── Submission ───────────────────────────────────────────────────────────────

export const SubmissionSchema = z.object({
  id: z.string().cuid(),
  call_id: z.string().cuid(),
  applicant_alias: z.string().min(1),
  status: ProposalStatusSchema,
  submitted_at: z.coerce.date().nullable(),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── ProposalVersion ─────────────────────────────────────────────────────────

export const ProposalVersionSchema = z.object({
  id: z.string().cuid(),
  submission_id: z.string().cuid(),
  version_number: z.number().int().positive(),
  is_effective: z.boolean(),
  title: z.string().min(1),
  abstract: z.string().min(1),
  requested_budget_k_eur: z.number().positive(),
  budget_usage: z.string(),
  tasks_breakdown: z.record(z.unknown()),
  attachments_meta: z.array(z.record(z.unknown())),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── ApplicantIdentity ────────────────────────────────────────────────────────

export const ApplicantIdentitySchema = z.object({
  id: z.string().cuid(),
  submission_id: z.string().cuid(),
  legal_name: z.string().min(1),
  email: z.string().email(),
  country: z.string().min(1),
  organisation: z.string().min(1),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── BlindedPacket ────────────────────────────────────────────────────────────

export const BlindedPacketContentSchema = z.object({
  proposal_version_id: z.string().cuid(),
  submission_id: z.string().cuid(),
  version_number: z.number().int(),
  title: z.string(),
  abstract: z.string(),
  requested_budget_k_eur: z.number(),
  budget_usage: z.string(),
  tasks_breakdown: z.record(z.unknown()),
  attachments_meta: z.array(z.record(z.unknown())),
});

export const BlindedPacketSchema = z.object({
  id: z.string().cuid(),
  proposal_version_id: z.string().cuid(),
  content: BlindedPacketContentSchema,
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── EligibilityRecord ────────────────────────────────────────────────────────

export const EligibilityRecordSchema = z.object({
  id: z.string().cuid(),
  submission_id: z.string().cuid(),
  status: EligibilityStatusSchema,
  inputs: EligibilityInputsSchema,
  active_rules: z.array(z.string()),
  failure_reasons: z.array(z.string()),
  evaluated_at: z.coerce.date(),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── AuditEvent ───────────────────────────────────────────────────────────────

export const AuditEventSchema = z.object({
  id: z.string().cuid(),
  event_type: z.string(),
  actor_id: z.string(),
  target_type: z.string(),
  target_id: z.string(),
  payload: z.record(z.unknown()),
  timestamp: z.coerce.date(),
});

// ─── API Input Schemas ────────────────────────────────────────────────────────

export const IntakeRequestSchema = z.object({
  call_id: z.string().min(1),
  proposal: z.object({
    title: z.string().min(1),
    abstract: z.string().min(1),
    requested_budget_k_eur: z.number().positive(),
    budget_usage: z.string().min(1),
    tasks_breakdown: z.record(z.unknown()),
    attachments_meta: z.array(z.record(z.unknown())).default([]),
  }),
  identity: z.object({
    legal_name: z.string().min(1),
    email: z.string().email(),
    country: z.string().min(1),
    organisation: z.string().min(1),
  }),
});

export const EligibilityRequestSchema = z.object({
  submission_id: z.string().min(1),
  inputs: EligibilityInputsSchema,
});

// ─── Principal ────────────────────────────────────────────────────────────────

export const PrincipalSchema = z.object({
  id: z.string(),
  role: PrincipalRoleSchema,
  identity: z.string(),
});
