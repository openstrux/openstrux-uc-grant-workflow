
import { z } from "zod";
import {
  ProposalStatusSchema,
  EligibilityStatusSchema,
  CallStatusSchema,
  MeetsEuropeanDimensionSchema,
  PrincipalRoleSchema,
  EligibilityInputsSchema,
  CallSchema,
  SubmissionSchema,
  ProposalVersionSchema,
  ApplicantIdentitySchema,
  BlindedPacketSchema,
  BlindedPacketContentSchema,
  EligibilityRecordSchema,
  AuditEventSchema,
  PrincipalSchema,
  IntakeRequestSchema,
  EligibilityRequestSchema,
} from "../schemas/index";

// ─── Enumeration types ────────────────────────────────────────────────────────

export type ProposalStatus = z.infer<typeof ProposalStatusSchema>;
export type EligibilityStatus = z.infer<typeof EligibilityStatusSchema>;
export type CallStatus = z.infer<typeof CallStatusSchema>;
export type MeetsEuropeanDimension = z.infer<typeof MeetsEuropeanDimensionSchema>;
export type PrincipalRole = z.infer<typeof PrincipalRoleSchema>;

// ─── Entity types ─────────────────────────────────────────────────────────────

export type EligibilityInputs = z.infer<typeof EligibilityInputsSchema>;
export type Call = z.infer<typeof CallSchema>;
export type Submission = z.infer<typeof SubmissionSchema>;
export type ProposalVersion = z.infer<typeof ProposalVersionSchema>;
export type ApplicantIdentity = z.infer<typeof ApplicantIdentitySchema>;
export type BlindedPacketContent = z.infer<typeof BlindedPacketContentSchema>;
export type BlindedPacket = z.infer<typeof BlindedPacketSchema>;
export type EligibilityRecord = z.infer<typeof EligibilityRecordSchema>;
export type AuditEvent = z.infer<typeof AuditEventSchema>;
export type Principal = z.infer<typeof PrincipalSchema>;

// ─── API types ────────────────────────────────────────────────────────────────

export type IntakeRequest = z.infer<typeof IntakeRequestSchema>;
export type EligibilityRequest = z.infer<typeof EligibilityRequestSchema>;

// ─── Access types ─────────────────────────────────────────────────────────────

export type Operation = "read" | "write" | "delete";

export type ResourceType =
  | "Submission"
  | "ProposalVersion"
  | "ApplicantIdentity"
  | "BlindedPacket"
  | "EligibilityRecord"
  | "AuditEvent"
  | "Call";

export interface AccessContext {
  principal: Principal;
  resourceType: ResourceType;
  operation: Operation;
  resourceId?: string;
  /** The applicant_alias on a Submission, used for scoping applicant access */
  resourceOwnerId?: string;
  /** Current status of the submission, used for state-based access */
  submissionStatus?: ProposalStatus;
}

export interface AccessDecision {
  allowed: boolean;
  reason: string;
}

// ─── Service result types ─────────────────────────────────────────────────────

export interface SubmitProposalResult {
  submission: Submission;
  proposalVersion: ProposalVersion;
  blindedPacket: BlindedPacket | null;
  auditEvent: AuditEvent;
}

export interface EligibilityResult {
  record: EligibilityRecord;
  submission: Submission;
  auditEvent: AuditEvent;
}

export interface EligibilityEvaluationResult {
  status: EligibilityStatus;
  failure_reasons: string[];
  active_rules: string[];
}
