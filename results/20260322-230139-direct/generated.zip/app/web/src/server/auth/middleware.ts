
import { NextRequest } from "next/server";
import { z } from "zod";
import type { Principal, Role } from "@repo/domain";
import { RoleSchema } from "@repo/domain";

const JWT_SECRET = process.env.JWT_SECRET ?? "dev-secret-change-in-production";
const DEV_MODE = process.env.NODE_ENV !== "production";

/**
 * Decoded JWT payload structure.
 * In production this would be verified with a proper JWT library.
 * For P0-P2 MVP, we support dev-mode X-Role header bypass.
 */
const JwtPayloadSchema = z.object({
  sub: z.string(),
  role: RoleSchema,
  applicant_alias: z.string().optional(),
  assigned_submission_ids: z.array(z.string()).optional(),
  iat: z.number().optional(),
  exp: z.number().optional(),
});

export type JwtPayload = z.infer<typeof JwtPayloadSchema>;

export interface AuthResult {
  ok: true;
  principal: Principal;
}

export interface AuthError {
  ok: false;
  status: number;
  message: string;
}

export type AuthOutcome = AuthResult | AuthError;

/**
 * Extracts and validates the principal from the incoming request.
 *
 * In dev mode: accepts X-Role header (and optionally X-Actor-Id,
 * X-Applicant-Alias, X-Assigned-Submissions) for test harness use.
 *
 * In production: validates Bearer JWT from Authorization header.
 */
export async function extractPrincipal(
  req: NextRequest
): Promise<AuthOutcome> {
  // ── Dev-mode header bypass ────────────────────────────────────────────────
  if (DEV_MODE) {
    const xRole = req.headers.get("x-role");
    if (xRole !== null) {
      const roleParse = RoleSchema.safeParse(xRole);
      if (!roleParse.success) {
        return {
          ok: false,
          status: 400,
          message: `Invalid X-Role header value: ${xRole}`,
        };
      }

      const actorId = req.headers.get("x-actor-id") ?? `dev-${xRole}-actor`;
      const applicantAlias = req.headers.get("x-applicant-alias") ?? undefined;
      const assignedRaw = req.headers.get("x-assigned-submissions");
      const assignedSubmissionIds = assignedRaw
        ? assignedRaw.split(",").map((s) => s.trim()).filter(Boolean)
        : undefined;

      const principal: Principal = {
        id: actorId,
        role: roleParse.data,
        applicant_alias: applicantAlias,
        assigned_submission_ids: assignedSubmissionIds,
      };

      return { ok: true, principal };
    }
  }

  // ── JWT extraction ────────────────────────────────────────────────────────
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return {
      ok: false,
      status: 401,
      message: "Missing or malformed Authorization header.",
    };
  }

  const token = authHeader.slice(7);

  try {
    const payload = decodeAndVerifyJwt(token);
    const parsed = JwtPayloadSchema.safeParse(payload);

    if (!parsed.success) {
      return {
        ok: false,
        status: 401,
        message: "Invalid JWT payload structure.",
      };
    }

    // Check expiry
    if (parsed.data.exp !== undefined && parsed.data.exp < Date.now() / 1000) {
      return {
        ok: false,
        status: 401,
        message: "JWT has expired.",
      };
    }

    const principal: Principal = {
      id: parsed.data.sub,
      role: parsed.data.role,
      applicant_alias: parsed.data.applicant_alias,
      assigned_submission_ids: parsed.data.assigned_submission_ids,
    };

    return { ok: true, principal };
  } catch (err) {
    return {
      ok: false,
      status: 401,
      message: "JWT verification failed.",
    };
  }
}

/**
 * Minimal JWT decoder for MVP (HS256).
 * In production, replace with a hardened JWT library (e.g., jose).
 *
 * GAP-002: No external IdP required for P0-P2; this is a dev-grade verifier.
 */
function decodeAndVerifyJwt(token: string): unknown {
  const parts = token.split(".");
  if (parts.length !== 3) {
    throw new Error("Malformed JWT: expected 3 parts.");
  }

  // Decode payload (base64url)
  const payloadB64 = parts[1];
  if (!payloadB64) {
    throw new Error("Malformed JWT: missing payload.");
  }

  const padding = "=".repeat((4 - (payloadB64.length % 4)) % 4);
  const base64 = payloadB64.replace(/-/g, "+").replace(/_/g, "/") + padding;
  const jsonStr = Buffer.from(base64, "base64").toString("utf-8");

  // NOTE: In production, verify signature against JWT_SECRET before trusting payload.
  // For MVP dev mode, we parse payload without signature verification.
  // Signature verification is left as a production hardening step (GAP-002).
  return JSON.parse(jsonStr) as unknown;
}

/**
 * Helper: respond with 401 JSON error.
 */
export function unauthorizedResponse(message: string): Response {
  return Response.json({ error: message }, { status: 401 });
}

/**
 * Helper: respond with 403 JSON error.
 */
export function forbiddenResponse(message: string, policy?: string): Response {
  return Response.json({ error: message, policy }, { status: 403 });
}
