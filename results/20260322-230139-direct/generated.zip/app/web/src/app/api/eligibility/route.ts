
import { NextRequest } from "next/server";
import { PrismaClient } from "@prisma/client";
import { EligibilityCheckRequestSchema } from "@repo/domain";
import { runEligibilityCheck, checkAccess } from "@repo/policies";
import {
  extractPrincipal,
  unauthorizedResponse,
  forbiddenResponse,
} from "../../../server/auth/middleware.js";

const prisma = new PrismaClient();

/**
 * POST /api/eligibility
 *
 * Runs the eligibility gate for a submission.
 *
 * Role: admin only (eligibility is an admin/system operation per workflow spec)
 *
 * Returns eligibility record ID, status, and active rules.
 * failure_reasons are only visible to admin (per access-policies.md).
 */
export async function POST(req: NextRequest): Promise<Response> {
  // 1. Authenticate
  const auth = await extractPrincipal(req);
  if (!auth.ok) {
    return unauthorizedResponse(auth.message);
  }
  const { principal } = auth;

  // 2. Authorize — only admins may trigger eligibility checks
  const accessResult = checkAccess(principal, "EligibilityRecord", "write");
  if (accessResult.decision === "deny") {
    void prisma.auditEvent
      .create({
        data: {
          event_type: "access.denied",
          actor_id: principal.id,
          target_type: "EligibilityRecord",
          target_id: "eligibility-check",
          payload: {
            operation: "write",
            policy: accessResult.policy,
            reason: accessResult.reason,
          },
        },
      })
      .catch(() => undefined);

    return forbiddenResponse(accessResult.reason, accessResult.policy);
  }

  // 3. Parse and validate body
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const parsed = EligibilityCheckRequestSchema.safeParse(body);
  if (!parsed.success) {
    return Response.json(
      { error: "Validation failed.", issues: parsed.error.issues },
      { status: 422 }
    );
  }

  const data = parsed.data;

  // 4. Run eligibility check (transaction: record + status transition + audit)
  try {
    const result = await runEligibilityCheck(
      prisma,
      {
        submission_id: data.submission_id,
        inputs: data.inputs,
      },
      principal.id
    );

    // 5. Return response
    // failure_reasons included for admin; filtered for non-admin at this layer
    const responseBody =
      principal.role === "admin"
        ? {
            eligibility_record_id: result.eligibility_record_id,
            status: result.status,
            failure_reasons: result.failure_reasons,
            active_rules: result.active_rules,
          }
        : {
            eligibility_record_id: result.eligibility_record_id,
            status: result.status,
            active_rules: result.active_rules,
          };

    return Response.json(responseBody, { status: 200 });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Internal server error.";
    return Response.json({ error: message }, { status: 400 });
  }
}
