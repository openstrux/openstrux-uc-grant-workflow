
/**
 * P4 — Clarification
 * Status: stub (not implemented in v0.6.0 MVP)
 */
export async function GET(): Promise<Response> {
  return Response.json(
    { error: "Clarification feature is not implemented in this version (P4)." },
    { status: 501 }
  );
}

export async function POST(): Promise<Response> {
  return Response.json(
    { error: "Clarification feature is not implemented in this version (P4)." },
    { status: 501 }
  );
}
