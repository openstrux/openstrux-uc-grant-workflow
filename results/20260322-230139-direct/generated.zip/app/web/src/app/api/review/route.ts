
/**
 * P3 — Review
 * Status: stub (not implemented in v0.6.0 MVP)
 */
export async function GET(): Promise<Response> {
  return Response.json(
    { error: "Review feature is not implemented in this version (P3)." },
    { status: 501 }
  );
}

export async function POST(): Promise<Response> {
  return Response.json(
    { error: "Review feature is not implemented in this version (P3)." },
    { status: 501 }
  );
}
