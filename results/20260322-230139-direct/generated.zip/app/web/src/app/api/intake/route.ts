
import { NextRequest } from "next/server";
import { PrismaClient } from "@prisma/client";
import { IntakeRequestSchema } from "@repo/domain";
import { submitProposal } from "@repo/policies";
import { checkAccess } from "@repo/policies";
import {
  extractPrincipal,
  unauthorizedResponse,
  forbiddenResponse,
} from "../../../server/auth/middleware.js";

const prisma = new PrismaClient();

/**
 * POST /api/intake
 *
 * Creates a new submission (proposal version + applicant identity + blinded packet).
 *
 * Role: applicant (own submission) | admin
 *
 * Returns the submission ID, proposal version ID, and blinded packet ID.
 * Never returns ApplicantIdentity fields in the response.
 */
export async function POST(req: NextRequest): Promise<Response> {
  // 1. Authenticate
  const auth = await extractPrincipal(req);
  if (!auth.ok) {
    return unauthorizedResponse(auth.message);
  }
  const { principal } = auth;

  // 2. Authorize — only applicants and admins may submit
  const accessResult = checkAccess(principal, "Submission", "write");
  if (accessResult.decision === "deny") {
    // Audit the denial (fire-and-forget for access denials)
    void prisma.auditEvent
      .create({
        data: {
          event_type: "access.denied",
          actor_id: principal.id,
          target_type: "Submission",
          target_id: "intake",
          payload: {
            operation: "write",
            policy: accessResult.policy,
            reason: accessResult.reason,
          },
        },
      })
      .catch(() => undefined);

    return forbiddenResponse(accessResult.reason, accessResult.policy);
  }

  // 3. Parse and validate body
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const parsed = IntakeRequestSchema.safeParse(body);
  if (!parsed.success) {
    return Response.json(
      { error: "Validation failed.", issues: parsed.error.issues },
      { status: 422 }
    );
  }

  const data = parsed.data;

  // 4. For applicants: enforce they can only submit under their own alias
  const applicantAlias =
    principal.role === "applicant"
      ? (principal.applicant_alias ?? principal.id)
      : (principal.applicant_alias ?? principal.id);

  // 5. Submit proposal (transaction: submission + version + identity + blinded packet + audit)
  try {
    const result = await submitProposal(
      prisma,
      {
        call_id: data.call_id,
        applicant_alias: applicantAlias,
        title: data.title,
        abstract: data.abstract,
        requested_budget_k_eur: data.requested_budget_k_eur,
        budget_usage: data.budget_usage,
        tasks_breakdown: data.tasks_breakdown,
        attachments_meta: data.attachments_meta,
        // Identity fields — kept in separate model, never returned to non-admin
        legal_name: data.legal_name,
        email: data.email,
        country: data.country,
        organisation: data.organisation,
      },
      principal.id
    );

    // 6. Return response — never include identity fields
    return Response.json(
      {
        submission_id: result.submission_id,
        proposal_version_id: result.proposal_version_id,
        blinded_packet_id: result.blinded_packet_id,
        status: result.status,
      },
      { status: 201 }
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Internal server error.";
    return Response.json({ error: message }, { status: 400 });
  }
}
