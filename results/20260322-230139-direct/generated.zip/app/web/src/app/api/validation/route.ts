
/**
 * P5 — Validation
 * Status: stub (not implemented in v0.6.0 MVP)
 */
export async function GET(): Promise<Response> {
  return Response.json(
    { error: "Validation feature is not implemented in this version (P5)." },
    { status: 501 }
  );
}

export async function POST(): Promise<Response> {
  return Response.json(
    { error: "Validation feature is not implemented in this version (P5)." },
    { status: 501 }
  );
}
