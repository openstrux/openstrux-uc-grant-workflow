
import { z } from "zod";

// ── Enumerations ──────────────────────────────────────────────────────────────

export const ProposalStatusSchema = z.enum([
  "draft",
  "submitted",
  "eligibility_failed",
  "eligible",
  "under_review",
  "clarification_requested",
  "revised",
  "validation_pending",
  "selected",
  "rejected",
]);

export const EligibilityStatusSchema = z.enum([
  "eligible",
  "ineligible",
  "pending",
]);

export const CallStatusSchema = z.enum([
  "draft",
  "open",
  "closed",
  "archived",
]);

export const MeetsEuropeanDimensionSchema = z.enum([
  "true",
  "false",
  "not_applicable",
]);

export const RoleSchema = z.enum([
  "applicant",
  "admin",
  "reviewer",
  "validator",
  "auditor",
]);

// ── EligibilityInputs ─────────────────────────────────────────────────────────

export const EligibilityInputsSchema = z.object({
  submitted_in_english: z.boolean(),
  aligned_with_call: z.boolean(),
  primary_objective_is_rd: z.boolean(),
  meets_european_dimension: MeetsEuropeanDimensionSchema,
  requested_budget_k_eur: z.number().positive(),
  first_time_applicant_in_programme: z.boolean(),
});

// ── Call ──────────────────────────────────────────────────────────────────────

export const CallSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  description: z.string(),
  open_date: z.coerce.date(),
  close_date: z.coerce.date(),
  status: CallStatusSchema,
  max_budget_k_eur: z.number().positive(),
  reviewer_policy_version: z.string(),
  enabled_eligibility_checks: z.array(z.string()),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

export const CreateCallSchema = CallSchema.omit({
  id: true,
  created_at: true,
  updated_at: true,
});

// ── Submission ────────────────────────────────────────────────────────────────

export const SubmissionSchema = z.object({
  id: z.string().min(1),
  call_id: z.string().min(1),
  applicant_alias: z.string().min(1),
  status: ProposalStatusSchema,
  submitted_at: z.coerce.date().nullable().optional(),
  created_at: z.coerce.date().optional(),
  updated_at: z.coerce.date().optional(),
});

// ── ProposalVersion ───────────────────────────────────────────────────────────

export const ProposalVersionSchema = z.object({
  id: z.string().min(1),
  submission_id: z.string().min(1),
  version_number: z.number().int().positive(),
  is_effective: z.boolean(),
  title: z.string().min(1),
  abstract: z.string().min(1),
  requested_budget_k_eur: z.number().positive(),
  budget_usage: z.string().min(1),
  tasks_breakdown: z.unknown(),
  attachments_meta: z.unknown(),
  created_at: z.coerce.date().optional(),
  updated_at: z.coerce.date().optional(),
});

// ── ApplicantIdentity ─────────────────────────────────────────────────────────

export const ApplicantIdentitySchema = z.object({
  id: z.string().min(1),
  submission_id: z.string().min(1),
  legal_name: z.string().min(1),
  email: z.string().email(),
  country: z.string().min(1),
  organisation: z.string().min(1),
  created_at: z.coerce.date().optional(),
  updated_at: z.coerce.date().optional(),
});

// ── BlindedPacket ─────────────────────────────────────────────────────────────

export const BlindedPacketContentSchema = z.object({
  submission_id: z.string().min(1),
  version_number: z.number().int().positive(),
  title: z.string(),
  abstract: z.string(),
  requested_budget_k_eur: z.number(),
  budget_usage: z.string(),
  tasks_breakdown: z.unknown(),
  attachments_meta: z.unknown(),
});

export const BlindedPacketSchema = z.object({
  id: z.string().min(1),
  proposal_version_id: z.string().min(1),
  content: BlindedPacketContentSchema,
  created_at: z.coerce.date().optional(),
  updated_at: z.coerce.date().optional(),
});

// ── EligibilityRecord ─────────────────────────────────────────────────────────

export const EligibilityRecordSchema = z.object({
  id: z.string().min(1),
  submission_id: z.string().min(1),
  status: EligibilityStatusSchema,
  inputs: EligibilityInputsSchema,
  active_rules: z.array(z.string()),
  failure_reasons: z.array(z.string()),
  evaluated_at: z.coerce.date(),
  created_at: z.coerce.date().optional(),
  updated_at: z.coerce.date().optional(),
});

// ── AuditEvent ────────────────────────────────────────────────────────────────

export const AuditEventSchema = z.object({
  id: z.string().min(1),
  event_type: z.string(),
  actor_id: z.string(),
  target_type: z.string(),
  target_id: z.string(),
  payload: z.record(z.string(), z.unknown()),
  timestamp: z.coerce.date().optional(),
});

// ── Intake request ────────────────────────────────────────────────────────────

export const IntakeRequestSchema = z.object({
  call_id: z.string().min(1),
  title: z.string().min(1),
  abstract: z.string().min(1),
  requested_budget_k_eur: z.number().positive(),
  budget_usage: z.string().min(1),
  tasks_breakdown: z.unknown(),
  attachments_meta: z.array(z.unknown()).optional().default([]),
  legal_name: z.string().min(1),
  email: z.string().email(),
  country: z.string().min(1),
  organisation: z.string().min(1),
});

// ── Eligibility check request ─────────────────────────────────────────────────

export const EligibilityCheckRequestSchema = z.object({
  submission_id: z.string().min(1),
  inputs: EligibilityInputsSchema,
});
