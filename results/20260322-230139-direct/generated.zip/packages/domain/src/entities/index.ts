
import { z } from "zod";
import {
  CallSchema,
  SubmissionSchema,
  ProposalVersionSchema,
  ApplicantIdentitySchema,
  BlindedPacketSchema,
  BlindedPacketContentSchema,
  EligibilityRecordSchema,
  AuditEventSchema,
  EligibilityInputsSchema,
  ProposalStatusSchema,
  EligibilityStatusSchema,
  CallStatusSchema,
  MeetsEuropeanDimensionSchema,
  RoleSchema,
} from "../schemas/index.js";

export type Call = z.infer<typeof CallSchema>;
export type Submission = z.infer<typeof SubmissionSchema>;
export type ProposalVersion = z.infer<typeof ProposalVersionSchema>;
export type ApplicantIdentity = z.infer<typeof ApplicantIdentitySchema>;
export type BlindedPacket = z.infer<typeof BlindedPacketSchema>;
export type BlindedPacketContent = z.infer<typeof BlindedPacketContentSchema>;
export type EligibilityRecord = z.infer<typeof EligibilityRecordSchema>;
export type AuditEvent = z.infer<typeof AuditEventSchema>;
export type EligibilityInputs = z.infer<typeof EligibilityInputsSchema>;

export type ProposalStatus = z.infer<typeof ProposalStatusSchema>;
export type EligibilityStatus = z.infer<typeof EligibilityStatusSchema>;
export type CallStatus = z.infer<typeof CallStatusSchema>;
export type MeetsEuropeanDimension = z.infer<typeof MeetsEuropeanDimensionSchema>;
export type Role = z.infer<typeof RoleSchema>;

export interface Principal {
  id: string;
  role: Role;
  applicant_alias?: string;
  assigned_submission_ids?: string[];
}

export type ResourceType =
  | "Submission"
  | "ProposalVersion"
  | "ApplicantIdentity"
  | "BlindedPacket"
  | "EligibilityRecord"
  | "Call"
  | "AuditEvent";

export type Operation = "read" | "write" | "delete";

export interface AccessContext {
  submission_id?: string;
  applicant_alias?: string;
  proposal_status?: ProposalStatus;
}

export interface AccessResult {
  allowed: boolean;
  policy: string;
  reason: string;
}

export type EligibilityCheckName =
  | "submittedInEnglish"
  | "alignedWithCall"
  | "primaryObjectiveIsRd"
  | "meetsEuropeanDimension"
  | "requestedBudgetKEur"
  | "firstTimeApplicantInProgramme";

export interface EligibilityRuleSet {
  version: string;
  enabled_checks?: EligibilityCheckName[];
  enabledChecks?: EligibilityCheckName[];
  checks?: EligibilityCheckName[];
  rules?: EligibilityCheckName[];
  activeChecks?: EligibilityCheckName[];
  max_budget_k_eur?: number;
  maxBudgetKEur?: number;
  maxBudget?: number;
}

export interface EligibilityResult {
  status: EligibilityStatus;
  failure_reasons: string[];
  active_rules: string[];
  inputs: EligibilityInputs;
  rule_set_version: string;
}
