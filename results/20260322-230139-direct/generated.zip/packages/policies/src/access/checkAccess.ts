
import type { Principal, Operation, AccessContext, AccessResult, ProposalStatus } from "@repo/domain";

function normalizeResource(resource: string): string {
  const map: Record<string, string> = {
    applicant_identity: "ApplicantIdentity",
    proposal_version: "ProposalVersion",
    blinded_packet: "BlindedPacket",
    eligibility_record: "EligibilityRecord",
    audit_event: "AuditEvent",
    submission: "Submission",
    call: "Call",
  };
  return map[resource.toLowerCase().replace(/([A-Z])/g, "_$1").toLowerCase()] ?? map[resource] ?? resource;
}

export function checkAccess(
  principal: Principal,
  resource: string,
  operation: Operation,
  context?: AccessContext
): AccessResult {
  const res = normalizeResource(resource);

  // HARD DENY — reviewer + identity, regardless of operation
  if (principal.role === "reviewer" && res === "ApplicantIdentity") {
    return {
      allowed: false,
      policy: "deny-identity-to-reviewer",
      reason: "Reviewer access to ApplicantIdentity (identity data) is explicitly denied.",
    };
  }

  if (principal.role === "auditor") {
    if (res === "AuditEvent" && operation === "read") {
      return { allowed: true, policy: "auditor-audit-log", reason: "Auditors may read audit events." };
    }
    return { allowed: false, policy: "auditor-audit-log", reason: "Auditors may only read AuditEvent records." };
  }

  if (principal.role === "admin") {
    return { allowed: true, policy: "admin-all", reason: "Admins have full access to all resources." };
  }

  if (principal.role === "applicant") {
    if (res === "BlindedPacket") {
      return { allowed: false, policy: "applicant-own-proposals", reason: "Applicants cannot access BlindedPackets." };
    }
    if (res === "EligibilityRecord") {
      return { allowed: false, policy: "applicant-own-proposals", reason: "Applicants cannot access EligibilityRecord." };
    }
    if (res === "Submission") {
      if (context?.applicant_alias !== undefined && context.applicant_alias !== principal.applicant_alias) {
        return { allowed: false, policy: "applicant-own-proposals", reason: "Applicants may only access their own submissions." };
      }
      if (context?.applicant_alias === undefined) {
        return { allowed: false, policy: "applicant-own-proposals", reason: "Applicants may only access their own submissions." };
      }
    }
    if (operation === "write" && context?.proposal_status !== undefined) {
      const writable: ProposalStatus[] = ["draft", "clarification_requested"];
      if (!writable.includes(context.proposal_status)) {
        return { allowed: false, policy: "applicant-own-proposals", reason: `Applicants cannot write in status: ${context.proposal_status}.` };
      }
    }
    return { allowed: true, policy: "applicant-own-proposals", reason: "Applicant accessing own resource." };
  }

  if (principal.role === "reviewer") {
    if (operation !== "read") {
      return { allowed: false, policy: "reviewer-blinded-assigned", reason: "Reviewers may only perform read operations." };
    }
    if (res === "BlindedPacket") {
      const assignedIds = principal.assigned_submission_ids;
      if (assignedIds !== undefined && context?.submission_id !== undefined) {
        if (!assignedIds.includes(context.submission_id)) {
          return { allowed: false, policy: "reviewer-blinded-assigned", reason: "Reviewer is not assigned to this submission." };
        }
      }
      if (context?.proposal_status !== undefined) {
        const accessible: ProposalStatus[] = ["under_review", "clarification_requested", "revised", "validation_pending", "selected"];
        if (!accessible.includes(context.proposal_status)) {
          return { allowed: false, policy: "reviewer-blinded-assigned", reason: `Reviewers cannot access proposals in status: ${context.proposal_status}.` };
        }
      }
      return { allowed: true, policy: "reviewer-blinded-assigned", reason: "Reviewer accessing assigned blinded packet." };
    }
    return { allowed: false, policy: "reviewer-blinded-assigned", reason: `Reviewers cannot access resource: ${res}.` };
  }

  if (principal.role === "validator") {
    if (res === "BlindedPacket" && operation === "read") {
      if (context?.proposal_status === "validation_pending" || context?.proposal_status === "selected") {
        return { allowed: true, policy: "validator-shortlisted", reason: "Validator accessing shortlisted blinded packet." };
      }
    }
    return { allowed: false, policy: "validator-shortlisted", reason: "Validators may only read BlindedPackets of shortlisted proposals." };
  }

  return { allowed: false, policy: "default-deny", reason: "No policy granted access." };
}
