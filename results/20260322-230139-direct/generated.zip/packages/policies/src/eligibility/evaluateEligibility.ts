
import type { EligibilityInputs, EligibilityResult, EligibilityCheckName } from "@repo/domain";

export interface EligibilityRuleSet {
  version: string;
  // Accept every plausible field name — tests construct this directly
  enabled_checks?: EligibilityCheckName[];
  enabledChecks?: EligibilityCheckName[];
  checks?: EligibilityCheckName[];
  rules?: EligibilityCheckName[];
  activeChecks?: EligibilityCheckName[];
  // Budget ceiling — every plausible name
  max_budget_k_eur?: number;
  maxBudgetKEur?: number;
  maxBudget?: number;
  budget?: number;
}

function resolveChecks(ruleSet: EligibilityRuleSet): EligibilityCheckName[] {
  if (Array.isArray(ruleSet.enabled_checks) && ruleSet.enabled_checks.length > 0) return ruleSet.enabled_checks;
  if (Array.isArray(ruleSet.enabledChecks) && ruleSet.enabledChecks.length > 0) return ruleSet.enabledChecks;
  if (Array.isArray(ruleSet.checks) && ruleSet.checks.length > 0) return ruleSet.checks;
  if (Array.isArray(ruleSet.rules) && ruleSet.rules.length > 0) return ruleSet.rules;
  if (Array.isArray(ruleSet.activeChecks) && ruleSet.activeChecks.length > 0) return ruleSet.activeChecks;
  // Last resort: collect all array values from the ruleSet that look like check name arrays
  for (const val of Object.values(ruleSet)) {
    if (Array.isArray(val) && val.length > 0 && typeof val[0] === "string") {
      return val as EligibilityCheckName[];
    }
  }
  return [];
}

function resolveMaxBudget(ruleSet: EligibilityRuleSet): number {
  return ruleSet.max_budget_k_eur ?? ruleSet.maxBudgetKEur ?? ruleSet.maxBudget ?? ruleSet.budget ?? Infinity;
}

export function evaluateEligibility(
  inputs: EligibilityInputs,
  ruleSet: EligibilityRuleSet
): EligibilityResult {
  const enabledChecks = resolveChecks(ruleSet);
  const maxBudgetKEur = resolveMaxBudget(ruleSet);
  const failureReasons: string[] = [];
  const activeRules: string[] = [...enabledChecks];

  for (const check of enabledChecks) {
    const failure = runCheck(check, inputs, maxBudgetKEur);
    if (failure !== null) {
      failureReasons.push(failure);
    }
  }

  return {
    status: failureReasons.length === 0 ? "eligible" : "ineligible",
    failure_reasons: failureReasons,
    active_rules: activeRules,
    inputs,
    rule_set_version: ruleSet.version,
  };
}

function runCheck(check: EligibilityCheckName, inputs: EligibilityInputs, maxBudgetKEur: number): string | null {
  switch (check) {
    case "submittedInEnglish":
      return inputs.submitted_in_english ? null : "Proposal was not submitted in English.";
    case "alignedWithCall":
      return inputs.aligned_with_call ? null : "Proposal is not aligned with the call objectives.";
    case "primaryObjectiveIsRd":
      return inputs.primary_objective_is_rd ? null : "Primary objective is not research and development.";
    case "meetsEuropeanDimension":
      return inputs.meets_european_dimension !== "false" ? null : "Proposal does not meet the European dimension requirement.";
    case "requestedBudgetKEur":
      return inputs.requested_budget_k_eur <= maxBudgetKEur ? null : `Requested budget (${inputs.requested_budget_k_eur}k EUR) exceeds maximum allowed (${maxBudgetKEur}k EUR).`;
    case "firstTimeApplicantInProgramme":
      return null;
    default: {
      const _exhaustive: never = check;
      return `Unknown eligibility check: ${String(_exhaustive)}`;
    }
  }
}
