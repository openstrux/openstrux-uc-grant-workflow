
/**
 * Maps a ProposalVersion to a BlindedPacketContent.
 *
 * INVARIANT: No identity field (legal_name, email, country, organisation,
 * applicant_alias) may be present in the output. This is enforced structurally
 * by only extracting an explicit allowlist of fields.
 */

import type { BlindedPacketContent } from "@repo/domain";

interface ProposalVersionInput {
  submission_id: string;
  version_number: number;
  title: string;
  abstract: string;
  requested_budget_k_eur: number;
  budget_usage: string;
  tasks_breakdown: unknown;
  attachments_meta: unknown[];
}

/**
 * Strips all identity fields and returns a reviewer-safe blinded packet content.
 * Uses explicit field selection (allowlist) — never spreads the full object.
 */
export function mapToBlindedPacketContent(
  version: ProposalVersionInput
): BlindedPacketContent {
  return {
    submission_id: version.submission_id,
    version_number: version.version_number,
    title: version.title,
    abstract: version.abstract,
    requested_budget_k_eur: version.requested_budget_k_eur,
    budget_usage: version.budget_usage,
    tasks_breakdown: version.tasks_breakdown,
    attachments_meta: version.attachments_meta,
  };
}
