
import { PrismaClient } from "@prisma/client";
import type {
  EligibilityInputs,
  EligibilityCheckName,
} from "@repo/domain";
import { evaluateEligibility } from "../eligibility/evaluateEligibility.js";

export interface RunEligibilityCheckInput {
  submission_id: string;
  inputs: EligibilityInputs;
}

export interface RunEligibilityCheckResult {
  eligibility_record_id: string;
  status: "eligible" | "ineligible" | "pending";
  failure_reasons: string[];
  active_rules: string[];
}

export async function runEligibilityCheck(
  prisma: PrismaClient,
  input: RunEligibilityCheckInput,
  actorId: string
): Promise<RunEligibilityCheckResult> {
  return prisma.$transaction(async (tx) => {
    const submission = await tx.submission.findUnique({
      where: { id: input.submission_id },
      include: { call: true },
    });

    if (!submission) {
      throw new Error(`Submission not found: ${input.submission_id}`);
    }

    if (submission.status !== "submitted") {
      throw new Error(
        `Eligibility check can only run on submitted proposals. Current status: ${submission.status}`
      );
    }

    const call = submission.call;

    const result = evaluateEligibility(input.inputs, {
      version: `call:${call.id}:v1`,
      enabled_checks: call.enabled_eligibility_checks as EligibilityCheckName[],
      max_budget_k_eur: call.max_budget_k_eur,
    });

    const eligibilityRecord = await tx.eligibilityRecord.create({
      data: {
        submission_id: input.submission_id,
        status: result.status,
        inputs: result.inputs as object,
        active_rules: result.active_rules,
        failure_reasons: result.failure_reasons,
        evaluated_at: new Date(),
      },
    });

    const nextStatus =
      result.status === "eligible" ? "eligible" : "eligibility_failed";

    await tx.submission.update({
      where: { id: input.submission_id },
      data: { status: nextStatus },
    });

    await tx.auditEvent.create({
      data: {
        event_type: "eligibility.evaluated",
        actor_id: actorId,
        target_type: "Submission",
        target_id: input.submission_id,
        payload: {
          eligibility_record_id: eligibilityRecord.id,
          previous_status: "submitted",
          next_status: nextStatus,
          eligibility_status: result.status,
          failure_reasons: result.failure_reasons,
          active_rules: result.active_rules,
          rule_set_version: result.rule_set_version,
        },
      },
    });

    return {
      eligibility_record_id: eligibilityRecord.id,
      status: result.status,
      failure_reasons: result.failure_reasons,
      active_rules: result.active_rules,
    };
  });
}
