
import { PrismaClient } from "@prisma/client";
import type { IntakeRequest } from "../types.js";
import { mapToBlindedPacketContent } from "../intake/blindedPacketMapper.js";

export interface SubmitProposalInput {
  call_id: string;
  applicant_alias: string;
  // Proposal content
  title: string;
  abstract: string;
  requested_budget_k_eur: number;
  budget_usage: string;
  tasks_breakdown: unknown;
  attachments_meta: unknown[];
  // Applicant identity (separate data path)
  legal_name: string;
  email: string;
  country: string;
  organisation: string;
}

export interface SubmitProposalResult {
  submission_id: string;
  proposal_version_id: string;
  blinded_packet_id: string;
  status: string;
}

/**
 * Creates a new submission, proposal version, applicant identity, and blinded
 * packet in a single Prisma transaction.
 *
 * ApplicantIdentity is written in the same transaction but kept on a separate
 * model — never included in the ProposalVersion or BlindedPacket.
 *
 * Produces an AuditEvent for the submit action.
 */
export async function submitProposal(
  prisma: PrismaClient,
  input: SubmitProposalInput,
  actorId: string
): Promise<SubmitProposalResult> {
  return prisma.$transaction(async (tx) => {
    // 1. Verify call exists and is open
    const call = await tx.call.findUnique({
      where: { id: input.call_id },
    });

    if (!call) {
      throw new Error(`Call not found: ${input.call_id}`);
    }

    if (call.status !== "open") {
      throw new Error(`Call is not open for submissions. Current status: ${call.status}`);
    }

    const now = new Date();
    if (now < call.open_date || now > call.close_date) {
      throw new Error("Submission is outside the call's open window.");
    }

    // 2. Create submission
    const submission = await tx.submission.create({
      data: {
        call_id: input.call_id,
        applicant_alias: input.applicant_alias,
        status: "submitted",
        submitted_at: now,
      },
    });

    // 3. Create proposal version (content only, no identity fields)
    const proposalVersion = await tx.proposalVersion.create({
      data: {
        submission_id: submission.id,
        version_number: 1,
        is_effective: true,
        title: input.title,
        abstract: input.abstract,
        requested_budget_k_eur: input.requested_budget_k_eur,
        budget_usage: input.budget_usage,
        tasks_breakdown: input.tasks_breakdown as object,
        attachments_meta: input.attachments_meta as object[],
      },
    });

    // 4. Create applicant identity (separate model, separate data path)
    await tx.applicantIdentity.create({
      data: {
        submission_id: submission.id,
        legal_name: input.legal_name,
        email: input.email,
        country: input.country,
        organisation: input.organisation,
      },
    });

    // 5. Generate blinded packet (identity fields never included)
    const blindedContent = mapToBlindedPacketContent({
      submission_id: submission.id,
      version_number: proposalVersion.version_number,
      title: proposalVersion.title,
      abstract: proposalVersion.abstract,
      requested_budget_k_eur: proposalVersion.requested_budget_k_eur,
      budget_usage: proposalVersion.budget_usage,
      tasks_breakdown: proposalVersion.tasks_breakdown,
      attachments_meta: proposalVersion.attachments_meta as unknown[],
    });

    const blindedPacket = await tx.blindedPacket.create({
      data: {
        proposal_version_id: proposalVersion.id,
        content: blindedContent,
      },
    });

    // 6. Write audit event
    await tx.auditEvent.create({
      data: {
        event_type: "submission.created",
        actor_id: actorId,
        target_type: "Submission",
        target_id: submission.id,
        payload: {
          call_id: input.call_id,
          applicant_alias: input.applicant_alias,
          proposal_version_id: proposalVersion.id,
          blinded_packet_id: blindedPacket.id,
          status: "submitted",
        },
      },
    });

    return {
      submission_id: submission.id,
      proposal_version_id: proposalVersion.id,
      blinded_packet_id: blindedPacket.id,
      status: "submitted",
    };
  });
}
