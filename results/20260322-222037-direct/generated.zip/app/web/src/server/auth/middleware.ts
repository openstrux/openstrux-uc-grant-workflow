
import { NextRequest } from "next/server";
import { z } from "zod";
import type { Principal } from "@repo/domain";
import { PrincipalRoleSchema } from "@repo/domain";

// ─── JWT payload shape ────────────────────────────────────────────────────────

const JwtPayloadSchema = z.object({
  sub: z.string().min(1),
  role: PrincipalRoleSchema,
  identity: z.string().optional(),
  assigned_submissions: z.array(z.string()).optional(),
});

type JwtPayload = z.infer<typeof JwtPayloadSchema>;

// ─── Dev-mode header extraction ───────────────────────────────────────────────

/**
 * In dev/test mode, the X-Role header is accepted as a trust-no-verify
 * principal source. In production, parse and verify a real JWT.
 *
 * Format of X-Role header:  "<role>:<actor-id>[:<identity>]"
 *   Examples:
 *     admin:user-001
 *     applicant:user-002:alias-abc
 *     reviewer:user-003:sub-id-1,sub-id-2
 */
function extractDevPrincipal(request: NextRequest): Principal | null {
  const xRole = request.headers.get("x-role");
  if (!xRole) return null;

  const parts = xRole.split(":");
  if (parts.length < 2) return null;

  const rolePart = parts[0];
  const actorId = parts[1];
  const extra = parts[2] ?? undefined;

  const roleResult = PrincipalRoleSchema.safeParse(rolePart);
  if (!roleResult.success) return null;

  const role = roleResult.data;

  const principal: Principal = {
    id: actorId ?? "unknown",
    role,
  };

  if (role === "applicant" && extra) {
    principal.identity = extra;
  }

  if (role === "reviewer" && extra) {
    principal.assigned_submissions = extra.split(",").filter(Boolean);
  }

  return principal;
}

// ─── JWT verification (production path) ──────────────────────────────────────

/**
 * Minimal JWT decoder — verifies signature using HS256 with JWT_SECRET.
 * For P0-P2 demo: no external IdP required.
 */
async function verifyJwt(token: string): Promise<JwtPayload | null> {
  const secret = process.env["JWT_SECRET"];
  if (!secret) {
    console.warn("[auth] JWT_SECRET not set — JWT verification unavailable.");
    return null;
  }

  try {
    const [headerB64, payloadB64, signatureB64] = token.split(".");
    if (!headerB64 || !payloadB64 || !signatureB64) return null;

    // Verify signature using Web Crypto API (available in Next.js edge/node)
    const encoder = new TextEncoder();
    const keyData = encoder.encode(secret);

    const cryptoKey = await crypto.subtle.importKey(
      "raw",
      keyData,
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["verify"]
    );

    const message = encoder.encode(`${headerB64}.${payloadB64}`);
    const signature = Uint8Array.from(
      atob(signatureB64.replace(/-/g, "+").replace(/_/g, "/")),
      (c) => c.charCodeAt(0)
    );

    const valid = await crypto.subtle.verify("HMAC", cryptoKey, signature, message);
    if (!valid) return null;

    const payloadJson = JSON.parse(
      atob(payloadB64.replace(/-/g, "+").replace(/_/g, "/"))
    );

    return JwtPayloadSchema.parse(payloadJson);
  } catch {
    return null;
  }
}

// ─── Main extraction function ─────────────────────────────────────────────────

/**
 * Extracts and validates the principal from the incoming request.
 * Priority:
 *   1. X-Role header (dev/test mode — only when NODE_ENV !== 'production')
 *   2. Authorization: Bearer <jwt>
 *
 * Returns null if no valid principal is found.
 */
export async function extractPrincipal(
  request: NextRequest
): Promise<Principal | null> {
  const isDev = process.env["NODE_ENV"] !== "production";

  if (isDev) {
    const devPrincipal = extractDevPrincipal(request);
    if (devPrincipal) return devPrincipal;
  }

  const authHeader = request.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) return null;

  const token = authHeader.slice(7);
  const payload = await verifyJwt(token);
  if (!payload) return null;

  return {
    id: payload.sub,
    role: payload.role,
    identity: payload.identity,
    assigned_submissions: payload.assigned_submissions,
  };
}

// ─── Route guard helper ───────────────────────────────────────────────────────

export interface AuthResult {
  principal: Principal;
}

/**
 * Validates that a request carries a recognized principal.
 * Returns a 401 Response if unauthenticated, or the principal if valid.
 */
export async function requireAuth(
  request: NextRequest
): Promise<AuthResult | Response> {
  const principal = await extractPrincipal(request);

  if (!principal) {
    return new Response(
      JSON.stringify({ error: "Unauthorized", message: "Authentication required." }),
      {
        status: 401,
        headers: { "Content-Type": "application/json" },
      }
    );
  }

  return { principal };
}

/**
 * Validates that the caller has one of the permitted roles.
 * Returns a 403 Response if the role is not permitted.
 */
export function requireRole(
  principal: Principal,
  ...roles: Principal["role"][]
): Response | null {
  if (!roles.includes(principal.role)) {
    return new Response(
      JSON.stringify({
        error: "Forbidden",
        message: `Role '${principal.role}' is not permitted for this operation.`,
      }),
      {
        status: 403,
        headers: { "Content-Type": "application/json" },
      }
    );
  }
  return null;
}
