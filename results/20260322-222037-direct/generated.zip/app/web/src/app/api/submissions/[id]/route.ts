
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/server/db/prisma";
import { requireAuth } from "@/server/auth/middleware";
import { checkAccess, logAccessDecision } from "@repo/policies";
import type { ProposalStatus } from "@repo/domain";

/**
 * GET /api/submissions/[id]
 *
 * Returns a single submission with its effective proposal version.
 * Identity data is never included in this response.
 * Reviewer access is denied — they must use /api/blinded-packets/[id].
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  const authResult = await requireAuth(request);
  if (authResult instanceof Response) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { principal } = authResult;

  const { id } = await params;

  // Fetch submission for access check metadata
  const submission = await prisma.submission.findUnique({
    where: { id },
    include: {
      proposal_versions: {
        where: { is_effective: true },
      },
    },
  });

  if (!submission) {
    return NextResponse.json({ error: "Not Found" }, { status: 404 });
  }

  const accessCtx = {
    principal,
    resource_type: "Submission" as const,
    resource_id: id,
    operation: "read" as const,
    resource_meta: {
      applicant_alias: submission.applicant_alias,
      status: submission.status as ProposalStatus,
    },
  };

  const decision = checkAccess(accessCtx);
  await logAccessDecision(prisma, accessCtx, decision);

  if (!decision.allowed) {
    return NextResponse.json(
      { error: "Forbidden", message: decision.reason },
      { status: 403 }
    );
  }

  const effectiveVersion = submission.proposal_versions[0];

  return NextResponse.json({
    submission: {
      id: submission.id,
      call_id: submission.call_id,
      status: submission.status,
      submitted_at: submission.submitted_at,
      created_at: submission.created_at,
      // Never include applicant_alias for non-admin responses
      ...(principal.role === "admin" ? { applicant_alias: submission.applicant_alias } : {}),
    },
    effective_version: effectiveVersion
      ? {
          id: effectiveVersion.id,
          version_number: effectiveVersion.version_number,
          title: effectiveVersion.title,
          abstract: effectiveVersion.abstract,
          requested_budget_k_eur: effectiveVersion.requested_budget_k_eur,
          budget_usage: effectiveVersion.budget_usage,
          tasks_breakdown: effectiveVersion.tasks_breakdown,
          attachments_meta: effectiveVersion.attachments_meta,
          created_at: effectiveVersion.created_at,
        }
      : null,
  });
}
