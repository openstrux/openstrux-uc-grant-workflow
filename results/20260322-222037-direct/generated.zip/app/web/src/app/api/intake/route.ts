
import { NextRequest, NextResponse } from "next/server";
import { ZodError } from "zod";
import { prisma } from "@/server/db/prisma";
import { requireAuth, requireRole } from "@/server/auth/middleware";
import { submitProposal } from "@repo/policies";
import { SubmitProposalInputSchema } from "@repo/domain";

/**
 * POST /api/intake
 *
 * Creates a new submission with proposal version, applicant identity (segregated),
 * and blinded packet. Requires 'applicant' role.
 *
 * Request body: SubmitProposalInput
 * Response: { submission_id, proposal_version_id, blinded_packet_id }
 */
export async function POST(request: NextRequest): Promise<NextResponse> {
  // 1. Authenticate
  const authResult = await requireAuth(request);
  if (authResult instanceof Response) {
    return NextResponse.json(
      { error: "Unauthorized" },
      { status: 401 }
    );
  }
  const { principal } = authResult;

  // 2. Authorize — only applicants may submit proposals
  const roleError = requireRole(principal, "applicant");
  if (roleError) {
    return NextResponse.json(
      { error: "Forbidden", message: `Role '${principal.role}' cannot submit proposals.` },
      { status: 403 }
    );
  }

  // 3. Validate input
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: "Bad Request", message: "Request body must be valid JSON." },
      { status: 400 }
    );
  }

  const parseResult = SubmitProposalInputSchema.safeParse(body);
  if (!parseResult.success) {
    return NextResponse.json(
      {
        error: "Validation Error",
        details: parseResult.error.flatten(),
      },
      { status: 422 }
    );
  }

  const input = parseResult.data;

  // 4. Derive applicant alias from principal identity
  const applicantAlias = principal.identity ?? principal.id;

  // 5. Execute service
  try {
    const result = await submitProposal(
      prisma,
      input,
      applicantAlias,
      principal.id
    );

    return NextResponse.json(
      {
        submission_id: result.submission.id,
        proposal_version_id: result.proposal_version.id,
        blinded_packet_id: result.blinded_packet.id,
        status: result.submission.status,
      },
      { status: 201 }
    );
  } catch (err) {
    if (err instanceof ZodError) {
      return NextResponse.json(
        { error: "Validation Error", details: err.flatten() },
        { status: 422 }
      );
    }

    if (err instanceof Error) {
      // Known domain errors (call not open, etc.)
      if (
        err.message.includes("not open") ||
        err.message.includes("outside its submission window")
      ) {
        return NextResponse.json(
          { error: "Bad Request", message: err.message },
          { status: 400 }
        );
      }

      if (err.message.includes("Record to update not found") || err.message.includes("No Submission")) {
        return NextResponse.json(
          { error: "Not Found", message: err.message },
          { status: 404 }
        );
      }
    }

    console.error("[POST /api/intake]", err);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
