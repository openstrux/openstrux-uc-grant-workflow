
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/server/db/prisma";
import { requireAuth, requireRole } from "@/server/auth/middleware";

const CreateCallInputSchema = z.object({
  title: z.string().min(1),
  description: z.string(),
  open_date: z.coerce.date(),
  close_date: z.coerce.date(),
  enabled_eligibility_checks: z.array(z.string()),
  max_budget_k_eur: z.number().positive(),
  reviewer_policy_version: z.string().min(1),
});

/**
 * GET /api/calls — list all calls (public)
 * POST /api/calls — create a call (admin only)
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  const authResult = await requireAuth(request);
  if (authResult instanceof Response) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const calls = await prisma.call.findMany({
    orderBy: { open_date: "desc" },
  });

  return NextResponse.json({ calls });
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  const authResult = await requireAuth(request);
  if (authResult instanceof Response) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { principal } = authResult;

  const roleError = requireRole(principal, "admin");
  if (roleError) {
    return NextResponse.json(
      { error: "Forbidden", message: "Only admins can create calls." },
      { status: 403 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: "Bad Request", message: "Request body must be valid JSON." },
      { status: 400 }
    );
  }

  const parseResult = CreateCallInputSchema.safeParse(body);
  if (!parseResult.success) {
    return NextResponse.json(
      { error: "Validation Error", details: parseResult.error.flatten() },
      { status: 422 }
    );
  }

  const data = parseResult.data;

  const call = await prisma.call.create({
    data: {
      title: data.title,
      description: data.description,
      open_date: data.open_date,
      close_date: data.close_date,
      status: "open",
      enabled_eligibility_checks: data.enabled_eligibility_checks,
      max_budget_k_eur: data.max_budget_k_eur,
      reviewer_policy_version: data.reviewer_policy_version,
    },
  });

  await prisma.auditEvent.create({
    data: {
      event_type: "call.created",
      actor_id: principal.id,
      target_type: "Call",
      target_id: call.id,
      payload: { title: call.title, status: call.status },
    },
  });

  return NextResponse.json({ call }, { status: 201 });
}
