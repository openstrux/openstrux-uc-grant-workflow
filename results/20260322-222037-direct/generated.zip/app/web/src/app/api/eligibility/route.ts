
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/server/db/prisma";
import { requireAuth, requireRole } from "@/server/auth/middleware";
import { runEligibilityCheck } from "@repo/policies";
import { RunEligibilityCheckInputSchema } from "@repo/domain";
import { logAccessDecision, checkAccess } from "@repo/policies";

/**
 * POST /api/eligibility
 *
 * Triggers an eligibility evaluation for a submitted proposal.
 * Requires 'admin' role (admins control the eligibility workflow).
 *
 * Request body: RunEligibilityCheckInput
 * Response: { eligibility_record_id, status, new_status, failure_reasons }
 */
export async function POST(request: NextRequest): Promise<NextResponse> {
  // 1. Authenticate
  const authResult = await requireAuth(request);
  if (authResult instanceof Response) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { principal } = authResult;

  // 2. Authorize — only admins may trigger eligibility checks
  const roleError = requireRole(principal, "admin");
  if (roleError) {
    // Log the denied access attempt
    await logAccessDecision(
      prisma,
      {
        principal,
        resource_type: "EligibilityRecord",
        resource_id: "new",
        operation: "write",
      },
      {
        allowed: false,
        reason: `Role '${principal.role}' is not permitted to run eligibility checks.`,
        policy: "admin-all",
      }
    );

    return NextResponse.json(
      {
        error: "Forbidden",
        message: `Role '${principal.role}' cannot run eligibility checks.`,
      },
      { status: 403 }
    );
  }

  // 3. Validate input
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: "Bad Request", message: "Request body must be valid JSON." },
      { status: 400 }
    );
  }

  const parseResult = RunEligibilityCheckInputSchema.safeParse(body);
  if (!parseResult.success) {
    return NextResponse.json(
      {
        error: "Validation Error",
        details: parseResult.error.flatten(),
      },
      { status: 422 }
    );
  }

  const { submission_id, inputs } = parseResult.data;

  // 4. Check access policy (admin-all covers this, but log it for audit completeness)
  const accessCtx = {
    principal,
    resource_type: "Submission" as const,
    resource_id: submission_id,
    operation: "write" as const,
  };
  const decision = checkAccess(accessCtx);
  await logAccessDecision(prisma, accessCtx, decision);

  if (!decision.allowed) {
    return NextResponse.json(
      { error: "Forbidden", message: decision.reason },
      { status: 403 }
    );
  }

  // 5. Execute service
  try {
    const result = await runEligibilityCheck(
      prisma,
      submission_id,
      inputs,
      principal.id
    );

    return NextResponse.json(
      {
        eligibility_record_id: result.eligibility_record.id,
        status: result.eligibility_record.status,
        new_submission_status: result.new_status,
        active_rules: result.eligibility_record.active_rules,
        // failure_reasons only returned to admins
        failure_reasons: result.eligibility_record.failure_reasons,
        evaluated_at: result.eligibility_record.evaluated_at,
      },
      { status: 200 }
    );
  } catch (err) {
    if (err instanceof Error) {
      if (err.message.includes("eligibility check can only run")) {
        return NextResponse.json(
          { error: "Conflict", message: err.message },
          { status: 409 }
        );
      }

      if (
        err.message.includes("No Submission") ||
        err.message.includes("not found") ||
        err.message.includes("Record to")
      ) {
        return NextResponse.json(
          { error: "Not Found", message: `Submission '${submission_id}' not found.` },
          { status: 404 }
        );
      }
    }

    console.error("[POST /api/eligibility]", err);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
