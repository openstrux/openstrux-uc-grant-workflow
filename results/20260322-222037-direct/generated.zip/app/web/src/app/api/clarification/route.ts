
import { NextResponse } from "next/server";

/**
 * P4 — Clarification (stub)
 * Returns 501 Not Implemented per mvp-profile.md.
 */
export async function GET(): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", message: "P4 Clarification phase is not active in this release." },
    { status: 501 }
  );
}

export async function POST(): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", message: "P4 Clarification phase is not active in this release." },
    { status: 501 }
  );
}
