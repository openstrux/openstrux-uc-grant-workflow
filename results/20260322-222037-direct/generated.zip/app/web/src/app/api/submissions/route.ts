
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/server/db/prisma";
import { requireAuth, requireRole } from "@/server/auth/middleware";
import { checkAccess, logAccessDecision } from "@repo/policies";

/**
 * GET /api/submissions
 *
 * Returns submissions visible to the caller.
 * - Admin: all submissions
 * - Applicant: own submissions only
 * - Reviewer: not permitted (use /api/blinded-packets)
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  const authResult = await requireAuth(request);
  if (authResult instanceof Response) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { principal } = authResult;

  const roleError = requireRole(principal, "admin", "applicant");
  if (roleError) {
    return NextResponse.json(
      { error: "Forbidden", message: "Reviewers must use /api/blinded-packets." },
      { status: 403 }
    );
  }

  try {
    let submissions;

    if (principal.role === "admin") {
      submissions = await prisma.submission.findMany({
        include: { call: { select: { title: true } } },
        orderBy: { created_at: "desc" },
      });
    } else {
      // Applicant — own submissions only
      const alias = principal.identity ?? principal.id;
      submissions = await prisma.submission.findMany({
        where: { applicant_alias: alias },
        include: { call: { select: { title: true } } },
        orderBy: { created_at: "desc" },
      });
    }

    // Log access
    await logAccessDecision(
      prisma,
      {
        principal,
        resource_type: "Submission",
        resource_id: "collection",
        operation: "read",
      },
      { allowed: true, reason: "Listing permitted submissions.", policy: principal.role === "admin" ? "admin-all" : "applicant-own-proposals" }
    );

    // Never return applicant_alias to non-admins (it could be identifying)
    const safeSubmissions = submissions.map((s) => ({
      id: s.id,
      call_id: s.call_id,
      call_title: (s as { call?: { title: string } }).call?.title,
      status: s.status,
      submitted_at: s.submitted_at,
      created_at: s.created_at,
      // Only include applicant_alias for admins
      ...(principal.role === "admin" ? { applicant_alias: s.applicant_alias } : {}),
    }));

    return NextResponse.json({ submissions: safeSubmissions }, { status: 200 });
  } catch (err) {
    console.error("[GET /api/submissions]", err);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
