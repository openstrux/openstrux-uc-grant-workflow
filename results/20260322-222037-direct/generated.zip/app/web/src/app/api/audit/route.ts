
import { NextResponse } from "next/server";

/**
 * P6 — Audit export (stub)
 * Returns 501 Not Implemented per mvp-profile.md.
 */
export async function GET(): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", message: "P6 Audit export is not active in this release." },
    { status: 501 }
  );
}
