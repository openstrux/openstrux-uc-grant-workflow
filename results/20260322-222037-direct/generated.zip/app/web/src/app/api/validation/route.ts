
import { NextResponse } from "next/server";

/**
 * P5 — Validation (stub)
 * Returns 501 Not Implemented per mvp-profile.md.
 */
export async function GET(): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", message: "P5 Validation phase is not active in this release." },
    { status: 501 }
  );
}

export async function POST(): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", message: "P5 Validation phase is not active in this release." },
    { status: 501 }
  );
}
