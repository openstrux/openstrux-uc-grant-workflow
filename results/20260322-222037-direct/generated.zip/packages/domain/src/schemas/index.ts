
import { z } from "zod";

// ─── Enumerations ────────────────────────────────────────────────────────────

export const ProposalStatusSchema = z.enum([
  "draft",
  "submitted",
  "eligibility_failed",
  "eligible",
  "under_review",
  "clarification_requested",
  "revised",
  "validation_pending",
  "selected",
  "rejected",
]);

export const EligibilityStatusSchema = z.enum([
  "eligible",
  "ineligible",
  "pending",
]);

export const CallStatusSchema = z.enum([
  "draft",
  "open",
  "closed",
  "archived",
]);

export const ReviewStatusSchema = z.enum([
  "not_started",
  "assigned",
  "acknowledged",
  "reviewing",
  "completed",
  "withdrawn",
]);

export const PrincipalRoleSchema = z.enum([
  "applicant",
  "admin",
  "reviewer",
  "validator",
  "auditor",
]);

// ─── EligibilityInputs ────────────────────────────────────────────────────────

export const EligibilityInputsSchema = z.object({
  submitted_in_english: z.boolean(),
  aligned_with_call: z.boolean(),
  primary_objective_is_rd: z.boolean(),
  meets_european_dimension: z.enum(["true", "false", "not_applicable"]),
  requested_budget_k_eur: z.number().positive(),
  first_time_applicant_in_programme: z.boolean(),
});

// ─── Call ─────────────────────────────────────────────────────────────────────

export const CallSchema = z.object({
  id: z.string().uuid(),
  title: z.string().min(1),
  description: z.string(),
  open_date: z.coerce.date(),
  close_date: z.coerce.date(),
  status: CallStatusSchema,
  enabled_eligibility_checks: z.array(z.string()),
  max_budget_k_eur: z.number().positive(),
  reviewer_policy_version: z.string(),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── Submission ───────────────────────────────────────────────────────────────

export const SubmissionSchema = z.object({
  id: z.string().uuid(),
  call_id: z.string().uuid(),
  applicant_alias: z.string().min(1),
  status: ProposalStatusSchema,
  submitted_at: z.coerce.date().nullable(),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── ProposalVersion ──────────────────────────────────────────────────────────

export const AttachmentMetaSchema = z.object({
  filename: z.string(),
  mime_type: z.string(),
  size_bytes: z.number().int().nonnegative(),
  storage_key: z.string(),
});

export const ProposalVersionSchema = z.object({
  id: z.string().uuid(),
  submission_id: z.string().uuid(),
  version_number: z.number().int().positive(),
  is_effective: z.boolean(),
  title: z.string().min(1),
  abstract: z.string().min(1),
  requested_budget_k_eur: z.number().positive(),
  budget_usage: z.string(),
  tasks_breakdown: z.record(z.unknown()),
  attachments_meta: z.array(AttachmentMetaSchema),
  created_at: z.coerce.date(),
});

// ─── ApplicantIdentity ────────────────────────────────────────────────────────

export const ApplicantIdentitySchema = z.object({
  id: z.string().uuid(),
  submission_id: z.string().uuid(),
  legal_name: z.string().min(1),
  email: z.string().email(),
  country: z.string().min(1),
  organisation: z.string().min(1),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── BlindedPacket ────────────────────────────────────────────────────────────

export const BlindedPacketContentSchema = z.object({
  proposal_version_id: z.string().uuid(),
  submission_id: z.string().uuid(),
  version_number: z.number().int().positive(),
  title: z.string(),
  abstract: z.string(),
  requested_budget_k_eur: z.number(),
  budget_usage: z.string(),
  tasks_breakdown: z.record(z.unknown()),
  attachments_meta: z.array(
    z.object({
      filename: z.string(),
      mime_type: z.string(),
      size_bytes: z.number(),
    })
  ),
});

export const BlindedPacketSchema = z.object({
  id: z.string().uuid(),
  proposal_version_id: z.string().uuid(),
  content: BlindedPacketContentSchema,
  created_at: z.coerce.date(),
});

// ─── EligibilityRecord ────────────────────────────────────────────────────────

export const EligibilityRecordSchema = z.object({
  id: z.string().uuid(),
  submission_id: z.string().uuid(),
  status: EligibilityStatusSchema,
  inputs: EligibilityInputsSchema,
  active_rules: z.array(z.string()),
  failure_reasons: z.array(z.string()),
  evaluated_at: z.coerce.date(),
});

// ─── AuditEvent ───────────────────────────────────────────────────────────────

export const AuditEventSchema = z.object({
  id: z.string().uuid(),
  event_type: z.string().min(1),
  actor_id: z.string().min(1),
  target_type: z.string().min(1),
  target_id: z.string().min(1),
  payload: z.record(z.unknown()),
  timestamp: z.coerce.date(),
});

// ─── Input schemas for API routes ─────────────────────────────────────────────

export const SubmitProposalInputSchema = z.object({
  call_id: z.string().uuid(),
  title: z.string().min(1),
  abstract: z.string().min(1),
  requested_budget_k_eur: z.number().positive(),
  budget_usage: z.string().min(1),
  tasks_breakdown: z.record(z.unknown()),
  attachments_meta: z.array(AttachmentMetaSchema).default([]),
  // Identity fields — collected at intake, segregated in storage
  legal_name: z.string().min(1),
  email: z.string().email(),
  country: z.string().min(1),
  organisation: z.string().min(1),
});

export const RunEligibilityCheckInputSchema = z.object({
  submission_id: z.string().uuid(),
  inputs: EligibilityInputsSchema,
});

// ─── Re-exports ───────────────────────────────────────────────────────────────

export type ProposalStatus = z.infer<typeof ProposalStatusSchema>;
export type EligibilityStatus = z.infer<typeof EligibilityStatusSchema>;
export type CallStatus = z.infer<typeof CallStatusSchema>;
export type ReviewStatus = z.infer<typeof ReviewStatusSchema>;
export type PrincipalRole = z.infer<typeof PrincipalRoleSchema>;
export type EligibilityInputs = z.infer<typeof EligibilityInputsSchema>;
export type AttachmentMeta = z.infer<typeof AttachmentMetaSchema>;
export type BlindedPacketContent = z.infer<typeof BlindedPacketContentSchema>;
export type SubmitProposalInput = z.infer<typeof SubmitProposalInputSchema>;
export type RunEligibilityCheckInput = z.infer<typeof RunEligibilityCheckInputSchema>;
