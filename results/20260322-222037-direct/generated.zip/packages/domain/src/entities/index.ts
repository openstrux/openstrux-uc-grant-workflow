
import type {
  ProposalStatus,
  EligibilityStatus,
  CallStatus,
  ReviewStatus,
  EligibilityInputs,
  AttachmentMeta,
  BlindedPacketContent,
  PrincipalRole,
} from "../schemas/index.js";

// ─── Call ─────────────────────────────────────────────────────────────────────

export interface Call {
  id: string;
  title: string;
  description: string;
  open_date: Date;
  close_date: Date;
  status: CallStatus;
  enabled_eligibility_checks: string[];
  max_budget_k_eur: number;
  reviewer_policy_version: string;
  created_at: Date;
  updated_at: Date;
}

// ─── Submission ───────────────────────────────────────────────────────────────

export interface Submission {
  id: string;
  call_id: string;
  applicant_alias: string;
  status: ProposalStatus;
  submitted_at: Date | null;
  created_at: Date;
  updated_at: Date;
}

// ─── ProposalVersion ──────────────────────────────────────────────────────────

export interface ProposalVersion {
  id: string;
  submission_id: string;
  version_number: number;
  is_effective: boolean;
  title: string;
  abstract: string;
  requested_budget_k_eur: number;
  budget_usage: string;
  tasks_breakdown: Record<string, unknown>;
  attachments_meta: AttachmentMeta[];
  created_at: Date;
}

// ─── ApplicantIdentity ────────────────────────────────────────────────────────

export interface ApplicantIdentity {
  id: string;
  submission_id: string;
  legal_name: string;
  email: string;
  country: string;
  organisation: string;
  created_at: Date;
  updated_at: Date;
}

// ─── BlindedPacket ────────────────────────────────────────────────────────────

export interface BlindedPacket {
  id: string;
  proposal_version_id: string;
  content: BlindedPacketContent;
  created_at: Date;
}

// ─── EligibilityRecord ────────────────────────────────────────────────────────

export interface EligibilityRecord {
  id: string;
  submission_id: string;
  status: EligibilityStatus;
  inputs: EligibilityInputs;
  active_rules: string[];
  failure_reasons: string[];
  evaluated_at: Date;
}

// ─── AuditEvent ───────────────────────────────────────────────────────────────

export interface AuditEvent {
  id: string;
  event_type: string;
  actor_id: string;
  target_type: string;
  target_id: string;
  payload: Record<string, unknown>;
  timestamp: Date;
}

// ─── Principal (access control) ───────────────────────────────────────────────

export interface Principal {
  id: string;
  role: PrincipalRole;
  /** For applicants: their alias. For reviewers: assigned submission IDs. */
  identity?: string;
  assigned_submissions?: string[];
}

// ─── Re-export shared types from schemas ──────────────────────────────────────

export type {
  ProposalStatus,
  EligibilityStatus,
  CallStatus,
  ReviewStatus,
  EligibilityInputs,
  AttachmentMeta,
  BlindedPacketContent,
  PrincipalRole,
} from "../schemas/index.js";
