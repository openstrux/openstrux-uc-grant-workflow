
import type { EligibilityInputs, EligibilityStatus } from "@repo/domain";

// ─── Rule definitions ─────────────────────────────────────────────────────────

export const KNOWN_ELIGIBILITY_RULES = [
  "submittedInEnglish",
  "alignedWithCall",
  "primaryObjectiveIsRd",
  "meetsEuropeanDimension",
  "requestedBudgetKEur",
  "firstTimeApplicantInProgramme",
] as const;

export type EligibilityRuleKey = (typeof KNOWN_ELIGIBILITY_RULES)[number];

export interface EligibilityRuleSet {
  version: string;
  enabled_rules: string[];
  max_budget_k_eur: number;
}

export interface EligibilityEvaluationResult {
  status: EligibilityStatus;
  failure_reasons: string[];
  active_rules: string[];
  inputs: EligibilityInputs;
  rule_set_version: string;
  evaluated_at: Date;
}

// ─── Rule evaluators ──────────────────────────────────────────────────────────

type RuleEvaluator = (
  inputs: EligibilityInputs,
  ruleSet: EligibilityRuleSet
) => string | null;

const ruleEvaluators: Record<EligibilityRuleKey, RuleEvaluator> = {
  submittedInEnglish: (inputs) =>
    inputs.submitted_in_english
      ? null
      : "Proposal must be submitted in English.",

  alignedWithCall: (inputs) =>
    inputs.aligned_with_call
      ? null
      : "Proposal must be aligned with the call objectives.",

  primaryObjectiveIsRd: (inputs) =>
    inputs.primary_objective_is_rd
      ? null
      : "Primary objective must be research and development.",

  meetsEuropeanDimension: (inputs) =>
    inputs.meets_european_dimension !== "false"
      ? null
      : "Proposal must meet the European dimension requirement.",

  requestedBudgetKEur: (inputs, ruleSet) =>
    inputs.requested_budget_k_eur <= ruleSet.max_budget_k_eur
      ? null
      : `Requested budget (${inputs.requested_budget_k_eur}k EUR) exceeds the maximum allowed (${ruleSet.max_budget_k_eur}k EUR).`,

  firstTimeApplicantInProgramme: (_inputs) =>
    // Informational — not a blocking rule per MVP spec; presence alone records the fact
    null,
};

// ─── Pure evaluation function ─────────────────────────────────────────────────

/**
 * Evaluates eligibility inputs against an active rule set.
 * Pure function — no side effects, no DB access.
 * Records exact input values and the active rule set at evaluation time.
 */
export function evaluateEligibility(
  inputs: EligibilityInputs,
  ruleSet: EligibilityRuleSet
): EligibilityEvaluationResult {
  const active_rules: string[] = [];
  const failure_reasons: string[] = [];
  const evaluated_at = new Date();

  for (const ruleKey of KNOWN_ELIGIBILITY_RULES) {
    if (!ruleSet.enabled_rules.includes(ruleKey)) {
      continue;
    }

    active_rules.push(ruleKey);

    const evaluator = ruleEvaluators[ruleKey];
    const failure = evaluator(inputs, ruleSet);
    if (failure !== null) {
      failure_reasons.push(failure);
    }
  }

  const status: EligibilityStatus =
    failure_reasons.length === 0 ? "eligible" : "ineligible";

  return {
    status,
    failure_reasons,
    active_rules,
    inputs,
    rule_set_version: ruleSet.version,
    evaluated_at,
  };
}
