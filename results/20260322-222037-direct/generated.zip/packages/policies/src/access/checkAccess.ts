
import type { Principal, ProposalStatus } from "@repo/domain";
import { PrismaClient } from "@prisma/client";

export type ResourceType =
  | "Submission"
  | "ProposalVersion"
  | "ApplicantIdentity"
  | "BlindedPacket"
  | "EligibilityRecord"
  | "Call"
  | "AuditEvent";

export type Operation = "read" | "write" | "delete";

export interface AccessContext {
  principal: Principal;
  resource_type: ResourceType;
  resource_id: string;
  operation: Operation;
  /** Runtime metadata — e.g. resource's current state */
  resource_meta?: Record<string, unknown>;
}

export interface AccessDecision {
  allowed: boolean;
  reason: string;
  policy: string;
}

/**
 * Evaluates an access policy for a given principal, resource, and operation.
 * Returns an explicit allow/deny with the matching policy name.
 *
 * All access control decisions should be logged as AuditEvents by the caller.
 */
export function checkAccess(ctx: AccessContext): AccessDecision {
  const { principal, resource_type, operation } = ctx;

  // ── HARD DENY: reviewer can never access ApplicantIdentity ───────────────
  if (
    principal.role === "reviewer" &&
    resource_type === "ApplicantIdentity"
  ) {
    return {
      allowed: false,
      reason:
        "Reviewers are denied access to applicant identity data. (POLICY: deny-identity-to-reviewer)",
      policy: "deny-identity-to-reviewer",
    };
  }

  // ── Admin: read/write/delete on all entities ─────────────────────────────
  if (principal.role === "admin") {
    return {
      allowed: true,
      reason: "Admins have full access to all resources.",
      policy: "admin-all",
    };
  }

  // ── Auditor: read-only on AuditEvent ─────────────────────────────────────
  if (principal.role === "auditor") {
    if (resource_type === "AuditEvent" && operation === "read") {
      return {
        allowed: true,
        reason: "Auditors may read audit events.",
        policy: "auditor-audit-log",
      };
    }
    return {
      allowed: false,
      reason: "Auditors may only read AuditEvent records.",
      policy: "auditor-audit-log",
    };
  }

  // ── Applicant: own submissions only ──────────────────────────────────────
  if (principal.role === "applicant") {
    if (resource_type === "BlindedPacket") {
      return {
        allowed: false,
        reason: "Applicants do not have access to blinded packets.",
        policy: "applicant-own-proposals",
      };
    }

    // EligibilityRecord.failure_reasons are admin-only, but the record itself is readable
    // The caller is responsible for stripping failure_reasons from the response.
    if (
      resource_type === "Submission" ||
      resource_type === "ProposalVersion" ||
      resource_type === "EligibilityRecord" ||
      resource_type === "Call"
    ) {
      // Scope check: must be own submission
      // Ownership is verified against resource_meta.applicant_alias
      const resourceAlias = ctx.resource_meta?.["applicant_alias"] as
        | string
        | undefined;

      if (resource_type === "Call") {
        // Calls are publicly readable metadata
        return {
          allowed: operation === "read",
          reason:
            operation === "read"
              ? "Applicants may read call metadata."
              : "Applicants may not modify calls.",
          policy: "applicant-own-proposals",
        };
      }

      if (resourceAlias !== undefined && resourceAlias !== principal.identity) {
        return {
          allowed: false,
          reason:
            "Applicants may only access their own submissions.",
          policy: "applicant-own-proposals",
        };
      }

      // State-based write access
      if (operation === "write") {
        const status = ctx.resource_meta?.["status"] as
          | ProposalStatus
          | undefined;
        const writableStatuses: ProposalStatus[] = [
          "draft",
          "clarification_requested",
        ];

        if (status !== undefined && !writableStatuses.includes(status)) {
          return {
            allowed: false,
            reason: `Applicants may only write to submissions in draft or clarification_requested state. Current: ${status}.`,
            policy: "applicant-own-proposals",
          };
        }
      }

      return {
        allowed: true,
        reason: "Applicant accessing own submission.",
        policy: "applicant-own-proposals",
      };
    }

    return {
      allowed: false,
      reason: `Applicants may not access resource type: ${resource_type}.`,
      policy: "applicant-own-proposals",
    };
  }

  // ── Reviewer: blinded packets of assigned submissions only ────────────────
  if (principal.role === "reviewer") {
    if (resource_type === "BlindedPacket" && operation === "read") {
      const submissionId = ctx.resource_meta?.["submission_id"] as
        | string
        | undefined;

      const assigned = principal.assigned_submissions ?? [];

      if (submissionId !== undefined && assigned.includes(submissionId)) {
        // Also check state: reviewer can only access under_review, revised, validation_pending, selected
        const status = ctx.resource_meta?.["status"] as
          | ProposalStatus
          | undefined;
        const reviewerReadableStatuses: ProposalStatus[] = [
          "under_review",
          "clarification_requested",
          "revised",
          "validation_pending",
          "selected",
        ];

        if (
          status === undefined ||
          reviewerReadableStatuses.includes(status)
        ) {
          return {
            allowed: true,
            reason:
              "Reviewer accessing blinded packet for assigned submission.",
            policy: "reviewer-blinded-assigned",
          };
        }

        return {
          allowed: false,
          reason: `Submission status '${status}' does not permit reviewer access.`,
          policy: "reviewer-blinded-assigned",
        };
      }

      return {
        allowed: false,
        reason:
          "Reviewer may only access blinded packets of assigned submissions.",
        policy: "reviewer-blinded-assigned",
      };
    }

    // Reviewers may also read EligibilityRecord status (not failure_reasons) for assigned submissions
    if (resource_type === "EligibilityRecord" && operation === "read") {
      const submissionId = ctx.resource_meta?.["submission_id"] as
        | string
        | undefined;
      const assigned = principal.assigned_submissions ?? [];

      if (submissionId !== undefined && assigned.includes(submissionId)) {
        return {
          allowed: true,
          reason:
            "Reviewer reading eligibility status for assigned submission.",
          policy: "reviewer-blinded-assigned",
        };
      }
    }

    return {
      allowed: false,
      reason: `Reviewer access denied for resource type: ${resource_type}, operation: ${operation}.`,
      policy: "reviewer-blinded-assigned",
    };
  }

  // ── Validator (P5+) ───────────────────────────────────────────────────────
  if (principal.role === "validator") {
    return {
      allowed: false,
      reason: "Validator role is not implemented in P0-P2.",
      policy: "validator-not-implemented",
    };
  }

  return {
    allowed: false,
    reason: `Unknown role: ${principal.role}.`,
    policy: "unknown",
  };
}

/**
 * Logs an access control decision as an AuditEvent.
 * Should be called for every checkAccess invocation.
 */
export async function logAccessDecision(
  prisma: PrismaClient,
  ctx: AccessContext,
  decision: AccessDecision
): Promise<void> {
  await prisma.auditEvent.create({
    data: {
      event_type: "access",
      actor_id: ctx.principal.id,
      target_type: ctx.resource_type,
      target_id: ctx.resource_id,
      payload: {
        operation: ctx.operation,
        allowed: decision.allowed,
        policy: decision.policy,
        reason: decision.reason,
        role: ctx.principal.role,
      },
    },
  });
}
