
import { PrismaClient } from "@prisma/client";
import type { EligibilityInputs, ProposalStatus } from "@repo/domain";
import type { EligibilityRecord } from "@repo/domain";
import {
  evaluateEligibility,
  type EligibilityRuleSet,
} from "../eligibility/evaluateEligibility.js";
import { buildBlindedPacketContent } from "../mappers/blindedPacketMapper.js";

export interface RunEligibilityCheckResult {
  eligibility_record: EligibilityRecord;
  new_status: ProposalStatus;
}

/**
 * Persists an EligibilityRecord, transitions the Submission status, and
 * generates a BlindedPacket (if transitioning to eligible).
 * All operations are wrapped in a Prisma transaction.
 * Emits an AuditEvent on completion.
 */
export async function runEligibilityCheck(
  prisma: PrismaClient,
  submissionId: string,
  inputs: EligibilityInputs,
  actorId: string
): Promise<RunEligibilityCheckResult> {
  // 1. Load submission and its call to get the active rule set
  const submission = await prisma.submission.findUniqueOrThrow({
    where: { id: submissionId },
    include: {
      call: true,
    },
  });

  if (submission.status !== "submitted") {
    throw new Error(
      `Eligibility check can only run on submissions in 'submitted' status. Current: '${submission.status}'.`
    );
  }

  const call = submission.call;
  const ruleSet: EligibilityRuleSet = {
    version: call.reviewer_policy_version,
    enabled_rules: call.enabled_eligibility_checks,
    max_budget_k_eur: call.max_budget_k_eur,
  };

  // 2. Pure evaluation — no side effects
  const evaluation = evaluateEligibility(inputs, ruleSet);

  const newStatus: ProposalStatus =
    evaluation.status === "eligible" ? "eligible" : "eligibility_failed";

  const result = await prisma.$transaction(async (tx) => {
    // 3. Persist EligibilityRecord
    const eligibilityRecord = await tx.eligibilityRecord.create({
      data: {
        submission_id: submissionId,
        status: evaluation.status,
        inputs: evaluation.inputs as Record<string, unknown>,
        active_rules: evaluation.active_rules,
        failure_reasons: evaluation.failure_reasons,
        evaluated_at: evaluation.evaluated_at,
      },
    });

    // 4. Transition submission status
    await tx.submission.update({
      where: { id: submissionId },
      data: { status: newStatus },
    });

    // 5. If eligible, generate/refresh BlindedPacket for the effective ProposalVersion
    if (newStatus === "eligible") {
      const effectiveVersion = await tx.proposalVersion.findFirst({
        where: { submission_id: submissionId, is_effective: true },
      });

      if (effectiveVersion) {
        const blindedContent = buildBlindedPacketContent(
          {
            id: effectiveVersion.id,
            submission_id: effectiveVersion.submission_id,
            version_number: effectiveVersion.version_number,
            title: effectiveVersion.title,
            abstract: effectiveVersion.abstract,
            requested_budget_k_eur: effectiveVersion.requested_budget_k_eur,
            budget_usage: effectiveVersion.budget_usage,
            tasks_breakdown: effectiveVersion.tasks_breakdown as Record<string, unknown>,
            attachments_meta: effectiveVersion.attachments_meta,
          },
          submissionId
        );

        // Upsert — a blinded packet may already exist from intake
        await tx.blindedPacket.upsert({
          where: { proposal_version_id: effectiveVersion.id },
          create: {
            proposal_version_id: effectiveVersion.id,
            content: blindedContent,
          },
          update: {
            content: blindedContent,
          },
        });
      }
    }

    // 6. Emit AuditEvent
    await tx.auditEvent.create({
      data: {
        event_type: "eligibility.evaluated",
        actor_id: actorId,
        target_type: "Submission",
        target_id: submissionId,
        payload: {
          eligibility_record_id: eligibilityRecord.id,
          result: evaluation.status,
          new_status: newStatus,
          active_rules: evaluation.active_rules,
          failure_reasons: evaluation.failure_reasons,
          rule_set_version: evaluation.rule_set_version,
        },
      },
    });

    return {
      eligibility_record: eligibilityRecord,
    };
  });

  return {
    eligibility_record: {
      id: result.eligibility_record.id,
      submission_id: result.eligibility_record.submission_id,
      status: result.eligibility_record.status as import("@repo/domain").EligibilityStatus,
      inputs: result.eligibility_record.inputs as EligibilityInputs,
      active_rules: result.eligibility_record.active_rules,
      failure_reasons: result.eligibility_record.failure_reasons,
      evaluated_at: result.eligibility_record.evaluated_at,
    },
    new_status: newStatus,
  };
}
