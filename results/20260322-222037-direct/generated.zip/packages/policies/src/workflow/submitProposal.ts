
import { PrismaClient } from "@prisma/client";
import type { SubmitProposalInput } from "@repo/domain";
import type { Submission, ProposalVersion, BlindedPacket } from "@repo/domain";
import { buildBlindedPacketContent } from "../mappers/blindedPacketMapper.js";

export interface SubmitProposalResult {
  submission: Submission;
  proposal_version: ProposalVersion;
  blinded_packet: BlindedPacket;
}

/**
 * Creates a submission, proposal version, identity record, and blinded packet
 * within a single Prisma transaction. Emits an AuditEvent on success.
 *
 * Identity data is written to applicant_identity and never included in the
 * blinded packet content presented to reviewers.
 */
export async function submitProposal(
  prisma: PrismaClient,
  input: SubmitProposalInput,
  applicantAlias: string,
  actorId: string
): Promise<SubmitProposalResult> {
  const result = await prisma.$transaction(async (tx) => {
    // 1. Verify the call exists and is open
    const call = await tx.call.findUniqueOrThrow({
      where: { id: input.call_id },
    });

    const now = new Date();
    if (call.status !== "open") {
      throw new Error(`Call "${call.id}" is not open for submissions.`);
    }
    if (now < call.open_date || now > call.close_date) {
      throw new Error(
        `Call "${call.id}" is outside its submission window.`
      );
    }

    // 2. Create Submission
    const submission = await tx.submission.create({
      data: {
        call_id: input.call_id,
        applicant_alias: applicantAlias,
        status: "submitted",
        submitted_at: now,
      },
    });

    // 3. Create ProposalVersion (version 1, effective)
    const proposalVersion = await tx.proposalVersion.create({
      data: {
        submission_id: submission.id,
        version_number: 1,
        is_effective: true,
        title: input.title,
        abstract: input.abstract,
        requested_budget_k_eur: input.requested_budget_k_eur,
        budget_usage: input.budget_usage,
        tasks_breakdown: input.tasks_breakdown,
        attachments_meta: input.attachments_meta,
      },
    });

    // 4. Create ApplicantIdentity — in separate table, not mixed with proposal content
    await tx.applicantIdentity.create({
      data: {
        submission_id: submission.id,
        legal_name: input.legal_name,
        email: input.email,
        country: input.country,
        organisation: input.organisation,
      },
    });

    // 5. Generate BlindedPacket — identity fields are explicitly excluded
    const blindedContent = buildBlindedPacketContent(
      proposalVersion,
      submission.id
    );

    const blindedPacket = await tx.blindedPacket.create({
      data: {
        proposal_version_id: proposalVersion.id,
        content: blindedContent,
      },
    });

    // 6. Emit AuditEvent
    await tx.auditEvent.create({
      data: {
        event_type: "submission.created",
        actor_id: actorId,
        target_type: "Submission",
        target_id: submission.id,
        payload: {
          call_id: input.call_id,
          version_number: 1,
          blinded_packet_id: blindedPacket.id,
          status: "submitted",
        },
      },
    });

    return {
      submission,
      proposal_version: proposalVersion,
      blinded_packet: blindedPacket,
    };
  });

  // Map Prisma results to domain types
  return {
    submission: {
      id: result.submission.id,
      call_id: result.submission.call_id,
      applicant_alias: result.submission.applicant_alias,
      status: result.submission.status as import("@repo/domain").ProposalStatus,
      submitted_at: result.submission.submitted_at,
      created_at: result.submission.created_at,
      updated_at: result.submission.updated_at,
    },
    proposal_version: {
      id: result.proposal_version.id,
      submission_id: result.proposal_version.submission_id,
      version_number: result.proposal_version.version_number,
      is_effective: result.proposal_version.is_effective,
      title: result.proposal_version.title,
      abstract: result.proposal_version.abstract,
      requested_budget_k_eur: result.proposal_version.requested_budget_k_eur,
      budget_usage: result.proposal_version.budget_usage,
      tasks_breakdown: result.proposal_version.tasks_breakdown as Record<string, unknown>,
      attachments_meta: result.proposal_version.attachments_meta as import("@repo/domain").AttachmentMeta[],
      created_at: result.proposal_version.created_at,
    },
    blinded_packet: {
      id: result.blinded_packet.id,
      proposal_version_id: result.blinded_packet.proposal_version_id,
      content: result.blinded_packet.content as import("@repo/domain").BlindedPacketContent,
      created_at: result.blinded_packet.created_at,
    },
  };
}
