
import { z } from "zod";
import {
  CallSchema,
  SubmissionSchema,
  ProposalVersionSchema,
  ApplicantIdentitySchema,
  BlindedPacketSchema,
  EligibilityRecordSchema,
  EligibilityInputsSchema,
  AuditEventSchema,
  PrincipalSchema,
  ProposalStatusSchema,
  EligibilityStatusSchema,
  CallStatusSchema,
  MeetsEuropeanDimensionSchema,
  RoleSchema,
  IntakeInputSchema,
  EligibilityCheckInputSchema,
  CreateCallInputSchema,
} from "../schemas/index.js";

// ─── Enum types ───────────────────────────────────────────────────────────────

export type ProposalStatus = z.infer<typeof ProposalStatusSchema>;
export type EligibilityStatus = z.infer<typeof EligibilityStatusSchema>;
export type CallStatus = z.infer<typeof CallStatusSchema>;
export type MeetsEuropeanDimension = z.infer<typeof MeetsEuropeanDimensionSchema>;
export type Role = z.infer<typeof RoleSchema>;

// ─── Entity types ─────────────────────────────────────────────────────────────

export type Call = z.infer<typeof CallSchema>;
export type Submission = z.infer<typeof SubmissionSchema>;
export type ProposalVersion = z.infer<typeof ProposalVersionSchema>;
export type ApplicantIdentity = z.infer<typeof ApplicantIdentitySchema>;
export type BlindedPacket = z.infer<typeof BlindedPacketSchema>;
export type EligibilityInputs = z.infer<typeof EligibilityInputsSchema>;
export type EligibilityRecord = z.infer<typeof EligibilityRecordSchema>;
export type AuditEvent = z.infer<typeof AuditEventSchema>;

// ─── Input types ──────────────────────────────────────────────────────────────

export type Principal = z.infer<typeof PrincipalSchema>;
export type IntakeInput = z.infer<typeof IntakeInputSchema>;
export type EligibilityCheckInput = z.infer<typeof EligibilityCheckInputSchema>;
export type CreateCallInput = z.infer<typeof CreateCallInputSchema>;

// ─── Operation types ──────────────────────────────────────────────────────────

export type Operation = "read" | "write" | "delete";

// ─── Resource descriptor ──────────────────────────────────────────────────────

export interface ResourceDescriptor {
  type:
    | "Call"
    | "Submission"
    | "ProposalVersion"
    | "ApplicantIdentity"
    | "BlindedPacket"
    | "EligibilityRecord"
    | "AuditEvent";
  id: string;
  ownerId?: string; // applicant_alias for Submission resources
}

// ─── Access decision ──────────────────────────────────────────────────────────

export interface AccessDecision {
  allowed: boolean;
  reason: string;
}

// ─── Eligibility evaluation result ───────────────────────────────────────────

export interface EligibilityEvaluation {
  status: EligibilityStatus;
  active_rules: string[];
  failure_reasons: string[];
}

// ─── Service results ──────────────────────────────────────────────────────────

export interface SubmitProposalResult {
  submission_id: string;
  proposal_version_id: string;
  blinded_packet_id: string;
}

export interface RunEligibilityCheckResult {
  eligibility_record_id: string;
  status: EligibilityStatus;
  failure_reasons: string[];
}
