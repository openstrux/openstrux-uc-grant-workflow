
import { z } from "zod";

// ─── Enumerations ────────────────────────────────────────────────────────────

export const ProposalStatusSchema = z.enum([
  "draft",
  "submitted",
  "eligibility_failed",
  "eligible",
  "under_review",
  "clarification_requested",
  "revised",
  "validation_pending",
  "selected",
  "rejected",
]);

export const EligibilityStatusSchema = z.enum([
  "eligible",
  "ineligible",
  "pending",
]);

export const CallStatusSchema = z.enum(["draft", "open", "closed", "archived"]);

export const MeetsEuropeanDimensionSchema = z.enum([
  "true",
  "false",
  "not_applicable",
]);

export const RoleSchema = z.enum([
  "applicant",
  "admin",
  "reviewer",
  "validator",
  "auditor",
]);

// ─── Call ────────────────────────────────────────────────────────────────────

export const CallSchema = z.object({
  id: z.string().uuid(),
  title: z.string().min(1),
  description: z.string(),
  open_date: z.coerce.date(),
  close_date: z.coerce.date(),
  status: CallStatusSchema,
  enabled_eligibility_checks: z.array(z.string()),
  max_budget_k_eur: z.number().positive(),
  reviewer_policy_version: z.string(),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

export const CreateCallInputSchema = z.object({
  title: z.string().min(1),
  description: z.string(),
  open_date: z.coerce.date(),
  close_date: z.coerce.date(),
  enabled_eligibility_checks: z.array(z.string()),
  max_budget_k_eur: z.number().positive(),
  reviewer_policy_version: z.string(),
});

// ─── Submission ───────────────────────────────────────────────────────────────

export const SubmissionSchema = z.object({
  id: z.string().uuid(),
  call_id: z.string().uuid(),
  applicant_alias: z.string().min(1),
  status: ProposalStatusSchema,
  submitted_at: z.coerce.date().nullable(),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── ProposalVersion ─────────────────────────────────────────────────────────

export const ProposalVersionSchema = z.object({
  id: z.string().uuid(),
  submission_id: z.string().uuid(),
  version_number: z.number().int().positive(),
  is_effective: z.boolean(),
  title: z.string().min(1),
  abstract: z.string(),
  requested_budget_k_eur: z.number().positive(),
  budget_usage: z.string(),
  tasks_breakdown: z.unknown(),
  attachments_meta: z.unknown(),
  created_at: z.coerce.date(),
});

// ─── ApplicantIdentity ────────────────────────────────────────────────────────

export const ApplicantIdentitySchema = z.object({
  id: z.string().uuid(),
  submission_id: z.string().uuid(),
  legal_name: z.string().min(1),
  email: z.string().email(),
  country: z.string().min(1),
  organisation: z.string().min(1),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── BlindedPacket ────────────────────────────────────────────────────────────

export const BlindedPacketSchema = z.object({
  id: z.string().uuid(),
  proposal_version_id: z.string().uuid(),
  content: z.record(z.unknown()),
  created_at: z.coerce.date(),
});

// ─── EligibilityInputs ────────────────────────────────────────────────────────

export const EligibilityInputsSchema = z.object({
  submitted_in_english: z.boolean(),
  aligned_with_call: z.boolean(),
  primary_objective_is_rd: z.boolean(),
  meets_european_dimension: MeetsEuropeanDimensionSchema,
  requested_budget_k_eur: z.number().positive(),
  first_time_applicant_in_programme: z.boolean(),
});

// ─── EligibilityRecord ────────────────────────────────────────────────────────

export const EligibilityRecordSchema = z.object({
  id: z.string().uuid(),
  submission_id: z.string().uuid(),
  status: EligibilityStatusSchema,
  inputs: EligibilityInputsSchema,
  active_rules: z.array(z.string()),
  failure_reasons: z.array(z.string()),
  evaluated_at: z.coerce.date(),
});

// ─── AuditEvent ───────────────────────────────────────────────────────────────

export const AuditEventSchema = z.object({
  id: z.string().uuid(),
  event_type: z.string().min(1),
  actor_id: z.string().min(1),
  target_type: z.string().min(1),
  target_id: z.string().min(1),
  payload: z.record(z.unknown()),
  timestamp: z.coerce.date(),
});

// ─── Intake input ─────────────────────────────────────────────────────────────

export const IntakeInputSchema = z.object({
  call_id: z.string().uuid(),
  // Proposal content
  title: z.string().min(1),
  abstract: z.string().min(1),
  requested_budget_k_eur: z.number().positive(),
  budget_usage: z.string().min(1),
  tasks_breakdown: z.unknown(),
  attachments_meta: z.unknown().optional(),
  // Identity
  legal_name: z.string().min(1),
  email: z.string().email(),
  country: z.string().min(1),
  organisation: z.string().min(1),
});

// ─── Eligibility check input ──────────────────────────────────────────────────

export const EligibilityCheckInputSchema = z.object({
  submission_id: z.string().uuid(),
  inputs: EligibilityInputsSchema,
});

// ─── Principal ────────────────────────────────────────────────────────────────

export const PrincipalSchema = z.object({
  id: z.string().min(1),
  role: RoleSchema,
  assigned_proposals: z.array(z.string().uuid()).optional(),
});
