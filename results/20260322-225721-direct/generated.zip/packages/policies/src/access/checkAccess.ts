
import type {
  Principal,
  Operation,
  ResourceDescriptor,
  AccessDecision,
} from "../../../domain/src/entities/index.js";

/**
 * Evaluates access control policies as defined in specs/access-policies.md.
 *
 * Enforcement is explicit — each policy is a named function.
 * Returns an AccessDecision with allowed: boolean and a reason string
 * (for audit logging).
 */
export function checkAccess(
  principal: Principal,
  resource: ResourceDescriptor,
  operation: Operation
): AccessDecision {
  // POLICY: deny-identity-to-reviewer — hard deny, always checked first
  if (
    principal.role === "reviewer" &&
    resource.type === "ApplicantIdentity"
  ) {
    return {
      allowed: false,
      reason:
        "POLICY:deny-identity-to-reviewer — reviewer principal may never access ApplicantIdentity",
    };
  }

  // POLICY: deny-identity-to-validator
  if (
    principal.role === "validator" &&
    resource.type === "ApplicantIdentity"
  ) {
    return {
      allowed: false,
      reason:
        "POLICY:deny-identity-to-validator — validator principal may never access ApplicantIdentity",
    };
  }

  // POLICY: admin-all
  if (principal.role === "admin") {
    // Deletion only via retention/anonymisation workflow (enforced in service layer)
    return {
      allowed: true,
      reason: "POLICY:admin-all",
    };
  }

  // POLICY: applicant-own-proposals
  if (principal.role === "applicant") {
    return checkApplicantPolicy(principal, resource, operation);
  }

  // POLICY: reviewer-blinded-assigned
  if (principal.role === "reviewer") {
    return checkReviewerPolicy(principal, resource, operation);
  }

  // POLICY: auditor — read-only access to AuditEvent
  if (principal.role === "auditor") {
    return checkAuditorPolicy(resource, operation);
  }

  // POLICY: validator — P5+, stub deny for now
  if (principal.role === "validator") {
    return {
      allowed: false,
      reason: "POLICY:validator — not active in P0-P2 scope",
    };
  }

  return {
    allowed: false,
    reason: "No matching policy — default deny",
  };
}

function checkApplicantPolicy(
  principal: Principal,
  resource: ResourceDescriptor,
  operation: Operation
): AccessDecision {
  // Applicants can only access their own submissions
  const ownedTypes = [
    "Submission",
    "ProposalVersion",
    "ApplicantIdentity",
  ] as const;

  if (resource.type === "BlindedPacket") {
    return {
      allowed: false,
      reason: "POLICY:applicant-own-proposals — excludes BlindedPacket",
    };
  }

  if (resource.type === "AuditEvent") {
    return {
      allowed: false,
      reason: "POLICY:applicant-own-proposals — excludes AuditEvent",
    };
  }

  if (resource.type === "Call" && operation === "read") {
    return { allowed: true, reason: "POLICY:applicant-own-proposals — Call read allowed" };
  }

  if (resource.type === "EligibilityRecord" && operation === "read") {
    // Applicants can read their own eligibility record but NOT failure_reasons
    // (failure_reasons stripping is handled at the service/API layer)
    if (resource.ownerId && resource.ownerId === principal.id) {
      return {
        allowed: true,
        reason:
          "POLICY:applicant-own-proposals — EligibilityRecord read (failure_reasons stripped at service layer)",
      };
    }
    return {
      allowed: false,
      reason: "POLICY:applicant-own-proposals — not owner of this EligibilityRecord",
    };
  }

  // For owned entity types, check ownership
  if ((ownedTypes as readonly string[]).includes(resource.type)) {
    if (!resource.ownerId) {
      // ownerId not supplied — deny conservatively
      return {
        allowed: false,
        reason:
          "POLICY:applicant-own-proposals — ownerId not provided, cannot verify ownership",
      };
    }
    if (resource.ownerId !== principal.id) {
      return {
        allowed: false,
        reason: "POLICY:applicant-own-proposals — applicant is not owner",
      };
    }
    // write operations are allowed only on Submission / ProposalVersion in draft/clarification
    // state gating is enforced at the service layer per workflow-states.md
    return {
      allowed: true,
      reason: "POLICY:applicant-own-proposals — owner access granted",
    };
  }

  return {
    allowed: false,
    reason: "POLICY:applicant-own-proposals — resource type not covered",
  };
}

function checkReviewerPolicy(
  principal: Principal,
  resource: ResourceDescriptor,
  operation: Operation
): AccessDecision {
  // Reviewers can only read BlindedPackets for assigned proposals
  if (resource.type !== "BlindedPacket") {
    return {
      allowed: false,
      reason: `POLICY:reviewer-blinded-assigned — reviewers may only access BlindedPacket, not ${resource.type}`,
    };
  }

  if (operation !== "read") {
    return {
      allowed: false,
      reason: "POLICY:reviewer-blinded-assigned — reviewers are read-only",
    };
  }

  const assignedProposals = principal.assigned_proposals ?? [];
  if (!assignedProposals.includes(resource.id)) {
    return {
      allowed: false,
      reason:
        "POLICY:reviewer-blinded-assigned — BlindedPacket not in reviewer's assigned proposals",
    };
  }

  return {
    allowed: true,
    reason: "POLICY:reviewer-blinded-assigned — assigned BlindedPacket read allowed",
  };
}

function checkAuditorPolicy(
  resource: ResourceDescriptor,
  operation: Operation
): AccessDecision {
  if (resource.type !== "AuditEvent") {
    return {
      allowed: false,
      reason: "POLICY:auditor — auditors may only access AuditEvent records",
    };
  }
  if (operation !== "read") {
    return {
      allowed: false,
      reason: "POLICY:auditor — auditors are read-only",
    };
  }
  return { allowed: true, reason: "POLICY:auditor — AuditEvent read allowed" };
}
