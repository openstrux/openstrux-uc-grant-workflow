
/**
 * Strips all identity-bearing fields from proposal content before
 * creating a BlindedPacket for reviewer consumption.
 *
 * Per specs/access-policies.md — Pseudonymization rule:
 * No identity field (legal name, email, country, organisation, applicant alias)
 * may appear in any reviewer-accessible response.
 */

import type { ProposalVersion } from "../../../domain/src/entities/index.js";

// Fields that are explicitly safe for reviewer consumption
const ALLOWED_CONTENT_FIELDS = [
  "title",
  "abstract",
  "requested_budget_k_eur",
  "budget_usage",
  "tasks_breakdown",
  "attachments_meta",
] as const;

// Identity fields that must never appear in a blinded packet
const IDENTITY_FIELDS_DENY_LIST = [
  "legal_name",
  "email",
  "country",
  "organisation",
  "applicant_alias",
  "submission_id",
  "id",
  "version_number",
  "is_effective",
  "created_at",
] as const;

export type BlindedContent = {
  title: string;
  abstract: string;
  requested_budget_k_eur: number;
  budget_usage: string;
  tasks_breakdown: unknown;
  attachments_meta: unknown;
};

/**
 * Creates the identity-free content blob for a BlindedPacket.
 * Uses an allowlist (not a denylist) to guarantee no new fields leak through.
 */
export function mapToBlindedContent(version: ProposalVersion): BlindedContent {
  // Allowlist approach: only extract known-safe fields
  const blinded: BlindedContent = {
    title: version.title,
    abstract: version.abstract,
    requested_budget_k_eur: version.requested_budget_k_eur,
    budget_usage: version.budget_usage,
    tasks_breakdown: version.tasks_breakdown,
    attachments_meta: version.attachments_meta,
  };

  // Defensive: verify none of the deny-listed fields made it in
  assertNoIdentityFields(blinded);

  return blinded;
}

/**
 * Validates that a content object (already blinded) contains no identity fields.
 * Used as a golden-test-style assertion at generation time.
 */
export function assertNoIdentityFields(content: Record<string, unknown>): void {
  for (const field of IDENTITY_FIELDS_DENY_LIST) {
    if (field in content) {
      throw new Error(
        `[BlindedPacketMapper] Identity field "${field}" detected in blinded content. ` +
          `This is a policy violation. Aborting blind packet creation.`
      );
    }
  }
}

/**
 * Validates that a reviewer-facing response object contains no identity fields.
 * Call this at the API response boundary for reviewer routes.
 */
export function stripIdentityFromResponse(
  obj: Record<string, unknown>
): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(obj)) {
    const isDenied = (IDENTITY_FIELDS_DENY_LIST as readonly string[]).includes(key);
    if (!isDenied) {
      result[key] = value;
    }
  }
  return result;
}

// Re-export for convenience
export { ALLOWED_CONTENT_FIELDS, IDENTITY_FIELDS_DENY_LIST };
