
import { PrismaClient } from "@prisma/client";
import type { IntakeInput, SubmitProposalResult } from "../../../domain/src/entities/index.js";
import { mapToBlindedContent } from "../intake/blindedPacketMapper.js";

/**
 * Creates a new Submission, ProposalVersion, ApplicantIdentity, and BlindedPacket
 * in a single Prisma transaction.
 *
 * Invariants enforced:
 * - ApplicantIdentity is stored separately from ProposalVersion (separate DB rows)
 * - BlindedPacket is generated immediately on submission (identity stripped)
 * - AuditEvent is written for the submission action
 * - Call must be open
 */
export async function submitProposal(
  prisma: PrismaClient,
  input: IntakeInput,
  applicantAlias: string
): Promise<SubmitProposalResult> {
  return prisma.$transaction(async (tx) => {
    // 1. Verify the call exists and is open
    const call = await tx.call.findUnique({
      where: { id: input.call_id },
    });

    if (!call) {
      throw new Error(`Call not found: ${input.call_id}`);
    }
    if (call.status !== "open") {
      throw new Error(`Call is not open for submissions (status: ${call.status})`);
    }

    const now = new Date();
    if (now < call.open_date || now > call.close_date) {
      throw new Error("Call submission window is not currently active");
    }

    // 2. Create Submission
    const submission = await tx.submission.create({
      data: {
        call_id: input.call_id,
        applicant_alias: applicantAlias,
        status: "submitted",
        submitted_at: now,
      },
    });

    // 3. Create ProposalVersion (version 1, effective)
    const proposalVersion = await tx.proposalVersion.create({
      data: {
        submission_id: submission.id,
        version_number: 1,
        is_effective: true,
        title: input.title,
        abstract: input.abstract,
        requested_budget_k_eur: input.requested_budget_k_eur,
        budget_usage: input.budget_usage,
        tasks_breakdown: input.tasks_breakdown as object,
        attachments_meta: (input.attachments_meta ?? []) as object,
      },
    });

    // 4. Create ApplicantIdentity (separate from proposal content — data separation invariant)
    await tx.applicantIdentity.create({
      data: {
        submission_id: submission.id,
        legal_name: input.legal_name,
        email: input.email,
        country: input.country,
        organisation: input.organisation,
      },
    });

    // 5. Generate BlindedPacket — map ProposalVersion to identity-free content
    const blindedContent = mapToBlindedContent({
      id: proposalVersion.id,
      submission_id: proposalVersion.submission_id,
      version_number: proposalVersion.version_number,
      is_effective: proposalVersion.is_effective,
      title: proposalVersion.title,
      abstract: proposalVersion.abstract,
      requested_budget_k_eur: proposalVersion.requested_budget_k_eur,
      budget_usage: proposalVersion.budget_usage,
      tasks_breakdown: proposalVersion.tasks_breakdown,
      attachments_meta: proposalVersion.attachments_meta,
      created_at: proposalVersion.created_at,
    });

    const blindedPacket = await tx.blindedPacket.create({
      data: {
        proposal_version_id: proposalVersion.id,
        content: blindedContent as object,
      },
    });

    // 6. Write AuditEvent
    await tx.auditEvent.create({
      data: {
        event_type: "submission.created",
        actor_id: applicantAlias,
        target_type: "Submission",
        target_id: submission.id,
        payload: {
          call_id: input.call_id,
          proposal_version_id: proposalVersion.id,
          blinded_packet_id: blindedPacket.id,
          status: "submitted",
        },
      },
    });

    return {
      submission_id: submission.id,
      proposal_version_id: proposalVersion.id,
      blinded_packet_id: blindedPacket.id,
    };
  });
}
