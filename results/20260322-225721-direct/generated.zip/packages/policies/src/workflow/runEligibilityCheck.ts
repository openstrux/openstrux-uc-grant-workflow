
import { PrismaClient } from "@prisma/client";
import type {
  EligibilityInputs,
  RunEligibilityCheckResult,
} from "../../../domain/src/entities/index.js";
import {
  evaluateEligibility,
  buildRuleSetFromCall,
} from "../eligibility/evaluateEligibility.js";

/**
 * Runs the eligibility gate for a given submission.
 *
 * Persists:
 * - EligibilityRecord with exact inputs and active rule set (spec constraint)
 * - Updates Submission.status to eligible | eligibility_failed
 * - Writes AuditEvent for the state transition
 *
 * All operations are in a single Prisma transaction.
 */
export async function runEligibilityCheck(
  prisma: PrismaClient,
  submissionId: string,
  inputs: EligibilityInputs,
  actorId: string
): Promise<RunEligibilityCheckResult> {
  return prisma.$transaction(async (tx) => {
    // 1. Load submission and its call
    const submission = await tx.submission.findUnique({
      where: { id: submissionId },
      include: { call: true },
    });

    if (!submission) {
      throw new Error(`Submission not found: ${submissionId}`);
    }

    // Eligibility check is only valid on submitted proposals
    // (or re-check from eligibility_failed per admin workflow)
    if (
      submission.status !== "submitted" &&
      submission.status !== "eligibility_failed"
    ) {
      throw new Error(
        `Eligibility check not allowed for submission in status: ${submission.status}`
      );
    }

    // 2. Build rule set from the call's configuration
    const ruleSet = buildRuleSetFromCall(submission.call);

    // 3. Evaluate eligibility — pure function, inputs recorded exactly
    const evaluation = evaluateEligibility(inputs, ruleSet);

    const newStatus =
      evaluation.status === "eligible" ? "eligible" : "eligibility_failed";

    // 4. Persist EligibilityRecord — records exact inputs and active rule set
    const eligibilityRecord = await tx.eligibilityRecord.create({
      data: {
        submission_id: submissionId,
        status: evaluation.status,
        inputs: inputs as object,
        active_rules: evaluation.active_rules,
        failure_reasons: evaluation.failure_reasons,
        evaluated_at: new Date(),
      },
    });

    // 5. Transition submission status
    await tx.submission.update({
      where: { id: submissionId },
      data: { status: newStatus },
    });

    // 6. Write AuditEvent for the state transition
    await tx.auditEvent.create({
      data: {
        event_type: "eligibility.evaluated",
        actor_id: actorId,
        target_type: "Submission",
        target_id: submissionId,
        payload: {
          eligibility_record_id: eligibilityRecord.id,
          previous_status: submission.status,
          new_status: newStatus,
          eligibility_status: evaluation.status,
          active_rules: evaluation.active_rules,
          failure_reasons: evaluation.failure_reasons,
          // Record exact inputs at evaluation time (spec constraint)
          evaluated_inputs: inputs,
        },
      },
    });

    return {
      eligibility_record_id: eligibilityRecord.id,
      status: evaluation.status,
      failure_reasons: evaluation.failure_reasons,
    };
  });
}
