
/**
 * Test helpers — exported for use in tests/unit/
 */

import type { EligibilityRuleSet } from "./evaluateEligibility.js";

export const defaultTestRuleSet: EligibilityRuleSet = {
  version: "v1.0.0",
  enabled_rules: [
    "submittedInEnglish",
    "alignedWithCall",
    "primaryObjectiveIsRd",
    "meetsEuropeanDimension",
    "requestedBudgetKEur",
  ],
  max_budget_k_eur: 500,
};
