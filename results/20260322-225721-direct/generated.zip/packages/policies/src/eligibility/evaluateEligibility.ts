
import type {
  EligibilityInputs,
  EligibilityEvaluation,
} from "../../../domain/src/entities/index.js";

/**
 * Eligibility check names — must match Call.enabled_eligibility_checks values.
 */
export type EligibilityCheckName =
  | "submittedInEnglish"
  | "alignedWithCall"
  | "primaryObjectiveIsRd"
  | "meetsEuropeanDimension"
  | "requestedBudgetKEur"
  | "firstTimeApplicant";

export interface EligibilityRuleSet {
  enabled_checks: EligibilityCheckName[];
  max_budget_k_eur: number;
}

/**
 * Pure function — evaluates EligibilityInputs against the active rule set.
 *
 * Records exact input values and the active rule set at evaluation time
 * (constraint from specs/constraints.md).
 *
 * Returns EligibilityEvaluation with status, active_rules, and failure_reasons.
 */
export function evaluateEligibility(
  inputs: EligibilityInputs,
  ruleSet: EligibilityRuleSet
): EligibilityEvaluation {
  const failure_reasons: string[] = [];
  const active_rules: EligibilityCheckName[] = [...ruleSet.enabled_checks];

  // Run each enabled check
  for (const check of active_rules) {
    const failure = runCheck(check, inputs, ruleSet.max_budget_k_eur);
    if (failure !== null) {
      failure_reasons.push(failure);
    }
  }

  const status = failure_reasons.length === 0 ? "eligible" : "ineligible";

  return {
    status,
    active_rules,
    failure_reasons,
  };
}

/**
 * Runs a single named eligibility check.
 * Returns null if the check passes, or a failure reason string if it fails.
 */
function runCheck(
  check: EligibilityCheckName,
  inputs: EligibilityInputs,
  maxBudgetKEur: number
): string | null {
  switch (check) {
    case "submittedInEnglish":
      if (!inputs.submitted_in_english) {
        return "submittedInEnglish: proposal must be submitted in English";
      }
      return null;

    case "alignedWithCall":
      if (!inputs.aligned_with_call) {
        return "alignedWithCall: proposal must be aligned with the call objectives";
      }
      return null;

    case "primaryObjectiveIsRd":
      if (!inputs.primary_objective_is_rd) {
        return "primaryObjectiveIsRd: primary objective must be research and development";
      }
      return null;

    case "meetsEuropeanDimension":
      if (inputs.meets_european_dimension === "false") {
        return "meetsEuropeanDimension: proposal does not meet the European dimension requirement";
      }
      return null;

    case "requestedBudgetKEur":
      if (inputs.requested_budget_k_eur > maxBudgetKEur) {
        return `requestedBudgetKEur: requested budget ${inputs.requested_budget_k_eur}k EUR exceeds maximum ${maxBudgetKEur}k EUR`;
      }
      return null;

    case "firstTimeApplicant":
      // firstTimeApplicant is informational in P2 — does not gate eligibility by itself
      return null;

    default: {
      // TypeScript exhaustiveness check
      const _exhaustive: never = check;
      return `unknown check: ${_exhaustive}`;
    }
  }
}

/**
 * Builds an EligibilityRuleSet from a Call's configuration.
 */
export function buildRuleSetFromCall(call: {
  enabled_eligibility_checks: string[];
  max_budget_k_eur: number;
}): EligibilityRuleSet {
  const knownChecks: EligibilityCheckName[] = [
    "submittedInEnglish",
    "alignedWithCall",
    "primaryObjectiveIsRd",
    "meetsEuropeanDimension",
    "requestedBudgetKEur",
    "firstTimeApplicant",
  ];

  const enabled_checks = call.enabled_eligibility_checks.filter(
    (c): c is EligibilityCheckName => (knownChecks as string[]).includes(c)
  );

  return {
    enabled_checks,
    max_budget_k_eur: call.max_budget_k_eur,
  };
}
