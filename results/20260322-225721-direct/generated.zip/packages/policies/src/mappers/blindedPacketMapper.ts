
import type { BlindedPacketContent, AttachmentMeta } from "@repo/domain";

/**
 * Blinded packet mapper — strips ALL identity fields from proposal content.
 *
 * Fields explicitly excluded (per specs/access-policies.md):
 *   - legal_name
 *   - email
 *   - country
 *   - organisation
 *   - applicant_alias
 *
 * This function is the single authoritative stripping point. Any change to
 * identity field names must be reflected here and verified by golden test.
 */
export function buildBlindedPacketContent(
  proposalVersion: {
    id: string;
    submission_id: string;
    version_number: number;
    title: string;
    abstract: string;
    requested_budget_k_eur: number;
    budget_usage: string;
    tasks_breakdown: Record<string, unknown>;
    attachments_meta: unknown;
  },
  submissionId: string
): BlindedPacketContent {
  const rawAttachments = Array.isArray(proposalVersion.attachments_meta)
    ? (proposalVersion.attachments_meta as AttachmentMeta[])
    : [];

  // Strip storage_key from attachment metadata — reviewers do not need raw storage references
  const sanitizedAttachments = rawAttachments.map((a) => ({
    filename: a.filename,
    mime_type: a.mime_type,
    size_bytes: a.size_bytes,
  }));

  return {
    proposal_version_id: proposalVersion.id,
    submission_id: submissionId,
    version_number: proposalVersion.version_number,
    title: proposalVersion.title,
    abstract: proposalVersion.abstract,
    requested_budget_k_eur: proposalVersion.requested_budget_k_eur,
    budget_usage: proposalVersion.budget_usage,
    tasks_breakdown: proposalVersion.tasks_breakdown,
    attachments_meta: sanitizedAttachments,
  };
}
