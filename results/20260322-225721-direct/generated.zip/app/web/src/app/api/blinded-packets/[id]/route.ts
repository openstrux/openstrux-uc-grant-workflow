
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/server/db/prisma";
import { requireAuth } from "@/server/auth/middleware";
import { checkAccess, logAccessDecision } from "@repo/policies";
import type { ProposalStatus } from "@repo/domain";

/**
 * GET /api/blinded-packets/[id]
 *
 * Returns a blinded packet. Access is restricted to:
 * - Reviewers: only for assigned submissions, in permitted states
 * - Admins: all blinded packets
 *
 * INVARIANT: No identity fields are present in the blinded packet content.
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  const authResult = await requireAuth(request);
  if (authResult instanceof Response) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { principal } = authResult;

  const { id } = await params;

  // Fetch blinded packet with submission status for access check
  const blindedPacket = await prisma.blindedPacket.findUnique({
    where: { id },
    include: {
      proposal_version: {
        include: {
          submission: {
            select: {
              id: true,
              status: true,
              // Never select applicant_alias in this path
            },
          },
        },
      },
    },
  });

  if (!blindedPacket) {
    return NextResponse.json({ error: "Not Found" }, { status: 404 });
  }

  const submissionId = blindedPacket.proposal_version.submission.id;
  const submissionStatus = blindedPacket.proposal_version.submission.status as ProposalStatus;

  const accessCtx = {
    principal,
    resource_type: "BlindedPacket" as const,
    resource_id: id,
    operation: "read" as const,
    resource_meta: {
      submission_id: submissionId,
      status: submissionStatus,
    },
  };

  const decision = checkAccess(accessCtx);
  await logAccessDecision(prisma, accessCtx, decision);

  if (!decision.allowed) {
    return NextResponse.json(
      { error: "Forbidden", message: decision.reason },
      { status: 403 }
    );
  }

  // Return only the blinded content — identity is structurally absent
  return NextResponse.json({
    id: blindedPacket.id,
    proposal_version_id: blindedPacket.proposal_version_id,
    content: blindedPacket.content,
    created_at: blindedPacket.created_at,
  });
}
