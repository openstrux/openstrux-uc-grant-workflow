
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "../../../lib/prisma.js";
import { extractPrincipal, AuthError } from "../../../server/auth/middleware.js";
import { checkAccess } from "../../../../../packages/policies/src/access/checkAccess.js";
import { submitProposal } from "../../../../../packages/policies/src/workflow/submitProposal.js";
import { IntakeInputSchema } from "../../../../../packages/domain/src/schemas/index.js";

/**
 * POST /api/intake
 *
 * Creates a new submission for a funding call.
 * Principal must be `applicant`.
 *
 * Body: IntakeInput
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  // 1. Authenticate and extract principal
  let principal;
  try {
    principal = await extractPrincipal(req);
  } catch (err) {
    if (err instanceof AuthError) {
      return NextResponse.json({ error: err.message }, { status: err.statusCode });
    }
    return NextResponse.json({ error: "Authentication failed" }, { status: 401 });
  }

  // 2. Authorisation — only applicants can submit proposals
  const accessDecision = checkAccess(
    principal,
    { type: "Submission", id: "new", ownerId: principal.id },
    "write"
  );

  // Log access decision audit event
  await prisma.auditEvent.create({
    data: {
      event_type: "access",
      actor_id: principal.id,
      target_type: "Submission",
      target_id: "new",
      payload: {
        operation: "write",
        allowed: accessDecision.allowed,
        reason: accessDecision.reason,
        route: "POST /api/intake",
      },
    },
  });

  if (!accessDecision.allowed) {
    return NextResponse.json(
      { error: "Access denied", reason: accessDecision.reason },
      { status: 403 }
    );
  }

  // 3. Validate request body
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const parseResult = IntakeInputSchema.safeParse(body);
  if (!parseResult.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parseResult.error.flatten() },
      { status: 422 }
    );
  }

  const input = parseResult.data;

  // 4. Submit proposal via service
  try {
    const result = await submitProposal(prisma, input, principal.id);
    return NextResponse.json(result, { status: 201 });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Submission failed";

    // Determine appropriate status code
    if (
      message.includes("not found") ||
      message.includes("not open") ||
      message.includes("not currently active")
    ) {
      return NextResponse.json({ error: message }, { status: 422 });
    }

    console.error("[POST /api/intake]", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
