
import { NextResponse } from "next/server";

/**
 * P6 — Audit / lifecycle export
 * Stub: returns 501 Not Implemented per mvp-profile.md
 */
export async function GET(): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", phase: "P6", message: "Audit export not active in P0-P2 MVP" },
    { status: 501 }
  );
}
