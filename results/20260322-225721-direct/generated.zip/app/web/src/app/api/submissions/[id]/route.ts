
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "../../../../lib/prisma.js";
import { extractPrincipal, AuthError } from "../../../../server/auth/middleware.js";
import { checkAccess } from "../../../../../../packages/policies/src/access/checkAccess.js";

interface RouteContext {
  params: Promise<{ id: string }>;
}

/**
 * GET /api/submissions/[id]
 *
 * Returns a single submission.
 * - applicant: own submissions only, no identity data returned
 * - admin: full submission, no identity data in this response (use /api/identity/[id])
 * - reviewer: forbidden
 */
export async function GET(
  req: NextRequest,
  context: RouteContext
): Promise<NextResponse> {
  const { id } = await context.params;

  let principal;
  try {
    principal = await extractPrincipal(req);
  } catch (err) {
    if (err instanceof AuthError) {
      return NextResponse.json({ error: err.message }, { status: err.statusCode });
    }
    return NextResponse.json({ error: "Authentication failed" }, { status: 401 });
  }

  // Load submission to determine ownership before access check
  const submission = await prisma.submission.findUnique({
    where: { id },
    include: {
      proposal_versions: {
        where: { is_effective: true },
        select: {
          id: true,
          version_number: true,
          title: true,
          abstract: true,
          requested_budget_k_eur: true,
          budget_usage: true,
          tasks_breakdown: true,
          attachments_meta: true,
          created_at: true,
        },
      },
      // applicant_identity intentionally excluded
    },
  });

  if (!submission) {
    return NextResponse.json({ error: "Submission not found" }, { status: 404 });
  }

  const accessDecision = checkAccess(
    principal,
    {
      type: "Submission",
      id: submission.id,
      ownerId: submission.applicant_alias,
    },
    "read"
  );

  await prisma.auditEvent.create({
    data: {
      event_type: "access",
      actor_id: principal.id,
      target_type: "Submission",
      target_id: id,
      payload: {
        operation: "read",
        allowed: accessDecision.allowed,
        reason: accessDecision.reason,
        route: `GET /api/submissions/${id}`,
      },
    },
  });

  if (!accessDecision.allowed) {
    return NextResponse.json(
      { error: "Access denied", reason: accessDecision.reason },
      { status: 403 }
    );
  }

  // Never expose applicant_alias to reviewers
  // (reviewers are denied above, but belt-and-suspenders)
  if (principal.role === "reviewer") {
    return NextResponse.json({ error: "Access denied" }, { status: 403 });
  }

  return NextResponse.json(submission);
}
