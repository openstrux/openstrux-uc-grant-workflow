
import { NextResponse } from "next/server";

/**
 * P4 — Clarification
 * Stub: returns 501 Not Implemented per mvp-profile.md
 */
export async function GET(): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", phase: "P4", message: "Clarification phase not active in P0-P2 MVP" },
    { status: 501 }
  );
}

export async function POST(): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", phase: "P4", message: "Clarification phase not active in P0-P2 MVP" },
    { status: 501 }
  );
}
