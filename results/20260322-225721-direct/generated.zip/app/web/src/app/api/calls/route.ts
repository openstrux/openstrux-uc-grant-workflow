
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "../../../lib/prisma.js";
import { extractPrincipal, AuthError } from "../../../server/auth/middleware.js";
import { checkAccess } from "../../../../../packages/policies/src/access/checkAccess.js";
import { CreateCallInputSchema } from "../../../../../packages/domain/src/schemas/index.js";

/**
 * GET /api/calls
 * List all open calls. Accessible to applicants and admins.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  let principal;
  try {
    principal = await extractPrincipal(req);
  } catch (err) {
    if (err instanceof AuthError) {
      return NextResponse.json({ error: err.message }, { status: err.statusCode });
    }
    return NextResponse.json({ error: "Authentication failed" }, { status: 401 });
  }

  const accessDecision = checkAccess(
    principal,
    { type: "Call", id: "list" },
    "read"
  );

  if (!accessDecision.allowed) {
    return NextResponse.json(
      { error: "Access denied", reason: accessDecision.reason },
      { status: 403 }
    );
  }

  const calls = await prisma.call.findMany({
    where:
      principal.role === "applicant" ? { status: "open" } : undefined,
    orderBy: { open_date: "desc" },
  });

  return NextResponse.json(calls);
}

/**
 * POST /api/calls
 * Create a new call. Admin only.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  let principal;
  try {
    principal = await extractPrincipal(req);
  } catch (err) {
    if (err instanceof AuthError) {
      return NextResponse.json({ error: err.message }, { status: err.statusCode });
    }
    return NextResponse.json({ error: "Authentication failed" }, { status: 401 });
  }

  const accessDecision = checkAccess(
    principal,
    { type: "Call", id: "new" },
    "write"
  );

  await prisma.auditEvent.create({
    data: {
      event_type: "access",
      actor_id: principal.id,
      target_type: "Call",
      target_id: "new",
      payload: {
        operation: "write",
        allowed: accessDecision.allowed,
        reason: accessDecision.reason,
        route: "POST /api/calls",
      },
    },
  });

  if (!accessDecision.allowed) {
    return NextResponse.json(
      { error: "Access denied", reason: accessDecision.reason },
      { status: 403 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const parseResult = CreateCallInputSchema.safeParse(body);
  if (!parseResult.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parseResult.error.flatten() },
      { status: 422 }
    );
  }

  const input = parseResult.data;

  try {
    const call = await prisma.call.create({
      data: {
        ...input,
        status: "draft",
        reviewer_policy_version: input.reviewer_policy_version,
      },
    });

    await prisma.auditEvent.create({
      data: {
        event_type: "call.created",
        actor_id: principal.id,
        target_type: "Call",
        target_id: call.id,
        payload: { title: call.title, status: call.status },
      },
    });

    return NextResponse.json(call, { status: 201 });
  } catch (err) {
    console.error("[POST /api/calls]", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
