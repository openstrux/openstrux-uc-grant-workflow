
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "../../../lib/prisma.js";
import { extractPrincipal, AuthError } from "../../../server/auth/middleware.js";
import { checkAccess } from "../../../../../packages/policies/src/access/checkAccess.js";

/**
 * GET /api/submissions
 *
 * Lists submissions.
 * - applicant: their own submissions only
 * - admin: all submissions
 * - reviewer: forbidden (use /api/blinded-packets)
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  let principal;
  try {
    principal = await extractPrincipal(req);
  } catch (err) {
    if (err instanceof AuthError) {
      return NextResponse.json({ error: err.message }, { status: err.statusCode });
    }
    return NextResponse.json({ error: "Authentication failed" }, { status: 401 });
  }

  const accessDecision = checkAccess(
    principal,
    { type: "Submission", id: "list", ownerId: principal.id },
    "read"
  );

  if (!accessDecision.allowed) {
    return NextResponse.json(
      { error: "Access denied", reason: accessDecision.reason },
      { status: 403 }
    );
  }

  const where =
    principal.role === "applicant"
      ? { applicant_alias: principal.id }
      : undefined;

  // Never include ApplicantIdentity in the list response — separate data path
  const submissions = await prisma.submission.findMany({
    where,
    include: {
      proposal_versions: {
        where: { is_effective: true },
        select: {
          id: true,
          version_number: true,
          title: true,
          abstract: true,
          requested_budget_k_eur: true,
          created_at: true,
          // Explicitly exclude: submission_id is present but applicant fields are not
        },
      },
      // applicant_identity intentionally excluded from response
    },
    orderBy: { created_at: "desc" },
  });

  return NextResponse.json(submissions);
}
