
import { NextResponse } from "next/server";

/**
 * P3 — Review
 * Stub: returns 501 Not Implemented per mvp-profile.md
 */
export async function GET(): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", phase: "P3", message: "Review phase not active in P0-P2 MVP" },
    { status: 501 }
  );
}

export async function POST(): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", phase: "P3", message: "Review phase not active in P0-P2 MVP" },
    { status: 501 }
  );
}
