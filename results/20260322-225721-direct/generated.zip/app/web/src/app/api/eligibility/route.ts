
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "../../../lib/prisma.js";
import { extractPrincipal, AuthError } from "../../../server/auth/middleware.js";
import { checkAccess } from "../../../../../packages/policies/src/access/checkAccess.js";
import { runEligibilityCheck } from "../../../../../packages/policies/src/workflow/runEligibilityCheck.js";
import { EligibilityCheckInputSchema } from "../../../../../packages/domain/src/schemas/index.js";

/**
 * POST /api/eligibility
 *
 * Runs the eligibility gate for a given submission.
 * Principal must be `admin`.
 *
 * Body: EligibilityCheckInput
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  // 1. Authenticate
  let principal;
  try {
    principal = await extractPrincipal(req);
  } catch (err) {
    if (err instanceof AuthError) {
      return NextResponse.json({ error: err.message }, { status: err.statusCode });
    }
    return NextResponse.json({ error: "Authentication failed" }, { status: 401 });
  }

  // 2. Authorise — only admins can trigger eligibility evaluation
  const accessDecision = checkAccess(
    principal,
    { type: "EligibilityRecord", id: "new" },
    "write"
  );

  await prisma.auditEvent.create({
    data: {
      event_type: "access",
      actor_id: principal.id,
      target_type: "EligibilityRecord",
      target_id: "new",
      payload: {
        operation: "write",
        allowed: accessDecision.allowed,
        reason: accessDecision.reason,
        route: "POST /api/eligibility",
      },
    },
  });

  if (!accessDecision.allowed) {
    return NextResponse.json(
      { error: "Access denied", reason: accessDecision.reason },
      { status: 403 }
    );
  }

  // 3. Validate body
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const parseResult = EligibilityCheckInputSchema.safeParse(body);
  if (!parseResult.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parseResult.error.flatten() },
      { status: 422 }
    );
  }

  const { submission_id, inputs } = parseResult.data;

  // 4. Run eligibility check
  try {
    const result = await runEligibilityCheck(
      prisma,
      submission_id,
      inputs,
      principal.id
    );
    return NextResponse.json(result, { status: 200 });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Eligibility check failed";

    if (message.includes("not found")) {
      return NextResponse.json({ error: message }, { status: 404 });
    }
    if (message.includes("not allowed")) {
      return NextResponse.json({ error: message }, { status: 422 });
    }

    console.error("[POST /api/eligibility]", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
