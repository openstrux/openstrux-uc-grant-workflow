
import { NextRequest } from "next/server";
import { z } from "zod";
import { PrincipalSchema } from "../../../../packages/domain/src/schemas/index.js";
import type { Principal } from "../../../../packages/domain/src/entities/index.js";

const RoleSchema = z.enum([
  "applicant",
  "admin",
  "reviewer",
  "validator",
  "auditor",
]);

/**
 * JWT payload structure (minimal for P0-P2).
 * In production this would be verified against a signing key.
 */
interface JwtPayload {
  sub: string;
  role: z.infer<typeof RoleSchema>;
  assigned_proposals?: string[];
  iat?: number;
  exp?: number;
}

export class AuthError extends Error {
  constructor(
    message: string,
    public readonly statusCode: number = 401
  ) {
    super(message);
    this.name = "AuthError";
  }
}

/**
 * Extracts and validates the principal from an incoming request.
 *
 * Strategy (P0-P2, no external IdP):
 * 1. Check Authorization: Bearer <jwt> header — decode and verify
 * 2. Dev-mode fallback: X-Role header (for testing without JWT signing)
 *
 * Returns a validated Principal or throws AuthError.
 */
export async function extractPrincipal(req: NextRequest): Promise<Principal> {
  // Dev-mode: X-Role header support
  // Only active when NODE_ENV !== "production"
  if (process.env.NODE_ENV !== "production") {
    const devRole = req.headers.get("x-role");
    const devUserId = req.headers.get("x-user-id");
    const devAssigned = req.headers.get("x-assigned-proposals");

    if (devRole) {
      const roleResult = RoleSchema.safeParse(devRole);
      if (!roleResult.success) {
        throw new AuthError(`Invalid X-Role header value: ${devRole}`, 401);
      }

      const principal: Principal = {
        id: devUserId ?? `dev-${devRole}-user`,
        role: roleResult.data,
        assigned_proposals: devAssigned ? devAssigned.split(",").map((s) => s.trim()) : [],
      };

      return PrincipalSchema.parse(principal);
    }
  }

  // Production: JWT from Authorization header
  const authHeader = req.headers.get("authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    throw new AuthError("Missing or invalid Authorization header", 401);
  }

  const token = authHeader.slice(7);
  const payload = decodeJwt(token);

  const roleResult = RoleSchema.safeParse(payload.role);
  if (!roleResult.success) {
    throw new AuthError(`Invalid role in JWT: ${payload.role}`, 401);
  }

  const principal: Principal = {
    id: payload.sub,
    role: roleResult.data,
    assigned_proposals: payload.assigned_proposals ?? [],
  };

  return PrincipalSchema.parse(principal);
}

/**
 * Minimal JWT decoder for P0-P2 (no signature verification in dev).
 * TODO: Add proper HMAC/RSA verification before production deployment.
 */
function decodeJwt(token: string): JwtPayload {
  const parts = token.split(".");
  if (parts.length !== 3) {
    throw new AuthError("Malformed JWT token", 401);
  }

  try {
    const payloadPart = parts[1];
    if (!payloadPart) {
      throw new AuthError("Malformed JWT token — missing payload", 401);
    }
    const decoded = Buffer.from(payloadPart, "base64url").toString("utf8");
    const payload = JSON.parse(decoded) as JwtPayload;

    if (!payload.sub || !payload.role) {
      throw new AuthError("JWT payload missing required fields (sub, role)", 401);
    }

    // Check expiry if present
    if (payload.exp && Date.now() / 1000 > payload.exp) {
      throw new AuthError("JWT token has expired", 401);
    }

    return payload;
  } catch (err) {
    if (err instanceof AuthError) throw err;
    throw new AuthError("Failed to decode JWT token", 401);
  }
}

/**
 * Writes an access-decision audit event.
 * Called by route handlers after checkAccess() to satisfy audit requirements.
 */
export function buildAccessAuditPayload(
  principal: Principal,
  resourceType: string,
  resourceId: string,
  operation: string,
  allowed: boolean,
  reason: string
): Record<string, unknown> {
  return {
    principal_id: principal.id,
    principal_role: principal.role,
    resource_type: resourceType,
    resource_id: resourceId,
    operation,
    allowed,
    reason,
    event_type: "access",
  };
}
