
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main(): Promise<void> {
  // Default call from specs/mvp-profile.md
  await prisma.call.upsert({
    where: { id: "eu-oss-fund-2026" },
    update: {},
    create: {
      id: "eu-oss-fund-2026",
      title: "EU Open Source Fund 2026",
      description:
        "Funding for open source projects with a clear European dimension and R&D primary objective.",
      open_date: new Date("2025-09-01T00:00:00Z"),
      close_date: new Date("2026-03-31T23:59:59Z"),
      status: "open",
      enabled_eligibility_checks: [
        "submittedInEnglish",
        "alignedWithCall",
        "primaryObjectiveIsRd",
        "meetsEuropeanDimension",
        "requestedBudgetKEur",
      ],
      max_budget_k_eur: 500,
      reviewer_policy_version: "v1.0.0",
    },
  });

  console.log("Seed complete: default call 'eu-oss-fund-2026' upserted.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
