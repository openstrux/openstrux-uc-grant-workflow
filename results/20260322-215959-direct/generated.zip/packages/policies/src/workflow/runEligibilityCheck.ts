
import { prisma } from "../../domain/src/lib/prisma.js";
import {
  evaluateEligibility,
  filterValidRuleNames,
} from "../eligibility/evaluateEligibility.js";
import { assertAccess } from "../access/checkAccess.js";
import type {
  Principal,
  EligibilityInputs,
  EligibilityCheckName,
  ProposalStatus,
  RunEligibilityCheckResult,
  Task,
  AttachmentMeta,
} from "../../domain/src/entities/index.js";
import { mapToBlindedContent } from "../intake/blindedPacketMapper.js";

export interface RunEligibilityCheckParams {
  submission_id: string;
  inputs: EligibilityInputs;
}

/**
 * Runs the eligibility gate for a submission:
 * 1. Loads the call's active rule set
 * 2. Evaluates the provided inputs (pure)
 * 3. Persists the EligibilityRecord with exact inputs + active rules
 * 4. Transitions submission status
 * 5. If newly eligible, generates/updates the BlindedPacket
 * 6. Writes an AuditEvent
 *
 * Only admins may trigger eligibility checks (per access policies).
 */
export async function runEligibilityCheck(
  params: RunEligibilityCheckParams,
  principal: Principal
): Promise<RunEligibilityCheckResult> {
  // Access check: only admins may run eligibility checks
  assertAccess({
    principal,
    resource: "EligibilityRecord",
    operation: "write",
  });

  return prisma.$transaction(async (tx) => {
    // 1. Load the submission and its call
    const submission = await tx.submission.findUnique({
      where: { id: params.submission_id },
      include: {
        call: true,
        proposal_versions: {
          where: { is_effective: true },
        },
      },
    });

    if (!submission) {
      throw new Error(`Submission '${params.submission_id}' not found.`);
    }

    if (submission.status !== "submitted") {
      throw new Error(
        `Eligibility check requires status 'submitted'; current status is '${submission.status}'.`
      );
    }

    const call = submission.call;

    // 2. Determine the active rule set from the call config
    const { valid: activeRules, unknown: unknownRules } = filterValidRuleNames(
      call.enabled_eligibility_checks
    );

    // Log unknown rule names but do not fail — admin must be able to proceed
    if (unknownRules.length > 0) {
      console.warn(
        `[runEligibilityCheck] Unknown rule names in call config: ${unknownRules.join(", ")}`
      );
    }

    // 3. Evaluate (pure function — no side effects)
    const evaluation = evaluateEligibility(params.inputs, activeRules, {
      max_budget_k_eur: call.max_budget_k_eur,
    });

    // 4. Determine new submission status
    const newStatus: ProposalStatus =
      evaluation.status === "eligible" ? "eligible" : "eligibility_failed";

    const now = new Date();

    // 5. Persist the EligibilityRecord with exact inputs captured
    const eligibilityRecord = await tx.eligibilityRecord.create({
      data: {
        submission_id: params.submission_id,
        status: evaluation.status,
        inputs: params.inputs as Record<string, unknown>,
        active_rules: evaluation.active_rules,
        failure_reasons: evaluation.failure_reasons,
        evaluated_at: now,
      },
    });

    // 6. Update submission status
    await tx.submission.update({
      where: { id: params.submission_id },
      data: { status: newStatus },
    });

    // 7. If newly eligible, ensure a BlindedPacket exists for the effective version
    if (evaluation.status === "eligible") {
      const effectiveVersion = submission.proposal_versions[0];
      if (effectiveVersion) {
        // Check if a BlindedPacket already exists (e.g. created at submission time)
        const existingPacket = await tx.blindedPacket.findUnique({
          where: { proposal_version_id: effectiveVersion.id },
        });

        if (!existingPacket) {
          const blindedContent = mapToBlindedContent({
            id: effectiveVersion.id,
            submission_id: effectiveVersion.submission_id,
            version_number: effectiveVersion.version_number,
            is_effective: effectiveVersion.is_effective,
            title: effectiveVersion.title,
            abstract: effectiveVersion.abstract,
            requested_budget_k_eur: effectiveVersion.requested_budget_k_eur,
            budget_usage: effectiveVersion.budget_usage,
            tasks_breakdown: effectiveVersion.tasks_breakdown as Task[],
            attachments_meta: effectiveVersion.attachments_meta as AttachmentMeta[],
          });

          await tx.blindedPacket.create({
            data: {
              proposal_version_id: effectiveVersion.id,
              content: blindedContent,
            },
          });
        }
      }
    }

    // 8. Write AuditEvent for the state transition
    await tx.auditEvent.create({
      data: {
        event_type: "eligibility.checked",
        actor_id: principal.id,
        target_type: "Submission",
        target_id: params.submission_id,
        payload: {
          eligibility_record_id: eligibilityRecord.id,
          previous_status: "submitted",
          new_status: newStatus,
          eligibility_status: evaluation.status,
          failure_reasons: evaluation.failure_reasons,
          active_rules: evaluation.active_rules,
        },
        timestamp: now,
      },
    });

    return {
      eligibility_record_id: eligibilityRecord.id,
      status: evaluation.status,
      failure_reasons: evaluation.failure_reasons,
    };
  });
}
