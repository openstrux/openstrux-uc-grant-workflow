
import { prisma } from "../../domain/src/lib/prisma.js";
import { mapToBlindedContent } from "../intake/blindedPacketMapper.js";
import type {
  Principal,
  SubmitProposalResult,
  Task,
  AttachmentMeta,
} from "../../domain/src/entities/index.js";
import { assertAccess } from "../access/checkAccess.js";

export interface SubmitProposalParams {
  call_id: string;
  title: string;
  abstract: string;
  requested_budget_k_eur: number;
  budget_usage: string;
  tasks_breakdown: Task[];
  attachments_meta: AttachmentMeta[];
  // Identity fields (handled in a separate data path)
  legal_name: string;
  email: string;
  country: string;
  organisation: string;
}

/**
 * Creates a new submission with an initial ProposalVersion, ApplicantIdentity,
 * BlindedPacket, and AuditEvent in a single Prisma transaction.
 *
 * Identity separation: ApplicantIdentity is written in the same transaction but
 * is stored in a separate table and is never included in the returned result.
 */
export async function submitProposal(
  params: SubmitProposalParams,
  principal: Principal
): Promise<SubmitProposalResult> {
  // Access check: only applicants (and admins) may submit
  assertAccess({
    principal,
    resource: "Submission",
    operation: "write",
  });

  // Determine the applicant alias from the principal
  const applicantAlias =
    principal.alias ?? principal.id;

  return prisma.$transaction(async (tx) => {
    // 1. Verify the call exists and is open
    const call = await tx.call.findUnique({
      where: { id: params.call_id },
    });

    if (!call) {
      throw new Error(`Call '${params.call_id}' not found.`);
    }

    const now = new Date();
    if (call.status !== "open") {
      throw new Error(`Call '${params.call_id}' is not open (status: ${call.status}).`);
    }
    if (now < call.open_date || now > call.close_date) {
      throw new Error(`Call '${params.call_id}' is outside its submission window.`);
    }

    // 2. Create the Submission
    const submission = await tx.submission.create({
      data: {
        call_id: params.call_id,
        applicant_alias: applicantAlias,
        status: "submitted",
        submitted_at: now,
      },
    });

    // 3. Create the initial ProposalVersion
    const proposalVersion = await tx.proposalVersion.create({
      data: {
        submission_id: submission.id,
        version_number: 1,
        is_effective: true,
        title: params.title,
        abstract: params.abstract,
        requested_budget_k_eur: params.requested_budget_k_eur,
        budget_usage: params.budget_usage,
        tasks_breakdown: params.tasks_breakdown,
        attachments_meta: params.attachments_meta,
      },
    });

    // 4. Create the ApplicantIdentity (separate data path)
    await tx.applicantIdentity.create({
      data: {
        submission_id: submission.id,
        legal_name: params.legal_name,
        email: params.email,
        country: params.country,
        organisation: params.organisation,
      },
    });

    // 5. Generate the BlindedPacket immediately on submission
    const blindedContent = mapToBlindedContent({
      id: proposalVersion.id,
      submission_id: proposalVersion.submission_id,
      version_number: proposalVersion.version_number,
      is_effective: proposalVersion.is_effective,
      title: proposalVersion.title,
      abstract: proposalVersion.abstract,
      requested_budget_k_eur: proposalVersion.requested_budget_k_eur,
      budget_usage: proposalVersion.budget_usage,
      tasks_breakdown: proposalVersion.tasks_breakdown as Task[],
      attachments_meta: proposalVersion.attachments_meta as AttachmentMeta[],
    });

    await tx.blindedPacket.create({
      data: {
        proposal_version_id: proposalVersion.id,
        content: blindedContent,
      },
    });

    // 6. Write AuditEvent
    await tx.auditEvent.create({
      data: {
        event_type: "submission.created",
        actor_id: principal.id,
        target_type: "Submission",
        target_id: submission.id,
        payload: {
          call_id: params.call_id,
          version_number: 1,
          requested_budget_k_eur: params.requested_budget_k_eur,
          status: "submitted",
        },
        timestamp: now,
      },
    });

    return {
      submission_id: submission.id,
      proposal_version_id: proposalVersion.id,
      status: "submitted",
    };
  });
}
