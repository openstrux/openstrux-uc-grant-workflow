
import type {
  AccessRequest,
  AccessResult,
  Principal,
  ProposalStatus,
} from "../../../domain/src/entities/index.js";

// ─── Policy implementations ───────────────────────────────────────────────────

/**
 * POLICY: applicant-own-proposals
 * Applicants can read/write their own submissions (not BlindedPacket or
 * EligibilityRecord.failure_reasons which is handled at serialisation time).
 * Write access is limited to states where the spec grants it.
 */
function evaluateApplicantPolicy(req: AccessRequest): AccessResult {
  const { resource, operation, context } = req;
  const principal = req.principal;

  // Applicants can never access ApplicantIdentity of others or BlindedPackets
  if (resource === "ApplicantIdentity") {
    // They may only access their own identity record indirectly (never via reviewer path)
    if (context?.applicantAlias && context.applicantAlias !== principal.alias) {
      return deny("applicant-own-proposals", "Applicants may only access their own identity.");
    }
  }

  if (resource === "BlindedPacket") {
    return deny("applicant-own-proposals", "Applicants do not have access to blinded packets.");
  }

  if (resource === "AuditEvent") {
    return deny("applicant-own-proposals", "Applicants may not access audit events.");
  }

  // Ownership check: must be own submission
  if (context?.applicantAlias && context.applicantAlias !== principal.alias) {
    return deny("applicant-own-proposals", "Applicants may only access their own submissions.");
  }

  // Write access is state-gated per workflow-states.md
  if (operation === "write") {
    const writeableStates: ProposalStatus[] = ["draft", "clarification_requested"];
    const currentStatus = context?.submissionStatus;
    if (currentStatus !== undefined && !writeableStates.includes(currentStatus)) {
      return deny(
        "applicant-own-proposals",
        `Applicants cannot write to submissions in state '${currentStatus}'.`
      );
    }
  }

  if (operation === "delete") {
    return deny("applicant-own-proposals", "Applicants may not delete records.");
  }

  return allow("applicant-own-proposals", "Applicant accessing own proposal.");
}

/**
 * POLICY: admin-all
 * Admins have read/write/delete to all entities. Deletion must be audit-logged
 * (enforced at service layer).
 */
function evaluateAdminPolicy(req: AccessRequest): AccessResult {
  return allow("admin-all", "Admin has full access.");
}

/**
 * POLICY: reviewer-blinded-assigned + deny-identity-to-reviewer
 */
function evaluateReviewerPolicy(req: AccessRequest): AccessResult {
  const { resource, operation, context } = req;
  const principal = req.principal;

  // Hard deny: reviewer may never access ApplicantIdentity
  if (resource === "ApplicantIdentity") {
    return deny(
      "deny-identity-to-reviewer",
      "Reviewers are explicitly denied access to ApplicantIdentity."
    );
  }

  // Hard deny: reviewer may never access Submission (contains applicant_alias)
  if (resource === "Submission") {
    return deny(
      "deny-identity-to-reviewer",
      "Reviewers may not access Submission records directly (contains identity fields)."
    );
  }

  if (resource === "AuditEvent") {
    return deny("reviewer-blinded-assigned", "Reviewers may not access audit events.");
  }

  if (resource === "Call") {
    // Reviewers may read call metadata (no identity data)
    if (operation === "read") {
      return allow("reviewer-blinded-assigned", "Reviewer may read call metadata.");
    }
    return deny("reviewer-blinded-assigned", "Reviewers may not write to calls.");
  }

  if (resource === "BlindedPacket") {
    if (operation !== "read") {
      return deny("reviewer-blinded-assigned", "Reviewers may only read blinded packets.");
    }
    // Must be assigned to this submission
    if (context?.submissionId !== undefined) {
      const assigned = principal.assignedSubmissionIds ?? [];
      if (!assigned.includes(context.submissionId)) {
        return deny(
          "reviewer-blinded-assigned",
          "Reviewer is not assigned to this submission."
        );
      }
    }
    return allow("reviewer-blinded-assigned", "Reviewer accessing assigned blinded packet.");
  }

  // EligibilityRecord — reviewers may read (without failure_reasons: stripped at serialisation)
  if (resource === "EligibilityRecord") {
    if (operation === "read") {
      if (context?.submissionId !== undefined) {
        const assigned = principal.assignedSubmissionIds ?? [];
        if (!assigned.includes(context.submissionId)) {
          return deny(
            "reviewer-blinded-assigned",
            "Reviewer is not assigned to this submission."
          );
        }
      }
      return allow("reviewer-blinded-assigned", "Reviewer accessing eligibility status of assigned submission.");
    }
    return deny("reviewer-blinded-assigned", "Reviewers may not write eligibility records.");
  }

  return deny("reviewer-blinded-assigned", `Reviewer has no access to resource '${resource}'.`);
}

/**
 * POLICY: validator (P5+) — stub
 */
function evaluateValidatorPolicy(_req: AccessRequest): AccessResult {
  return deny("validator-stub", "Validator role is not active in this phase (P5+).");
}

/**
 * POLICY: auditor — read-only access to AuditEvent
 */
function evaluateAuditorPolicy(req: AccessRequest): AccessResult {
  if (req.resource === "AuditEvent" && req.operation === "read") {
    return allow("auditor-read-audit", "Auditor reading audit events.");
  }
  return deny("auditor-read-audit", "Auditors may only read audit events.");
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function allow(policyName: string, reason: string): AccessResult {
  return { allowed: true, reason, policyName };
}

function deny(policyName: string, reason: string): AccessResult {
  return { allowed: false, reason, policyName };
}

// ─── Main export ──────────────────────────────────────────────────────────────

/**
 * Evaluates access for a given principal + resource + operation.
 * This is the single enforcement point for all access policies.
 */
export function checkAccess(req: AccessRequest): AccessResult {
  const { principal } = req;

  switch (principal.role) {
    case "applicant":
      return evaluateApplicantPolicy(req);
    case "admin":
      return evaluateAdminPolicy(req);
    case "reviewer":
      return evaluateReviewerPolicy(req);
    case "validator":
      return evaluateValidatorPolicy(req);
    case "auditor":
      return evaluateAuditorPolicy(req);
    default: {
      // Exhaustive check
      const _exhaustive: never = principal.role;
      return deny("unknown-role", `Unknown role: ${String(_exhaustive)}`);
    }
  }
}

/**
 * Asserts access is allowed; throws if denied.
 * Use in service layer to fail fast.
 */
export function assertAccess(req: AccessRequest): void {
  const result = checkAccess(req);
  if (!result.allowed) {
    const err = new AccessDeniedError(result.reason, result.policyName);
    throw err;
  }
}

export class AccessDeniedError extends Error {
  public readonly policyName: string;

  constructor(reason: string, policyName: string) {
    super(`Access denied [${policyName}]: ${reason}`);
    this.name = "AccessDeniedError";
    this.policyName = policyName;
  }
}
