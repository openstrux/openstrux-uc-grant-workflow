
import type {
  EligibilityInputs,
  EligibilityCheckName,
  EligibilityRule,
  EligibilityRuleConfig,
  EligibilityRuleResult,
  EligibilityEvaluation,
  EligibilityStatus,
} from "../../../domain/src/entities/index.js";

// ─── Individual rule implementations ────────────────────────────────────────

const submittedInEnglishRule: EligibilityRule = {
  name: "submittedInEnglish",
  evaluate(inputs: EligibilityInputs, _config: EligibilityRuleConfig): EligibilityRuleResult {
    if (!inputs.submitted_in_english) {
      return { passed: false, failure_reason: "Proposal must be submitted in English." };
    }
    return { passed: true };
  },
};

const alignedWithCallRule: EligibilityRule = {
  name: "alignedWithCall",
  evaluate(inputs: EligibilityInputs, _config: EligibilityRuleConfig): EligibilityRuleResult {
    if (!inputs.aligned_with_call) {
      return { passed: false, failure_reason: "Proposal objectives are not aligned with the call." };
    }
    return { passed: true };
  },
};

const primaryObjectiveIsRdRule: EligibilityRule = {
  name: "primaryObjectiveIsRd",
  evaluate(inputs: EligibilityInputs, _config: EligibilityRuleConfig): EligibilityRuleResult {
    if (!inputs.primary_objective_is_rd) {
      return {
        passed: false,
        failure_reason: "Primary objective must be research and development.",
      };
    }
    return { passed: true };
  },
};

const meetsEuropeanDimensionRule: EligibilityRule = {
  name: "meetsEuropeanDimension",
  evaluate(inputs: EligibilityInputs, _config: EligibilityRuleConfig): EligibilityRuleResult {
    if (inputs.meets_european_dimension === "false") {
      return {
        passed: false,
        failure_reason: "Proposal does not meet the European dimension requirement.",
      };
    }
    return { passed: true };
  },
};

const requestedBudgetKEurRule: EligibilityRule = {
  name: "requestedBudgetKEur",
  evaluate(inputs: EligibilityInputs, config: EligibilityRuleConfig): EligibilityRuleResult {
    const max = config.max_budget_k_eur ?? 500;
    if (inputs.requested_budget_k_eur > max) {
      return {
        passed: false,
        failure_reason: `Requested budget ${inputs.requested_budget_k_eur}k EUR exceeds maximum of ${max}k EUR.`,
      };
    }
    return { passed: true };
  },
};

const firstTimeApplicantInProgrammeRule: EligibilityRule = {
  name: "firstTimeApplicantInProgramme",
  evaluate(inputs: EligibilityInputs, _config: EligibilityRuleConfig): EligibilityRuleResult {
    // This rule is informational in P2; no failure is produced — the information
    // is recorded in inputs for admin use.
    return { passed: true };
  },
};

// ─── Rule registry ────────────────────────────────────────────────────────────

const RULE_REGISTRY: Record<EligibilityCheckName, EligibilityRule> = {
  submittedInEnglish: submittedInEnglishRule,
  alignedWithCall: alignedWithCallRule,
  primaryObjectiveIsRd: primaryObjectiveIsRdRule,
  meetsEuropeanDimension: meetsEuropeanDimensionRule,
  requestedBudgetKEur: requestedBudgetKEurRule,
  firstTimeApplicantInProgramme: firstTimeApplicantInProgrammeRule,
};

// ─── Pure evaluation function ─────────────────────────────────────────────────

/**
 * Evaluates eligibility inputs against the supplied active rule names.
 *
 * This is a pure function — no side effects, no DB access.
 * All inputs and active rule names are captured at evaluation time so they
 * can be stored verbatim in EligibilityRecord.
 */
export function evaluateEligibility(
  inputs: EligibilityInputs,
  activeRuleNames: EligibilityCheckName[],
  config: EligibilityRuleConfig
): EligibilityEvaluation {
  const failure_reasons: string[] = [];

  for (const ruleName of activeRuleNames) {
    const rule = RULE_REGISTRY[ruleName];
    if (!rule) {
      // Unknown rule name — log as failure to be safe
      failure_reasons.push(`Unknown eligibility rule: ${ruleName}`);
      continue;
    }
    const result: EligibilityRuleResult = rule.evaluate(inputs, config);
    if (!result.passed && result.failure_reason) {
      failure_reasons.push(result.failure_reason);
    }
  }

  const status: EligibilityStatus =
    failure_reasons.length === 0 ? "eligible" : "ineligible";

  return {
    status,
    active_rules: activeRuleNames,
    failure_reasons,
  };
}

/**
 * Returns the full set of known rule names.
 * Used to validate that call.enabled_eligibility_checks contains valid values.
 */
export function knownRuleNames(): EligibilityCheckName[] {
  return Object.keys(RULE_REGISTRY) as EligibilityCheckName[];
}

/**
 * Validates that every name in the supplied array is a known rule.
 * Returns unknown names so callers can decide how to handle them.
 */
export function filterValidRuleNames(names: string[]): {
  valid: EligibilityCheckName[];
  unknown: string[];
} {
  const known = new Set<string>(knownRuleNames());
  const valid: EligibilityCheckName[] = [];
  const unknown: string[] = [];

  for (const name of names) {
    if (known.has(name)) {
      valid.push(name as EligibilityCheckName);
    } else {
      unknown.push(name);
    }
  }

  return { valid, unknown };
}
