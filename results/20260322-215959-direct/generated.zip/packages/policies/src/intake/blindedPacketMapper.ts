
import type {
  BlindedContent,
  AttachmentMeta,
  Task,
} from "../../domain/src/entities/index.js";

/**
 * Input type mirrors the DB shape after joining ProposalVersion with Submission.
 * We keep this explicit to prevent accidentally including identity fields.
 */
export interface ProposalVersionForBlinding {
  id: string;
  submission_id: string;
  version_number: number;
  is_effective: boolean;
  title: string;
  abstract: string;
  requested_budget_k_eur: number;
  budget_usage: string;
  tasks_breakdown: Task[];
  attachments_meta: AttachmentMeta[];
}

/**
 * Maps a ProposalVersion to a BlindedContent object.
 *
 * IDENTITY SEPARATION INVARIANT:
 * - Must never include: legal_name, email, country, organisation, applicant_alias
 * - Only content fields from ProposalVersion are included
 * - The submission_id is retained for reviewer assignment lookups but
 *   does NOT reveal identity (it's a random CUID)
 *
 * This mapper is the single code path that produces reviewer-visible content.
 * It is tested by a golden test in tests/unit/blindedPacketMapper.test.ts.
 */
export function mapToBlindedContent(
  version: ProposalVersionForBlinding
): BlindedContent {
  return {
    proposal_version_id: version.id,
    submission_id: version.submission_id,
    version_number: version.version_number,
    title: version.title,
    abstract: version.abstract,
    requested_budget_k_eur: version.requested_budget_k_eur,
    budget_usage: version.budget_usage,
    tasks_breakdown: version.tasks_breakdown.map(stripTaskIdentity),
    attachments_meta: version.attachments_meta.map(stripAttachmentIdentity),
  };
}

/**
 * Tasks may contain applicant-authored text; we include them as-is since
 * proposal content is intended to be non-identifying by design. If a task
 * contained identity (e.g. a name in `responsible`), that is an applicant
 * error, not a system error. Future phases may add NLP redaction here.
 */
function stripTaskIdentity(task: Task): Task {
  return {
    task_id: task.task_id,
    description: task.description,
    duration_weeks: task.duration_weeks,
    responsible: task.responsible,
  };
}

function stripAttachmentIdentity(meta: AttachmentMeta): AttachmentMeta {
  return {
    filename: meta.filename,
    mime_type: meta.mime_type,
    size_bytes: meta.size_bytes,
    ...(meta.checksum !== undefined ? { checksum: meta.checksum } : {}),
  };
}

/**
 * Type guard: verify that a plain object does NOT contain identity fields.
 * Used in unit tests.
 */
export function containsIdentityFields(obj: Record<string, unknown>): boolean {
  const identityKeys = [
    "legal_name",
    "email",
    "country",
    "organisation",
    "applicant_alias",
  ];
  return identityKeys.some((key) => key in obj);
}
