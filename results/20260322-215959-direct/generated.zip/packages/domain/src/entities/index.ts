
import type { z } from "zod";
import type {
  ProposalStatusSchema,
  EligibilityStatusSchema,
  CallStatusSchema,
  PrincipalRoleSchema,
  EligibilityInputsSchema,
  CallSchema,
  SubmissionSchema,
  ProposalVersionSchema,
  ApplicantIdentitySchema,
  BlindedPacketSchema,
  BlindedContentSchema,
  EligibilityRecordSchema,
  AuditEventSchema,
  AttachmentMetaSchema,
  TaskSchema,
} from "../schemas/index.js";

// ─── Enumeration types ────────────────────────────────────────────────────────

export type ProposalStatus = z.infer<typeof ProposalStatusSchema>;
export type EligibilityStatus = z.infer<typeof EligibilityStatusSchema>;
export type CallStatus = z.infer<typeof CallStatusSchema>;
export type PrincipalRole = z.infer<typeof PrincipalRoleSchema>;

// ─── Value objects ────────────────────────────────────────────────────────────

export type EligibilityInputs = z.infer<typeof EligibilityInputsSchema>;
export type AttachmentMeta = z.infer<typeof AttachmentMetaSchema>;
export type Task = z.infer<typeof TaskSchema>;
export type BlindedContent = z.infer<typeof BlindedContentSchema>;

// ─── Entities ────────────────────────────────────────────────────────────────

export type Call = z.infer<typeof CallSchema>;
export type Submission = z.infer<typeof SubmissionSchema>;
export type ProposalVersion = z.infer<typeof ProposalVersionSchema>;
export type ApplicantIdentity = z.infer<typeof ApplicantIdentitySchema>;
export type BlindedPacket = z.infer<typeof BlindedPacketSchema>;
export type EligibilityRecord = z.infer<typeof EligibilityRecordSchema>;
export type AuditEvent = z.infer<typeof AuditEventSchema>;

// ─── Principal ────────────────────────────────────────────────────────────────

export interface Principal {
  /** Stable identifier for the authenticated user (sub claim in JWT) */
  id: string;
  role: PrincipalRole;
  /** For applicants: the alias used in submissions */
  alias?: string;
  /** For reviewers: submission IDs they are assigned to */
  assignedSubmissionIds?: string[];
}

// ─── Policy evaluation types ──────────────────────────────────────────────────

export type ResourceType =
  | "Call"
  | "Submission"
  | "ProposalVersion"
  | "ApplicantIdentity"
  | "BlindedPacket"
  | "EligibilityRecord"
  | "AuditEvent";

export type Operation = "read" | "write" | "delete";

export interface AccessRequest {
  principal: Principal;
  resource: ResourceType;
  operation: Operation;
  /** The record being accessed, used for ownership checks */
  context?: AccessContext;
}

export interface AccessContext {
  submissionId?: string;
  applicantAlias?: string;
  submissionStatus?: ProposalStatus;
}

export interface AccessResult {
  allowed: boolean;
  reason: string;
  policyName: string;
}

// ─── Eligibility rule types ───────────────────────────────────────────────────

export type EligibilityCheckName =
  | "submittedInEnglish"
  | "alignedWithCall"
  | "primaryObjectiveIsRd"
  | "meetsEuropeanDimension"
  | "requestedBudgetKEur"
  | "firstTimeApplicantInProgramme";

export interface EligibilityRule {
  name: EligibilityCheckName;
  evaluate: (inputs: EligibilityInputs, config: EligibilityRuleConfig) => EligibilityRuleResult;
}

export interface EligibilityRuleConfig {
  max_budget_k_eur?: number;
}

export interface EligibilityRuleResult {
  passed: boolean;
  failure_reason?: string;
}

export interface EligibilityEvaluation {
  status: EligibilityStatus;
  active_rules: EligibilityCheckName[];
  failure_reasons: string[];
}

// ─── Service result types ─────────────────────────────────────────────────────

export interface SubmitProposalResult {
  submission_id: string;
  proposal_version_id: string;
  status: ProposalStatus;
}

export interface RunEligibilityCheckResult {
  eligibility_record_id: string;
  status: EligibilityStatus;
  failure_reasons: string[];
}
