
import { z } from "zod";

// ─── Enumerations ────────────────────────────────────────────────────────────

export const ProposalStatusSchema = z.enum([
  "draft",
  "submitted",
  "eligibility_failed",
  "eligible",
  "under_review",
  "clarification_requested",
  "revised",
  "validation_pending",
  "selected",
  "rejected",
]);

export const EligibilityStatusSchema = z.enum([
  "eligible",
  "ineligible",
  "pending",
]);

export const CallStatusSchema = z.enum([
  "draft",
  "open",
  "closed",
  "archived",
]);

export const PrincipalRoleSchema = z.enum([
  "applicant",
  "admin",
  "reviewer",
  "validator",
  "auditor",
]);

// ─── EligibilityInputs ───────────────────────────────────────────────────────

export const EligibilityInputsSchema = z.object({
  submitted_in_english: z.boolean(),
  aligned_with_call: z.boolean(),
  primary_objective_is_rd: z.boolean(),
  meets_european_dimension: z.enum(["true", "false", "not_applicable"]),
  requested_budget_k_eur: z.number().positive(),
  first_time_applicant_in_programme: z.boolean(),
});

// ─── Call ────────────────────────────────────────────────────────────────────

export const CallSchema = z.object({
  id: z.string().cuid(),
  title: z.string().min(1),
  description: z.string().min(1),
  open_date: z.coerce.date(),
  close_date: z.coerce.date(),
  status: CallStatusSchema,
  enabled_eligibility_checks: z.array(z.string()),
  max_budget_k_eur: z.number().positive(),
  reviewer_policy_version: z.string().min(1),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── Submission ──────────────────────────────────────────────────────────────

export const SubmissionSchema = z.object({
  id: z.string().cuid(),
  call_id: z.string().cuid(),
  applicant_alias: z.string().min(1),
  status: ProposalStatusSchema,
  submitted_at: z.coerce.date().nullable(),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── ProposalVersion ─────────────────────────────────────────────────────────

export const AttachmentMetaSchema = z.object({
  filename: z.string(),
  mime_type: z.string(),
  size_bytes: z.number().int().nonnegative(),
  checksum: z.string().optional(),
});

export const TaskSchema = z.object({
  task_id: z.string(),
  description: z.string(),
  duration_weeks: z.number().int().positive(),
  responsible: z.string(),
});

export const ProposalVersionSchema = z.object({
  id: z.string().cuid(),
  submission_id: z.string().cuid(),
  version_number: z.number().int().positive(),
  is_effective: z.boolean(),
  title: z.string().min(1),
  abstract: z.string().min(1),
  requested_budget_k_eur: z.number().positive(),
  budget_usage: z.string().min(1),
  tasks_breakdown: z.array(TaskSchema),
  attachments_meta: z.array(AttachmentMetaSchema),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── ApplicantIdentity ───────────────────────────────────────────────────────

export const ApplicantIdentitySchema = z.object({
  id: z.string().cuid(),
  submission_id: z.string().cuid(),
  legal_name: z.string().min(1),
  email: z.string().email(),
  country: z.string().min(2).max(2),
  organisation: z.string().min(1),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── BlindedPacket ───────────────────────────────────────────────────────────

export const BlindedContentSchema = z.object({
  proposal_version_id: z.string().cuid(),
  submission_id: z.string().cuid(),
  version_number: z.number().int().positive(),
  title: z.string(),
  abstract: z.string(),
  requested_budget_k_eur: z.number(),
  budget_usage: z.string(),
  tasks_breakdown: z.array(TaskSchema),
  attachments_meta: z.array(AttachmentMetaSchema),
});

export const BlindedPacketSchema = z.object({
  id: z.string().cuid(),
  proposal_version_id: z.string().cuid(),
  content: BlindedContentSchema,
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── EligibilityRecord ───────────────────────────────────────────────────────

export const EligibilityRecordSchema = z.object({
  id: z.string().cuid(),
  submission_id: z.string().cuid(),
  status: EligibilityStatusSchema,
  inputs: EligibilityInputsSchema,
  active_rules: z.array(z.string()),
  failure_reasons: z.array(z.string()),
  evaluated_at: z.coerce.date(),
  created_at: z.coerce.date(),
  updated_at: z.coerce.date(),
});

// ─── AuditEvent ──────────────────────────────────────────────────────────────

export const AuditEventSchema = z.object({
  id: z.string().cuid(),
  event_type: z.string().min(1),
  actor_id: z.string().min(1),
  target_type: z.string().min(1),
  target_id: z.string().min(1),
  payload: z.record(z.unknown()),
  timestamp: z.coerce.date(),
});

// ─── API Input Schemas ───────────────────────────────────────────────────────

export const SubmitProposalInputSchema = z.object({
  call_id: z.string().min(1),
  // Proposal content
  title: z.string().min(1),
  abstract: z.string().min(1),
  requested_budget_k_eur: z.number().positive(),
  budget_usage: z.string().min(1),
  tasks_breakdown: z.array(TaskSchema),
  attachments_meta: z.array(AttachmentMetaSchema).default([]),
  // Identity
  legal_name: z.string().min(1),
  email: z.string().email(),
  country: z.string().min(2).max(2),
  organisation: z.string().min(1),
});

export const EligibilityCheckInputSchema = z.object({
  submission_id: z.string().min(1),
  inputs: EligibilityInputsSchema,
});

// ─── Type exports ─────────────────────────────────────────────────────────────

export type SubmitProposalInput = z.infer<typeof SubmitProposalInputSchema>;
export type EligibilityCheckInput = z.infer<typeof EligibilityCheckInputSchema>;
export type EligibilityInputs = z.infer<typeof EligibilityInputsSchema>;
export type BlindedContent = z.infer<typeof BlindedContentSchema>;
export type AttachmentMeta = z.infer<typeof AttachmentMetaSchema>;
export type Task = z.infer<typeof TaskSchema>;
