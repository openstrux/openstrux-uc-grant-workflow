
import { NextRequest, NextResponse } from "next/server";
import type { Principal, PrincipalRole } from "../../../../packages/domain/src/entities/index.js";
import { PrincipalRoleSchema } from "../../../../packages/domain/src/schemas/index.js";

// ─── JWT payload type ─────────────────────────────────────────────────────────

interface JwtPayload {
  sub: string;
  role: PrincipalRole;
  alias?: string;
  assigned_submission_ids?: string[];
  exp?: number;
  iat?: number;
}

// ─── Dev-mode header extraction ───────────────────────────────────────────────

/**
 * In dev/test mode, reads principal from `X-Role`, `X-Actor-Id`, and
 * `X-Actor-Alias` headers. This avoids needing an external IdP for P0-P2.
 *
 * In production this path must be disabled.
 */
function extractPrincipalFromDevHeaders(
  req: NextRequest
): Principal | null {
  const rawRole = req.headers.get("x-role");
  const actorId = req.headers.get("x-actor-id");

  if (!rawRole || !actorId) return null;

  const roleParse = PrincipalRoleSchema.safeParse(rawRole);
  if (!roleParse.success) return null;

  const role = roleParse.data;
  const alias = req.headers.get("x-actor-alias") ?? undefined;
  const assignedRaw = req.headers.get("x-assigned-submission-ids");
  const assignedSubmissionIds = assignedRaw
    ? assignedRaw.split(",").map((s) => s.trim()).filter(Boolean)
    : undefined;

  return {
    id: actorId,
    role,
    alias,
    assignedSubmissionIds,
  };
}

// ─── JWT extraction (production path) ────────────────────────────────────────

/**
 * Minimal JWT decoder — reads the payload from a Bearer token WITHOUT
 * cryptographic verification. Verification should be added before P3.
 *
 * For P0-P2 the dev-header path is preferred; this is a fallback scaffold.
 */
function extractPrincipalFromJwt(req: NextRequest): Principal | null {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) return null;

  const token = authHeader.slice(7);
  const parts = token.split(".");
  if (parts.length !== 3) return null;

  try {
    const payloadPart = parts[1];
    if (!payloadPart) return null;
    // Base64url decode
    const json = Buffer.from(payloadPart, "base64url").toString("utf-8");
    const payload = JSON.parse(json) as JwtPayload;

    // Check expiry
    if (payload.exp !== undefined && Date.now() / 1000 > payload.exp) {
      return null;
    }

    const roleParse = PrincipalRoleSchema.safeParse(payload.role);
    if (!roleParse.success) return null;

    return {
      id: payload.sub,
      role: roleParse.data,
      alias: payload.alias,
      assignedSubmissionIds: payload.assigned_submission_ids,
    };
  } catch {
    return null;
  }
}

// ─── Main exported resolver ───────────────────────────────────────────────────

/**
 * Resolves a Principal from the incoming request.
 * Returns null if no valid auth is present.
 *
 * Priority:
 * 1. Dev-mode headers (X-Role + X-Actor-Id) when NODE_ENV !== "production"
 * 2. Bearer JWT token
 */
export function resolvePrincipal(req: NextRequest): Principal | null {
  if (process.env["NODE_ENV"] !== "production") {
    const devPrincipal = extractPrincipalFromDevHeaders(req);
    if (devPrincipal) return devPrincipal;
  }

  return extractPrincipalFromJwt(req);
}

// ─── Route handler helpers ────────────────────────────────────────────────────

/**
 * Extracts principal and returns a 401 response if unauthenticated.
 * Use at the top of every route handler.
 */
export function requireAuth(
  req: NextRequest
): { principal: Principal; error?: never } | { principal?: never; error: NextResponse } {
  const principal = resolvePrincipal(req);
  if (!principal) {
    return {
      error: NextResponse.json(
        { error: "Unauthorized", message: "Missing or invalid authentication." },
        { status: 401 }
      ),
    };
  }
  return { principal };
}

/**
 * Returns a 403 response for access denied scenarios.
 * Includes the policy name for debuggability.
 */
export function forbiddenResponse(reason: string, policyName?: string): NextResponse {
  return NextResponse.json(
    {
      error: "Forbidden",
      message: reason,
      ...(policyName ? { policy: policyName } : {}),
    },
    { status: 403 }
  );
}

/**
 * Returns a 400 validation error response from a Zod error.
 */
export function validationErrorResponse(issues: { message: string; path: (string | number)[] }[]): NextResponse {
  return NextResponse.json(
    {
      error: "ValidationError",
      issues,
    },
    { status: 400 }
  );
}
