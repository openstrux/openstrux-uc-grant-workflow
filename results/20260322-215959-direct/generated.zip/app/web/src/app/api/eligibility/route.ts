
import { NextRequest, NextResponse } from "next/server";
import { EligibilityCheckInputSchema } from "../../../../../packages/domain/src/schemas/index.js";
import { runEligibilityCheck } from "../../../../../packages/policies/src/workflow/runEligibilityCheck.js";
import {
  requireAuth,
  forbiddenResponse,
  validationErrorResponse,
} from "../../server/auth/middleware.js";
import { AccessDeniedError } from "../../../../../packages/policies/src/access/checkAccess.js";

/**
 * POST /api/eligibility
 *
 * Triggers an eligibility check for a submission.
 * Persists the EligibilityRecord and transitions the submission status.
 *
 * Roles allowed: admin only
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  // 1. Authenticate
  const auth = requireAuth(req);
  if (auth.error) return auth.error;
  const { principal } = auth;

  // 2. Validate input
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json(
      { error: "BadRequest", message: "Request body must be valid JSON." },
      { status: 400 }
    );
  }

  const parsed = EligibilityCheckInputSchema.safeParse(body);
  if (!parsed.success) {
    return validationErrorResponse(
      parsed.error.issues.map((i) => ({
        message: i.message,
        path: i.path as (string | number)[],
      }))
    );
  }

  const input = parsed.data;

  // 3. Execute service (access control enforced inside)
  try {
    const result = await runEligibilityCheck(
      {
        submission_id: input.submission_id,
        inputs: input.inputs,
      },
      principal
    );

    return NextResponse.json(result, { status: 200 });
  } catch (err) {
    if (err instanceof AccessDeniedError) {
      return forbiddenResponse(err.message, err.policyName);
    }
    if (err instanceof Error) {
      return NextResponse.json(
        { error: "UnprocessableEntity", message: err.message },
        { status: 422 }
      );
    }
    return NextResponse.json(
      { error: "InternalServerError", message: "An unexpected error occurred." },
      { status: 500 }
    );
  }
}
