
import { NextRequest, NextResponse } from "next/server";
import { SubmitProposalInputSchema } from "../../../../../packages/domain/src/schemas/index.js";
import { submitProposal } from "../../../../../packages/policies/src/workflow/submitProposal.js";
import {
  requireAuth,
  forbiddenResponse,
  validationErrorResponse,
} from "../../server/auth/middleware.js";
import { AccessDeniedError } from "../../../../../packages/policies/src/access/checkAccess.js";

/**
 * POST /api/intake
 *
 * Creates a new submission with proposal content and applicant identity.
 * Identity and proposal content are separated at the service layer.
 *
 * Roles allowed: applicant, admin
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  // 1. Authenticate
  const auth = requireAuth(req);
  if (auth.error) return auth.error;
  const { principal } = auth;

  // 2. Validate input
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json(
      { error: "BadRequest", message: "Request body must be valid JSON." },
      { status: 400 }
    );
  }

  const parsed = SubmitProposalInputSchema.safeParse(body);
  if (!parsed.success) {
    return validationErrorResponse(
      parsed.error.issues.map((i) => ({
        message: i.message,
        path: i.path as (string | number)[],
      }))
    );
  }

  const input = parsed.data;

  // 3. Execute service (access control enforced inside)
  try {
    const result = await submitProposal(
      {
        call_id: input.call_id,
        title: input.title,
        abstract: input.abstract,
        requested_budget_k_eur: input.requested_budget_k_eur,
        budget_usage: input.budget_usage,
        tasks_breakdown: input.tasks_breakdown,
        attachments_meta: input.attachments_meta,
        legal_name: input.legal_name,
        email: input.email,
        country: input.country,
        organisation: input.organisation,
      },
      principal
    );

    return NextResponse.json(result, { status: 201 });
  } catch (err) {
    if (err instanceof AccessDeniedError) {
      return forbiddenResponse(err.message, err.policyName);
    }
    if (err instanceof Error) {
      // Domain errors (call not found, not open, etc.)
      return NextResponse.json(
        { error: "UnprocessableEntity", message: err.message },
        { status: 422 }
      );
    }
    return NextResponse.json(
      { error: "InternalServerError", message: "An unexpected error occurred." },
      { status: 500 }
    );
  }
}
