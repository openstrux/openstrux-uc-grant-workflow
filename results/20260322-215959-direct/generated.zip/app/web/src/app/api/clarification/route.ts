
import { NextRequest, NextResponse } from "next/server";

/**
 * P4 — Clarification
 * Not implemented in this phase. Returns 501.
 */
export async function GET(_req: NextRequest): Promise<NextResponse> {
  return NextResponse.json(
    { error: "NotImplemented", message: "P4 Clarification is not active in this phase." },
    { status: 501 }
  );
}

export async function POST(_req: NextRequest): Promise<NextResponse> {
  return NextResponse.json(
    { error: "NotImplemented", message: "P4 Clarification is not active in this phase." },
    { status: 501 }
  );
}
