
import { NextRequest, NextResponse } from "next/server";

/**
 * P5 — Validation
 * Not implemented in this phase. Returns 501.
 */
export async function GET(_req: NextRequest): Promise<NextResponse> {
  return NextResponse.json(
    { error: "NotImplemented", message: "P5 Validation is not active in this phase." },
    { status: 501 }
  );
}

export async function POST(_req: NextRequest): Promise<NextResponse> {
  return NextResponse.json(
    { error: "NotImplemented", message: "P5 Validation is not active in this phase." },
    { status: 501 }
  );
}
