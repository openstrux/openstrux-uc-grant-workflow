
import { NextRequest, NextResponse } from "next/server";

/**
 * P6 — Audit/lifecycle export
 * Not implemented in this phase. Returns 501.
 */
export async function GET(_req: NextRequest): Promise<NextResponse> {
  return NextResponse.json(
    { error: "NotImplemented", message: "P6 Audit export is not active in this phase." },
    { status: 501 }
  );
}
