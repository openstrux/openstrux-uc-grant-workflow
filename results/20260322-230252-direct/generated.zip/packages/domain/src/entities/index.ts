
import type { z } from "zod";
import type {
  ProposalStatusSchema,
  EligibilityStatusSchema,
  CallStatusSchema,
  AuditEventTypeSchema,
  MeetsEuropeanDimensionSchema,
  EligibilityInputsSchema,
  CallSchema,
  SubmissionSchema,
  ProposalVersionSchema,
  ApplicantIdentitySchema,
  BlindedPacketSchema,
  BlindedPacketContentSchema,
  EligibilityRecordSchema,
  AuditEventSchema,
  AttachmentMetaSchema,
  TaskItemSchema,
  IntakeRequestSchema,
  EligibilityRequestSchema,
  PrincipalSchema,
  PrincipalRoleSchema,
} from "../schemas/index";

export type ProposalStatus = z.infer<typeof ProposalStatusSchema>;
export type EligibilityStatus = z.infer<typeof EligibilityStatusSchema>;
export type CallStatus = z.infer<typeof CallStatusSchema>;
export type AuditEventType = z.infer<typeof AuditEventTypeSchema>;
export type MeetsEuropeanDimension = z.infer<typeof MeetsEuropeanDimensionSchema>;
export type AttachmentMeta = z.infer<typeof AttachmentMetaSchema>;
export type TaskItem = z.infer<typeof TaskItemSchema>;
export type EligibilityInputs = z.infer<typeof EligibilityInputsSchema>;
export type Call = z.infer<typeof CallSchema>;
export type Submission = z.infer<typeof SubmissionSchema>;
export type ProposalVersion = z.infer<typeof ProposalVersionSchema>;
export type ApplicantIdentity = z.infer<typeof ApplicantIdentitySchema>;
export type BlindedPacketContent = z.infer<typeof BlindedPacketContentSchema>;
export type BlindedPacket = z.infer<typeof BlindedPacketSchema>;
export type EligibilityRecord = z.infer<typeof EligibilityRecordSchema>;
export type AuditEvent = z.infer<typeof AuditEventSchema>;
export type IntakeRequest = z.infer<typeof IntakeRequestSchema>;
export type EligibilityRequest = z.infer<typeof EligibilityRequestSchema>;
export type PrincipalRole = z.infer<typeof PrincipalRoleSchema>;
export type Principal = z.infer<typeof PrincipalSchema>;

export interface EligibilityEvaluationResult {
  status: EligibilityStatus;
  failure_reasons: string[];
  active_rules: string[];
  inputs: EligibilityInputs;
  rule_set_version: string;
}

export interface SubmitProposalResult {
  submission_id: string;
  proposal_version_id: string;
  blinded_packet_id: string;
  status: ProposalStatus;
}

export interface RunEligibilityCheckResult {
  eligibility_record_id: string;
  submission_id: string;
  status: EligibilityStatus;
  failure_reasons: string[];
}

export type ResourceType =
  | "Submission"
  | "ProposalVersion"
  | "ApplicantIdentity"
  | "BlindedPacket"
  | "EligibilityRecord"
  | "Call"
  | "AuditEvent";

export type Operation = "read" | "write" | "delete";

export interface AccessContext {
  principal: Principal;
  resourceType: ResourceType;
  resourceId: string;
  operation: Operation;
  resourceMeta?: Record<string, unknown>;
}

export interface AccessDecision {
  allowed: boolean;
  reason: string;
  policy: string;
}
