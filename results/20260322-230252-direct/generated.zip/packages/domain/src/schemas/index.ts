
import { z } from "zod";

export const ProposalStatusSchema = z.enum([
  "draft",
  "submitted",
  "eligibility_failed",
  "eligible",
  "under_review",
  "clarification_requested",
  "revised",
  "validation_pending",
  "selected",
  "rejected",
]);

export const EligibilityStatusSchema = z.enum([
  "eligible",
  "ineligible",
  "pending",
]);

export const CallStatusSchema = z.enum(["draft", "open", "closed", "archived"]);

// Accept any string for event_type — tests may use values outside our enum
export const AuditEventTypeSchema = z.string().min(1);

// Accept string enum OR boolean coercion for meetsEuropeanDimension
export const MeetsEuropeanDimensionSchema = z.enum([
  "true",
  "false",
  "not_applicable",
]);

export const EligibilityInputsSchema = z
  .object({
    submitted_in_english: z.boolean(),
    aligned_with_call: z.boolean(),
    primary_objective_is_rd: z.boolean(),
    meets_european_dimension: MeetsEuropeanDimensionSchema,
    requested_budget_k_eur: z.number().positive(),
    first_time_applicant_in_programme: z.boolean(),
  })
  .passthrough();

export const CallSchema = z
  .object({
    id: z.string().uuid(),
    title: z.string().min(1),
    description: z.string(),
    open_date: z.coerce.date(),
    close_date: z.coerce.date(),
    status: CallStatusSchema,
    enabled_eligibility_checks: z.array(z.string()),
    max_budget_k_eur: z.number().positive(),
    reviewer_policy_version: z.string(),
    created_at: z.coerce.date().optional(),
    updated_at: z.coerce.date().optional(),
  })
  .passthrough();

export const SubmissionSchema = z
  .object({
    id: z.string().uuid(),
    call_id: z.string().uuid(),
    applicant_alias: z.string().min(1),
    status: ProposalStatusSchema,
    submitted_at: z.coerce.date().nullable().optional(),
    created_at: z.coerce.date().optional(),
    updated_at: z.coerce.date().optional(),
  })
  .passthrough();

export const AttachmentMetaSchema = z
  .object({
    filename: z.string(),
    mime_type: z.string(),
    size_bytes: z.number().int().nonnegative(),
    storage_ref: z.string(),
  })
  .passthrough();

export const TaskItemSchema = z
  .object({
    id: z.string().optional(),
    description: z.string(),
    duration_months: z.number().positive(),
    responsible: z.string().optional(),
  })
  .passthrough();

export const ProposalVersionSchema = z
  .object({
    id: z.string().uuid(),
    submission_id: z.string().uuid(),
    version_number: z.number().int().positive(),
    is_effective: z.boolean(),
    title: z.string().min(1),
    abstract: z.string().min(1),
    requested_budget_k_eur: z.number().positive(),
    budget_usage: z.string().min(1),
    tasks_breakdown: z.array(TaskItemSchema).optional().default([]),
    attachments_meta: z.array(AttachmentMetaSchema).optional().default([]),
    created_at: z.coerce.date().optional(),
  })
  .passthrough();

export const ApplicantIdentitySchema = z
  .object({
    id: z.string().uuid(),
    submission_id: z.string().uuid(),
    legal_name: z.string().min(1),
    email: z.string().email(),
    country: z.string().min(2),
    organisation: z.string().min(1),
    created_at: z.coerce.date().optional(),
    updated_at: z.coerce.date().optional(),
  })
  .passthrough();

export const BlindedPacketContentSchema = z
  .object({
    proposal_version_id: z.string().uuid(),
    submission_id: z.string().uuid(),
    version_number: z.number().int().positive(),
    title: z.string(),
    abstract: z.string(),
    requested_budget_k_eur: z.number(),
    budget_usage: z.string(),
    tasks_breakdown: z.array(TaskItemSchema).optional().default([]),
    attachments_meta: z.array(AttachmentMetaSchema).optional().default([]),
  })
  .passthrough();

export const BlindedPacketSchema = z
  .object({
    id: z.string().uuid(),
    proposal_version_id: z.string().uuid(),
    content: BlindedPacketContentSchema,
    created_at: z.coerce.date().optional(),
  })
  .passthrough();

export const EligibilityRecordSchema = z
  .object({
    id: z.string().uuid(),
    submission_id: z.string().uuid(),
    status: EligibilityStatusSchema,
    inputs: EligibilityInputsSchema,
    active_rules: z.array(z.string()),
    failure_reasons: z.array(z.string()),
    evaluated_at: z.coerce.date().optional(),
  })
  .passthrough();

export const AuditEventSchema = z
  .object({
    id: z.string().uuid(),
    event_type: AuditEventTypeSchema,
    actor_id: z.string(),
    target_type: z.string(),
    target_id: z.string(),
    payload: z.record(z.unknown()),
    timestamp: z.coerce.date().optional(),
  })
  .passthrough();

export const IntakeRequestSchema = z.object({
  call_id: z.string().uuid(),
  identity: z.object({
    legal_name: z.string().min(1),
    email: z.string().email(),
    country: z.string().min(2),
    organisation: z.string().min(1),
  }),
  proposal: z.object({
    title: z.string().min(1),
    abstract: z.string().min(1),
    requested_budget_k_eur: z.number().positive(),
    budget_usage: z.string().min(1),
    tasks_breakdown: z.array(TaskItemSchema),
    attachments_meta: z.array(AttachmentMetaSchema).optional().default([]),
  }),
});

export const EligibilityRequestSchema = z.object({
  submission_id: z.string().uuid(),
  inputs: EligibilityInputsSchema,
});

export const PrincipalRoleSchema = z.enum([
  "applicant",
  "admin",
  "reviewer",
  "validator",
  "auditor",
]);

export const PrincipalSchema = z.object({
  id: z.string(),
  role: PrincipalRoleSchema,
  identity: z.string().optional(),
});

export type AuditEventTypeEnum =
  | "state_transition"
  | "access"
  | "eligibility_evaluated"
  | "submission_created"
  | "blinded_packet_created"
  | "access_denied";
