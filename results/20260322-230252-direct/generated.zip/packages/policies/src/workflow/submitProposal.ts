
import { prisma } from "../../domain/src/prisma/client";
import { mapToBlindedContent } from "../intake/blindedPacketMapper";
import type {
  IntakeRequest,
  SubmitProposalResult,
} from "../../domain/src/entities/index";
import type { ProposalVersion as PrismaProposalVersion } from "@prisma/client";

export async function submitProposal(
  request: IntakeRequest,
  actorId: string
): Promise<SubmitProposalResult> {
  const result = await prisma.$transaction(async (tx) => {
    const applicantAlias = `applicant:${actorId}`;

    const submission = await tx.submission.create({
      data: {
        call_id: request.call_id,
        applicant_alias: applicantAlias,
        status: "submitted",
        submitted_at: new Date(),
      },
    });

    const proposalVersion = await tx.proposalVersion.create({
      data: {
        submission_id: submission.id,
        version_number: 1,
        is_effective: true,
        title: request.proposal.title,
        abstract: request.proposal.abstract,
        requested_budget_k_eur: request.proposal.requested_budget_k_eur,
        budget_usage: request.proposal.budget_usage,
        tasks_breakdown: request.proposal.tasks_breakdown,
        attachments_meta: request.proposal.attachments_meta,
      },
    });

    await tx.applicantIdentity.create({
      data: {
        submission_id: submission.id,
        legal_name: request.identity.legal_name,
        email: request.identity.email,
        country: request.identity.country,
        organisation: request.identity.organisation,
      },
    });

    const blindedContent = mapToBlindedContent(
      proposalVersion as PrismaProposalVersion
    );

    const blindedPacket = await tx.blindedPacket.create({
      data: {
        proposal_version_id: proposalVersion.id,
        content: blindedContent,
      },
    });

    await tx.auditEvent.create({
      data: {
        event_type: "submission_created",
        actor_id: actorId,
        target_type: "Submission",
        target_id: submission.id,
        payload: {
          call_id: request.call_id,
          status: "submitted",
          version_number: 1,
        },
      },
    });

    await tx.auditEvent.create({
      data: {
        event_type: "state_transition",
        actor_id: actorId,
        target_type: "Submission",
        target_id: submission.id,
        payload: {
          from: "draft",
          to: "submitted",
          trigger: "submit",
        },
      },
    });

    await tx.auditEvent.create({
      data: {
        event_type: "blinded_packet_created",
        actor_id: actorId,
        target_type: "BlindedPacket",
        target_id: blindedPacket.id,
        payload: {
          submission_id: submission.id,
          proposal_version_id: proposalVersion.id,
        },
      },
    });

    return {
      submission_id: submission.id,
      proposal_version_id: proposalVersion.id,
      blinded_packet_id: blindedPacket.id,
      status: "submitted" as const,
    };
  });

  return result;
}
