
import { prisma } from "../../domain/src/prisma/client";
import {
  evaluateEligibility,
  type EligibilityRuleSet,
} from "../eligibility/evaluateEligibility";
import type {
  EligibilityInputs,
  RunEligibilityCheckResult,
} from "../../domain/src/entities/index";

const DEFAULT_RULE_SET_VERSION = "v0.6.0";

export async function runEligibilityCheck(
  submissionId: string,
  inputs: EligibilityInputs,
  actorId: string
): Promise<RunEligibilityCheckResult> {
  const submission = await prisma.submission.findUnique({
    where: { id: submissionId },
    include: {
      call: {
        select: {
          id: true,
          enabled_eligibility_checks: true,
          max_budget_k_eur: true,
          status: true,
        },
      },
    },
  });

  if (!submission) {
    throw new Error(`Submission not found: ${submissionId}`);
  }

  if (submission.status !== "submitted") {
    throw new Error(
      `Eligibility check can only run on submitted proposals. Current status: ${submission.status}`
    );
  }

  const ruleSet: EligibilityRuleSet = {
    version: DEFAULT_RULE_SET_VERSION,
    enabledChecks: submission.call.enabled_eligibility_checks,
    maxBudgetKEur: submission.call.max_budget_k_eur,
  };

  // Note: evaluateEligibility signature is (ruleSet, inputs)
  const evaluationResult = evaluateEligibility(ruleSet, inputs);

  const result = await prisma.$transaction(async (tx) => {
    const eligibilityRecord = await tx.eligibilityRecord.create({
      data: {
        submission_id: submissionId,
        status: evaluationResult.status,
        inputs: evaluationResult.inputs as object,
        active_rules: evaluationResult.active_rules,
        failure_reasons: evaluationResult.failure_reasons,
        evaluated_at: new Date(),
      },
    });

    const newStatus =
      evaluationResult.status === "eligible"
        ? ("eligible" as const)
        : ("eligibility_failed" as const);

    const previousStatus = submission.status;

    await tx.submission.update({
      where: { id: submissionId },
      data: { status: newStatus },
    });

    await tx.auditEvent.create({
      data: {
        event_type: "eligibility_evaluated",
        actor_id: actorId,
        target_type: "EligibilityRecord",
        target_id: eligibilityRecord.id,
        payload: {
          submission_id: submissionId,
          result: evaluationResult.status,
          failure_reasons: evaluationResult.failure_reasons,
          active_rules: evaluationResult.active_rules,
          rule_set_version: evaluationResult.rule_set_version,
          inputs: evaluationResult.inputs as Record<string, unknown>,
        },
      },
    });

    await tx.auditEvent.create({
      data: {
        event_type: "state_transition",
        actor_id: actorId,
        target_type: "Submission",
        target_id: submissionId,
        payload: {
          from: previousStatus,
          to: newStatus,
          trigger: "eligibility_check",
          eligibility_record_id: eligibilityRecord.id,
        },
      },
    });

    return {
      eligibility_record_id: eligibilityRecord.id,
      submission_id: submissionId,
      status: evaluationResult.status,
      failure_reasons: evaluationResult.failure_reasons,
    };
  });

  return result;
}
