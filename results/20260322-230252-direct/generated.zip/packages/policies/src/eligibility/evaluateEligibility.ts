
/**
 * Pure eligibility evaluation function.
 * No DB access, no side effects.
 *
 * NOTE: parameter order is (ruleSet, inputs) — ruleSet first.
 */

import type {
  EligibilityInputs,
  EligibilityEvaluationResult,
} from "../../domain/src/entities/index";

export interface EligibilityRuleSet {
  version: string;
  enabledChecks: string[];
  maxBudgetKEur: number;
}

export const RULE_SUBMITTED_IN_ENGLISH = "submittedInEnglish";
export const RULE_ALIGNED_WITH_CALL = "alignedWithCall";
export const RULE_PRIMARY_OBJECTIVE_IS_RD = "primaryObjectiveIsRd";
export const RULE_MEETS_EUROPEAN_DIMENSION = "meetsEuropeanDimension";
export const RULE_REQUESTED_BUDGET_K_EUR = "requestedBudgetKEur";

type RuleEvaluator = (
  inputs: EligibilityInputs,
  ruleSet: EligibilityRuleSet
) => string | null;

const ruleEvaluators: Record<string, RuleEvaluator> = {
  [RULE_SUBMITTED_IN_ENGLISH]: (inputs) =>
    inputs.submitted_in_english
      ? null
      : "Proposal must be submitted in English.",

  [RULE_ALIGNED_WITH_CALL]: (inputs) =>
    inputs.aligned_with_call
      ? null
      : "Proposal must be aligned with the call objectives.",

  [RULE_PRIMARY_OBJECTIVE_IS_RD]: (inputs) =>
    inputs.primary_objective_is_rd
      ? null
      : "The primary objective must be research and development.",

  [RULE_MEETS_EUROPEAN_DIMENSION]: (inputs) =>
    inputs.meets_european_dimension === "false"
      ? "Proposal does not meet the European dimension requirement."
      : null,

  [RULE_REQUESTED_BUDGET_K_EUR]: (inputs, ruleSet) =>
    inputs.requested_budget_k_eur > ruleSet.maxBudgetKEur
      ? `Requested budget (${inputs.requested_budget_k_eur}k EUR) exceeds the maximum allowed (${ruleSet.maxBudgetKEur}k EUR).`
      : null,
};

export function evaluateEligibility(
  ruleSet: EligibilityRuleSet,
  inputs: EligibilityInputs
): EligibilityEvaluationResult {
  const failure_reasons: string[] = [];
  const active_rules = [...ruleSet.enabledChecks];

  for (const rule of ruleSet.enabledChecks) {
    const evaluator = ruleEvaluators[rule];
    if (!evaluator) {
      failure_reasons.push(`Unknown eligibility rule: ${rule}`);
      continue;
    }
    const reason = evaluator(inputs, ruleSet);
    if (reason !== null) {
      failure_reasons.push(reason);
    }
  }

  return {
    status: failure_reasons.length === 0 ? "eligible" : "ineligible",
    failure_reasons,
    active_rules,
    inputs,
    rule_set_version: ruleSet.version,
  };
}
