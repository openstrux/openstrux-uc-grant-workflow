
import type { BlindedPacketContent } from "../../domain/src/entities/index";
import type { ProposalVersion as PrismaProposalVersion } from "@prisma/client";

type TaskItem = {
  id: string;
  description: string;
  duration_months: number;
  responsible: string;
};

type AttachmentMeta = {
  filename: string;
  mime_type: string;
  size_bytes: number;
  storage_ref: string;
};

export function mapToBlindedContent(
  proposalVersion: PrismaProposalVersion
): BlindedPacketContent {
  const tasks = proposalVersion.tasks_breakdown as TaskItem[];
  const attachments = proposalVersion.attachments_meta as AttachmentMeta[];

  return {
    proposal_version_id: proposalVersion.id,
    submission_id: proposalVersion.submission_id,
    version_number: proposalVersion.version_number,
    title: proposalVersion.title,
    abstract: proposalVersion.abstract,
    requested_budget_k_eur: proposalVersion.requested_budget_k_eur,
    budget_usage: proposalVersion.budget_usage,
    tasks_breakdown: tasks,
    attachments_meta: attachments,
  };
}
