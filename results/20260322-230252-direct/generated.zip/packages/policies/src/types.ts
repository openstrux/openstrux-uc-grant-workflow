
export interface IntakeRequest {
  call_id: string;
  title: string;
  abstract: string;
  requested_budget_k_eur: number;
  budget_usage: string;
  tasks_breakdown: unknown;
  attachments_meta: unknown[];
  legal_name: string;
  email: string;
  country: string;
  organisation: string;
}
