
/**
 * Access policy enforcement.
 *
 * Implements all policies from specs/access-policies.md:
 *   - applicant-own-proposals
 *   - admin-all
 *   - reviewer-blinded-assigned
 *   - deny-identity-to-reviewer
 */

import type {
  Principal,
  AccessDecision,
  ResourceType,
  Operation,
} from "../../domain/src/entities/index";

const POLICY_APPLICANT_OWN_PROPOSALS = "applicant-own-proposals";
const POLICY_ADMIN_ALL = "admin-all";
const POLICY_REVIEWER_BLINDED_ASSIGNED = "reviewer-blinded-assigned";
const POLICY_DENY_IDENTITY_TO_REVIEWER = "deny-identity-to-reviewer";
const POLICY_DENY_DEFAULT = "deny-default";

export function checkAccess(
  principal: Principal,
  resourceType: ResourceType,
  operation: Operation,
  resourceMeta?: Record<string, unknown>
): AccessDecision {
  // ── Admin: full access ────────────────────────────────────────────────────
  if (principal.role === "admin") {
    return {
      allowed: true,
      reason: "Admin has access to all resources.",
      policy: POLICY_ADMIN_ALL,
    };
  }

  // ── Reviewer ──────────────────────────────────────────────────────────────
  if (principal.role === "reviewer") {
    // Hard deny: identity data (checked first, before BlindedPacket gate)
    const isIdentityResource =
      resourceType === "ApplicantIdentity" ||
      (resourceType as string) === "applicant_identity";

    if (isIdentityResource) {
      return {
        allowed: false,
        reason:
          "Access denied: reviewer cannot access applicant identity data.",
        policy: POLICY_DENY_IDENTITY_TO_REVIEWER,
      };
    }

    // Hard deny: Submission (exposes applicant_alias)
    if (resourceType === "Submission") {
      return {
        allowed: false,
        reason:
          "Access denied: reviewers must access proposals through blinded packets only.",
        policy: POLICY_DENY_IDENTITY_TO_REVIEWER,
      };
    }

    // Only BlindedPacket allowed beyond this point
    if (resourceType !== "BlindedPacket") {
      return {
        allowed: false,
        reason: "Reviewers may only access blinded packets.",
        policy: POLICY_REVIEWER_BLINDED_ASSIGNED,
      };
    }

    if (operation !== "read") {
      return {
        allowed: false,
        reason: "Reviewers have read-only access to blinded packets.",
        policy: POLICY_REVIEWER_BLINDED_ASSIGNED,
      };
    }

    // Check assignment — support multiple possible meta key names
    const assignedIds =
      (resourceMeta?.["assigned_proposal_version_ids"] as string[] | undefined) ??
      (resourceMeta?.["assignedProposals"] as string[] | undefined) ??
      (resourceMeta?.["assignedIds"] as string[] | undefined) ??
      (resourceMeta?.["assignedSubmissionIds"] as string[] | undefined);

    const targetId =
      (resourceMeta?.["proposal_version_id"] as string | undefined) ??
      (resourceMeta?.["proposalVersionId"] as string | undefined) ??
      (resourceMeta?.["submissionId"] as string | undefined) ??
      (resourceMeta?.["id"] as string | undefined);

    if (!assignedIds || !targetId) {
      return {
        allowed: false,
        reason: "Assignment context not provided; access denied.",
        policy: POLICY_REVIEWER_BLINDED_ASSIGNED,
      };
    }

    if (!assignedIds.includes(targetId)) {
      return {
        allowed: false,
        reason: "Reviewer is not assigned to this proposal.",
        policy: POLICY_REVIEWER_BLINDED_ASSIGNED,
      };
    }

    return {
      allowed: true,
      reason: "Reviewer accessing assigned blinded packet.",
      policy: POLICY_REVIEWER_BLINDED_ASSIGNED,
    };
  }

  // ── Applicant ─────────────────────────────────────────────────────────────
  if (principal.role === "applicant") {
    if (resourceType === "BlindedPacket") {
      return {
        allowed: false,
        reason: "Applicants do not have access to blinded packets.",
        policy: POLICY_APPLICANT_OWN_PROPOSALS,
      };
    }

    if (operation === "delete") {
      return {
        allowed: false,
        reason: "Applicants may not delete resources.",
        policy: POLICY_APPLICANT_OWN_PROPOSALS,
      };
    }

    if (resourceType === "EligibilityRecord" && operation === "write") {
      return {
        allowed: false,
        reason: "Applicants may not write eligibility records.",
        policy: POLICY_APPLICANT_OWN_PROPOSALS,
      };
    }

    // Ownership check — support multiple possible meta key names
    const ownerAlias =
      (resourceMeta?.["applicant_alias"] as string | undefined) ??
      (resourceMeta?.["ownerAlias"] as string | undefined) ??
      (resourceMeta?.["owner"] as string | undefined) ??
      (resourceMeta?.["alias"] as string | undefined);

    // Compare against principal.identity first, then principal.id as fallback
    const principalAlias = principal.identity ?? principal.id;

    if (!ownerAlias) {
      return {
        allowed: false,
        reason: "Ownership cannot be verified; access denied.",
        policy: POLICY_APPLICANT_OWN_PROPOSALS,
      };
    }

    if (ownerAlias !== principalAlias) {
      return {
        allowed: false,
        reason: "Applicant may only access their own submissions.",
        policy: POLICY_APPLICANT_OWN_PROPOSALS,
      };
    }

    return {
      allowed: true,
      reason: "Applicant accessing own resource.",
      policy: POLICY_APPLICANT_OWN_PROPOSALS,
    };
  }

  // ── Auditor ───────────────────────────────────────────────────────────────
  if (principal.role === "auditor") {
    if (resourceType === "AuditEvent" && operation === "read") {
      return {
        allowed: true,
        reason: "Auditor read access to audit log.",
        policy: "auditor-audit-log",
      };
    }
    return {
      allowed: false,
      reason: "Auditors may only read audit events.",
      policy: "auditor-audit-log",
    };
  }

  // ── Default deny ──────────────────────────────────────────────────────────
  return {
    allowed: false,
    reason: "No matching policy; default deny.",
    policy: POLICY_DENY_DEFAULT,
  };
}
