
import { type NextRequest } from "next/server";
import { z } from "zod";
import {
  PrincipalSchema,
  PrincipalRoleSchema,
} from "../../../../../packages/domain/src/schemas/index";
import type { Principal } from "../../../../../packages/domain/src/entities/index";

function decodeJwtPayload(token: string): Record<string, unknown> | null {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const payload = parts[1];
    if (!payload) return null;
    const base64 = payload.replace(/-/g, "+").replace(/_/g, "/");
    const json = Buffer.from(base64, "base64").toString("utf-8");
    return JSON.parse(json) as Record<string, unknown>;
  } catch {
    return null;
  }
}

const DevHeadersSchema = z.object({
  role: PrincipalRoleSchema,
  actorId: z.string().min(1),
  identity: z.string().optional(),
});

export function extractPrincipal(req: NextRequest): Principal | null {
  const authHeader = req.headers.get("authorization");
  if (authHeader?.startsWith("Bearer ")) {
    const token = authHeader.slice(7);
    const payload = decodeJwtPayload(token);
    if (payload) {
      const parsed = PrincipalSchema.safeParse({
        id: payload["sub"],
        role: payload["role"],
        identity: payload["identity"],
      });
      if (parsed.success) return parsed.data;
    }
  }

  if (process.env.NODE_ENV !== "production") {
    const roleHeader = req.headers.get("x-role");
    const actorHeader = req.headers.get("x-actor-id");
    const identityHeader = req.headers.get("x-identity");

    if (roleHeader && actorHeader) {
      const parsed = DevHeadersSchema.safeParse({
        role: roleHeader,
        actorId: actorHeader,
        identity: identityHeader ?? undefined,
      });
      if (parsed.success) {
        return {
          id: parsed.data.actorId,
          role: parsed.data.role,
          identity: parsed.data.identity,
        };
      }
    }
  }

  return null;
}

export function requirePrincipal(req: NextRequest):
  | { principal: Principal; error: null }
  | { principal: null; error: Response } {
  const principal = extractPrincipal(req);
  if (!principal) {
    return {
      principal: null,
      error: new Response(JSON.stringify({ error: "Unauthenticated" }), {
        status: 401,
        headers: { "Content-Type": "application/json" },
      }),
    };
  }
  return { principal, error: null };
}

export function requireRole(
  req: NextRequest,
  ...allowedRoles: Principal["role"][]
): { principal: Principal; error: null } | { principal: null; error: Response } {
  const result = requirePrincipal(req);
  if (result.error) return result;

  if (!allowedRoles.includes(result.principal.role)) {
    return {
      principal: null,
      error: new Response(
        JSON.stringify({
          error: "Forbidden",
          detail: `Role '${result.principal.role}' is not permitted.`,
        }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      ),
    };
  }

  return result;
}
