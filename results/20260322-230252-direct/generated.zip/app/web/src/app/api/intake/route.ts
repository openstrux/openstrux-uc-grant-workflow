
import { type NextRequest, NextResponse } from "next/server";
import { IntakeRequestSchema } from "../../../../../../packages/domain/src/schemas/index";
import { submitProposal } from "../../../../../../packages/policies/src/workflow/submitProposal";
import { checkAccess } from "../../../../../../packages/policies/src/access/checkAccess";
import { requirePrincipal } from "../../../server/auth/middleware";
import { prisma } from "../../../../../../packages/domain/src/prisma/client";

export async function POST(req: NextRequest): Promise<NextResponse> {
  const auth = requirePrincipal(req);
  if (auth.error) {
    return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  }
  const { principal } = auth;

  const decision = checkAccess(principal, "Submission", "write", {
    applicant_alias: principal.identity ?? principal.id,
  });

  void prisma.auditEvent
    .create({
      data: {
        event_type: decision.allowed ? "access" : "access_denied",
        actor_id: principal.id,
        target_type: "Submission",
        target_id: "new",
        payload: {
          operation: "write",
          policy: decision.policy,
          reason: decision.reason,
          allowed: decision.allowed,
        },
      },
    })
    .catch(() => {});

  if (!decision.allowed) {
    return NextResponse.json(
      { error: "Forbidden", detail: decision.reason },
      { status: 403 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const parsed = IntakeRequestSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parsed.error.flatten() },
      { status: 422 }
    );
  }

  try {
    const result = await submitProposal(parsed.data, principal.id);
    return NextResponse.json(result, { status: 201 });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Internal server error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
