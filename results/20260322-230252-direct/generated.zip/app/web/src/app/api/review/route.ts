
/**
 * POST /api/review
 *
 * P3 — Review phase. Not implemented in v0.6.0 (MVP profile).
 */

import { type NextRequest, NextResponse } from "next/server";

export async function POST(_req: NextRequest): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", detail: "Review phase (P3) is not active in this release." },
    { status: 501 }
  );
}

export async function GET(_req: NextRequest): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", detail: "Review phase (P3) is not active in this release." },
    { status: 501 }
  );
}
