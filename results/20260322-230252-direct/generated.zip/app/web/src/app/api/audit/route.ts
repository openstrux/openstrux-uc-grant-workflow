
/**
 * GET /api/audit
 *
 * P6 — Audit/lifecycle export. Not implemented in v0.6.0 (MVP profile).
 */

import { type NextRequest, NextResponse } from "next/server";

export async function GET(_req: NextRequest): Promise<NextResponse> {
  return NextResponse.json(
    { error: "Not Implemented", detail: "Audit export (P6) is not active in this release." },
    { status: 501 }
  );
}
