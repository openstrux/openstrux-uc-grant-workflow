
import { type NextRequest, NextResponse } from "next/server";
import { EligibilityRequestSchema } from "../../../../../../packages/domain/src/schemas/index";
import { runEligibilityCheck } from "../../../../../../packages/policies/src/workflow/runEligibilityCheck";
import { checkAccess } from "../../../../../../packages/policies/src/access/checkAccess";
import { requirePrincipal } from "../../../server/auth/middleware";
import { prisma } from "../../../../../../packages/domain/src/prisma/client";

export async function POST(req: NextRequest): Promise<NextResponse> {
  const auth = requirePrincipal(req);
  if (auth.error) {
    return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  }
  const { principal } = auth;

  const decision = checkAccess(principal, "EligibilityRecord", "write", {});

  void prisma.auditEvent
    .create({
      data: {
        event_type: decision.allowed ? "access" : "access_denied",
        actor_id: principal.id,
        target_type: "EligibilityRecord",
        target_id: "new",
        payload: {
          operation: "write",
          policy: decision.policy,
          reason: decision.reason,
          allowed: decision.allowed,
        },
      },
    })
    .catch(() => {});

  if (!decision.allowed) {
    return NextResponse.json(
      { error: "Forbidden", detail: decision.reason },
      { status: 403 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const parsed = EligibilityRequestSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parsed.error.flatten() },
      { status: 422 }
    );
  }

  try {
    const result = await runEligibilityCheck(
      parsed.data.submission_id,
      parsed.data.inputs,
      principal.id
    );
    return NextResponse.json(result, { status: 200 });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Internal server error";
    if (message.includes("not found")) {
      return NextResponse.json({ error: message }, { status: 404 });
    }
    if (message.includes("Current status")) {
      return NextResponse.json({ error: message }, { status: 409 });
    }
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
